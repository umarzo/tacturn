// TacTurn — root build configuration.
//
// Versions are deliberately conservative and known-compatible:
//   AGP 8.5.2 requires Gradle 8.7+ and JDK 17+.
//   Kotlin 1.9.24 pairs with AGP 8.5.x and JDK 17 bytecode targets.

plugins {
    id("com.android.application") version "8.5.2" apply false
    id("com.android.library") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
    id("org.jetbrains.kotlin.jvm") version "1.9.24" apply false
}
