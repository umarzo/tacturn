// TacTurn engine — native C++ chess engine (libtacturn.so) + thin Kotlin
// facade. ALL chess logic is C++; the Kotlin side is bindings only.

plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tacturn.chess.engine"
    compileSdk = 34

    defaultConfig {
        minSdk = 21

        // Keep the ABI set tight: arm64 covers every modern phone, armeabi-v7a
        // legacy 32-bit devices, x86_64 the emulator.
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64")
        }
        externalNativeBuild {
            cmake {
                arguments += listOf(
                    "-DCMAKE_BUILD_TYPE=Release",
                    "-DANDROID_STL=c++_static"
                )
            }
        }
    }

    // Pin the NDK so CI/developer builds match the tested toolchain.
    ndkVersion = "27.2.12479018"

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.annotation:annotation:1.8.0")
}
