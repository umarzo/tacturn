// TacTurn Chess Engine v1 — JNI bridge for the Kotlin facade.
//
// Thin marshalling layer over the flat C API (api.h). All strings are UTF-8
// and copied into Java buffers. The engine itself is pure C++ and knows
// nothing about Java.
//
// Hardening:
//   - every entry point validates the session handle (a stale/zero handle
//     returns a safe default instead of dereferencing null)
//   - portable AttachCurrentThread via the C invoke interface
//   - logcat breadcrumbs (tag "TacTurnNative") around lifecycle + think
//
// Symbol names target com.tacturn.chess.engine.Game (instance methods) and
// Game$Companion (nativeVersion / nativeApiVersion) exactly as declared by
// the Kotlin `external fun`s.

#include <jni.h>

#include <cstring>
#include <vector>

#include "../api.h"

#if defined(__ANDROID__)
#include <android/log.h>
#define TLOG(...) __android_log_print(ANDROID_LOG_INFO, "TacTurnNative", __VA_ARGS__)
#define TWARN(...) __android_log_print(ANDROID_LOG_WARN, "TacTurnNative", __VA_ARGS__)
#else
#define TLOG(...) ((void)0)
#define TWARN(...) ((void)0)
#endif

// libtacturn is compiled with -fvisibility=hidden; only JNIEXPORT symbols
// are exported.

namespace {

inline TacHandle H(jlong h) { return (TacHandle)(intptr_t)h; }

/** Null/stale handle guard: logs once per call and returns true when the
 *  call must be skipped (the Kotlin facade degrades gracefully). */
inline bool badHandle(jlong h) {
    if (h != 0) return false;
    TWARN("native call with null session handle");
    return true;
}

jstring toJString(JNIEnv *env, const char *s) {
    return env->NewStringUTF(s ? s : "");
}

}  // namespace

extern "C" {

// ================= Game$Companion: nativeVersion / nativeApiVersion =====

JNIEXPORT jstring JNICALL
Java_com_tacturn_chess_engine_Game_00024Companion_nativeVersion(JNIEnv *env, jobject) {
    return toJString(env, tacturn_version());
}

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_00024Companion_nativeApiVersion(JNIEnv *, jobject) {
    return tacturn_api_version();
}

// v1.1: PGO training entry point (profile generation only — see
// scripts/pgo/README-PGO.md). Not called by the app's normal flow.
JNIEXPORT jlong JNICALL
Java_com_tacturn_chess_engine_Game_00024Companion_nativePgoTrain(JNIEnv *, jobject,
                                                                 jint seconds) {
    return (jlong)tacturn_pgo_train(seconds);
}

// ================= Game: lifecycle ======================================

JNIEXPORT jlong JNICALL
Java_com_tacturn_chess_engine_Game_nativeCreate(JNIEnv *, jobject, jint ttBits) {
    TLOG("nativeCreate ttBits=%d", (int)ttBits);
    return (jlong)(intptr_t)tacturn_create(ttBits);
}

JNIEXPORT void JNICALL
Java_com_tacturn_chess_engine_Game_nativeDestroy(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return;
    TLOG("nativeDestroy");
    tacturn_destroy(H(h));
}

JNIEXPORT void JNICALL
Java_com_tacturn_chess_engine_Game_nativeReset(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return;
    tacturn_reset(H(h));
}

JNIEXPORT jboolean JNICALL
Java_com_tacturn_chess_engine_Game_nativeSetFen(JNIEnv *env, jobject, jlong h, jstring fen) {
    if (badHandle(h) || fen == nullptr) return JNI_FALSE;
    const char *c = env->GetStringUTFChars(fen, nullptr);
    int32_t ok = tacturn_set_fen(H(h), c);
    env->ReleaseStringUTFChars(fen, c);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jstring JNICALL
Java_com_tacturn_chess_engine_Game_nativeFen(JNIEnv *env, jobject, jlong h) {
    char buf[128];
    if (badHandle(h)) return toJString(env, "");
    tacturn_fen(H(h), buf, (int32_t)sizeof(buf));
    return toJString(env, buf);
}

// ================= Game: board / queries ================================

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeSideToMove(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return 0;
    return tacturn_side_to_move(H(h));
}

JNIEXPORT void JNICALL
Java_com_tacturn_chess_engine_Game_nativeBoardPieces(JNIEnv *env, jobject, jlong h,
                                                     jintArray out) {
    if (badHandle(h) || out == nullptr || env->GetArrayLength(out) != 64) return;
    jint tmp[64];
    tacturn_board_pieces(H(h), tmp);
    env->SetIntArrayRegion(out, 0, 64, tmp);
}

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeKingSquare(JNIEnv *, jobject, jlong h, jint color) {
    if (badHandle(h)) return -1;
    return tacturn_king_square(H(h), color);
}

JNIEXPORT jboolean JNICALL
Java_com_tacturn_chess_engine_Game_nativeInCheck(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return JNI_FALSE;
    return tacturn_in_check(H(h)) ? JNI_TRUE : JNI_FALSE;
}

// ================= Game: moves ==========================================

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeLegalMoves(JNIEnv *env, jobject, jlong h,
                                                    jintArray out) {
    if (badHandle(h) || out == nullptr) return 0;
    jint tmp[256];
    int32_t n = tacturn_legal_moves(H(h), tmp, 256);
    int32_t cap = env->GetArrayLength(out);
    int32_t copy = n < cap ? n : cap;
    if (copy > 0) env->SetIntArrayRegion(out, 0, copy, tmp);
    return n;
}

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeFindMoves(JNIEnv *env, jobject, jlong h, jint from,
                                                   jint to, jintArray out) {
    if (badHandle(h) || out == nullptr) return 0;
    jint tmp[8];
    int32_t n = tacturn_find_moves(H(h), from, to, tmp, 8);
    int32_t cap = env->GetArrayLength(out);
    int32_t copy = n < cap ? n : cap;
    if (copy > 0) env->SetIntArrayRegion(out, 0, copy, tmp);
    return n;
}

JNIEXPORT jboolean JNICALL
Java_com_tacturn_chess_engine_Game_nativeMakeMove(JNIEnv *, jobject, jlong h, jint move) {
    if (badHandle(h)) return JNI_FALSE;
    // Returns the SAN length (>0) when applied, 0 when rejected.
    // SAN is fetched separately via nativeMoveSan(lastIndex) by the facade.
    return tacturn_make_move(H(h), move, nullptr, 0) > 0 ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_tacturn_chess_engine_Game_nativeUndo(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return JNI_FALSE;
    return tacturn_undo(H(h)) ? JNI_TRUE : JNI_FALSE;
}

// ================= Game: records / result ===============================

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeMoveCount(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return 0;
    return tacturn_move_count(H(h));
}

JNIEXPORT jstring JNICALL
Java_com_tacturn_chess_engine_Game_nativeMoveSan(JNIEnv *env, jobject, jlong h, jint index) {
    char san[32];
    int32_t move, captured;
    if (badHandle(h)) return toJString(env, "");
    if (!tacturn_move_record(H(h), index, &move, &captured, san, (int32_t)sizeof(san)))
        return toJString(env, "");
    return toJString(env, san);
}

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeMoveRecordMove(JNIEnv *, jobject, jlong h, jint index) {
    int32_t move = 0, captured = 0;
    if (badHandle(h)) return 0;
    tacturn_move_record(H(h), index, &move, &captured, nullptr, 0);
    return move;
}

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeMoveRecordCaptured(JNIEnv *, jobject, jlong h,
                                                            jint index) {
    int32_t move = 0, captured = 0;
    if (badHandle(h)) return 6;  // NO_PIECE
    tacturn_move_record(H(h), index, &move, &captured, nullptr, 0);
    return captured;
}

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeResult(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return 0;  // ONGOING
    return tacturn_result(H(h));
}

// ================= Game: book / search ==================================

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeBookProbe(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return 0;
    return tacturn_book_probe(H(h));
}

JNIEXPORT jboolean JNICALL
Java_com_tacturn_chess_engine_Game_nativeBookContains(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return JNI_FALSE;
    return tacturn_book_contains(H(h)) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_tacturn_chess_engine_Game_nativeBookIsBookMove(JNIEnv *, jobject, jlong h,
                                                       jint move) {
    if (badHandle(h)) return JNI_FALSE;
    return tacturn_book_contains_move(H(h), move) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_tacturn_chess_engine_Game_nativeRequestStop(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return;
    tacturn_request_stop(H(h));
}

JNIEXPORT void JNICALL
Java_com_tacturn_chess_engine_Game_nativeClearSearchTable(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return;
    tacturn_clear_search_table(H(h));
}

// ---- search with progress callback ----

struct CallbackCtx {
    JavaVM *vm;
    jobject ref;      // global ref to the IterationListener
    jmethodID mid;    // IterationListener.onIteration(IIIJJ)V
};

static void iterationCallback(void *userdata, int32_t depth, int32_t score, int32_t bestMove,
                              int64_t nodes, int64_t timeMs) {
    CallbackCtx *ctx = (CallbackCtx *)userdata;
    JNIEnv *env = nullptr;
    bool attached = false;
    // Portable across JNI headers: GetEnv takes void** everywhere, but
    // AttachCurrentThread is declared JNIEnv** in the NDK's jni.h and void**
    // in desktop JDK headers — dispatch at compile time, call through the
    // plain C invoke interface on both.
    JavaVM *vm = ctx->vm;
    if (vm->functions->GetEnv(vm, (void **)&env, JNI_VERSION_1_6) != JNI_OK) {
        bool ok;
#ifdef __ANDROID__
        ok = vm->functions->AttachCurrentThread(vm, &env, nullptr) == JNI_OK;
#else
        ok = vm->functions->AttachCurrentThread(vm, (void **)&env, nullptr) == JNI_OK;
#endif
        if (!ok) return;
        attached = true;
    }
    env->CallVoidMethod(ctx->ref, ctx->mid, depth, score, bestMove, (jlong)nodes, (jlong)timeMs);
    if (env->ExceptionCheck()) env->ExceptionClear();
    if (attached) vm->functions->DetachCurrentThread(vm);
}

/**
 * Wraps the callback plumbing shared by think/analyze: creates the global
 * ref + method id, returns false when the listener is unusable.
 */
static bool setupCallback(JNIEnv *env, jobject callback, CallbackCtx *ctx) {
    if (callback == nullptr) return false;
    JavaVM *vm = nullptr;
    env->GetJavaVM(&vm);
    ctx->vm = vm;
    ctx->ref = env->NewGlobalRef(callback);
    jclass cls = env->GetObjectClass(callback);
    ctx->mid = env->GetMethodID(cls, "onIteration", "(IIIJJ)V");
    if (ctx->mid == nullptr) {
        if (env->ExceptionCheck()) env->ExceptionClear();
        env->DeleteGlobalRef(ctx->ref);
        ctx->ref = nullptr;
        return false;
    }
    return true;
}

static void teardownCallback(JNIEnv *env, CallbackCtx *ctx) {
    if (ctx->ref != nullptr) {
        env->DeleteGlobalRef(ctx->ref);
        ctx->ref = nullptr;
    }
}

/** Converts TacSearchLimits (JNI args form) into the C struct. */
static TacSearchLimits toLimits(jint maxDepth, jlong moveTimeMs, jlong hardMoveTimeMs,
                                jboolean adaptiveTime, jint depthFloor, jint lastScore,
                                jint jitterCp, jint contemptCp, jint threads,
                                jint interIterationDelayMs) {
    TacSearchLimits lim;
    lim.maxDepth = maxDepth;
    lim.moveTimeMs = moveTimeMs;
    lim.hardMoveTimeMs = hardMoveTimeMs;
    lim.adaptiveTime = adaptiveTime ? 1 : 0;
    lim.depthFloor = depthFloor;
    lim.lastScore = lastScore;
    lim.jitterCp = jitterCp;
    lim.contemptCp = contemptCp;
    lim.threads = threads;
    lim.interIterationDelayMs = interIterationDelayMs;
    lim.rootExcludeCount = 0;
    return lim;
}

JNIEXPORT void JNICALL
Java_com_tacturn_chess_engine_Game_nativeThink(JNIEnv *env, jobject, jlong h, jint maxDepth,
                                               jlong moveTimeMs, jlong hardMoveTimeMs,
                                               jboolean adaptiveTime, jint depthFloor,
                                               jint lastScore, jint jitterCp, jint contemptCp,
                                               jint threads, jint interIterationDelayMs,
                                               jobject callback, jintArray outResult) {
    if (badHandle(h)) {
        // Session already closed: report "no move" and let the facade unwind
        // gracefully instead of dereferencing a dead handle.
        if (outResult != nullptr && env->GetArrayLength(outResult) >= 8) {
            jint r[8] = {0, 0, 0, 0, 0, 0, 0, 0};
            env->SetIntArrayRegion(outResult, 0, 8, r);
        }
        return;
    }

    TacSearchLimits lim = toLimits(maxDepth, moveTimeMs, hardMoveTimeMs, adaptiveTime,
                                   depthFloor, lastScore, jitterCp, contemptCp, threads,
                                   interIterationDelayMs);

    TacSearchResult result;
    CallbackCtx ctx;
    bool useCb = setupCallback(env, callback, &ctx);

    TLOG("think: depth<=%d movetime=%lldms hard=%lldms adaptive=%d threads=%d",
         (int)maxDepth, (long long)moveTimeMs, (long long)hardMoveTimeMs,
         (int)(adaptiveTime ? 1 : 0), (int)threads);

    tacturn_think(H(h), &lim, useCb ? iterationCallback : nullptr, useCb ? &ctx : nullptr,
                  &result);

    if (useCb) {
        teardownCallback(env, &ctx);
    }

    TLOG("think done: move=%d score=%d depth=%d nodes=%lld time=%lldms",
         (int)result.bestMove, (int)result.score, (int)result.depth,
         (long long)result.nodes, (long long)result.timeMs);

    if (outResult != nullptr && env->GetArrayLength(outResult) >= 8) {
        // Layout: [0]=bestMove [1]=score [2]=depth [3]=mateIn
        //         [4]=nodesHi [5]=nodesLo [6]=timeMs ([7] spare)
        jint r[8] = {0, 0, 0, 0, 0, 0, 0, 0};
        r[0] = result.bestMove;
        r[1] = result.score;
        r[2] = result.depth;
        r[3] = result.mateIn;
        r[4] = (jint)((uint64_t)result.nodes >> 32);
        r[5] = (jint)((uint64_t)result.nodes & 0xFFFFFFFFULL);
        r[6] = (jint)result.timeMs;
        env->SetIntArrayRegion(outResult, 0, 8, r);
    }
}

// ---- Multi-PV analysis ----

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeAnalyze(JNIEnv *env, jobject, jlong h, jint maxDepth,
                                                 jlong moveTimeMs, jlong hardMoveTimeMs,
                                                 jboolean adaptiveTime, jint depthFloor,
                                                 jint contemptCp, jint multiPv,
                                                 jint interIterationDelayMs, jint threads,
                                                 jobject callback, jintArray outLines) {
    if (badHandle(h) || outLines == nullptr) return 0;

    // Flat int layout per line: [score, depth, mateIn, pvLen, pv0..pv23]
    // → 4 + 24 = 28 ints; outLines must hold maxLines * 28 (Kotlin sizes it).
    const int LINE_INTS = 4 + TACTURN_MAX_PV;
    const int maxLines = env->GetArrayLength(outLines) / LINE_INTS;
    if (maxLines <= 0) return 0;

    // Fix: adaptiveTime/depthFloor used to be hardcoded to off/0 here,
    // silently discarding whatever the Kotlin side requested. Multi-PV
    // analysis (interactive AND batch game-review) now gets the same
    // complexity/instability-aware time allocation as Play (nativeThink),
    // instead of every position racing an identical flat clock regardless
    // of how sharp or forced it is. contemptCp is threaded through so
    // analysis runs contempt-free (0) while play keeps its draw-avoidance.
    TacSearchLimits lim = toLimits(maxDepth, moveTimeMs, hardMoveTimeMs, adaptiveTime,
                                   depthFloor, 0, 0, contemptCp, threads,
                                   interIterationDelayMs);

    std::vector<TacPvLine> lines((size_t)maxLines);
    CallbackCtx ctx;
    bool useCb = setupCallback(env, callback, &ctx);

    TLOG("analyze: depth<=%d movetime=%lldms adaptive=%d multiPv=%d", (int)maxDepth,
         (long long)moveTimeMs, (int)(adaptiveTime ? 1 : 0), (int)multiPv);

    int32_t n = tacturn_analyze(H(h), &lim, multiPv, useCb ? iterationCallback : nullptr,
                                useCb ? &ctx : nullptr, lines.data(), maxLines);

    if (useCb) {
        teardownCallback(env, &ctx);
    }

    TLOG("analyze done: %d lines", (int)n);

    if (n > 0) {
        std::vector<jint> flat((size_t)n * LINE_INTS);
        for (int32_t i = 0; i < n; i++) {
            const TacPvLine &l = lines[(size_t)i];
            flat[(size_t)i * LINE_INTS + 0] = l.score;
            flat[(size_t)i * LINE_INTS + 1] = l.depth;
            flat[(size_t)i * LINE_INTS + 2] = l.mateIn;
            flat[(size_t)i * LINE_INTS + 3] = l.pvLen;
            for (int32_t m = 0; m < l.pvLen && m < TACTURN_MAX_PV; m++)
                flat[(size_t)i * LINE_INTS + 4 + m] = l.pv[m];
        }
        env->SetIntArrayRegion(outLines, 0, (jsize)flat.size(), flat.data());
    }
    return n;
}

// ---- SAN for a legal move in the current position ----

JNIEXPORT jstring JNICALL
Java_com_tacturn_chess_engine_Game_nativeSanFor(JNIEnv *env, jobject, jlong h, jint move) {
    char san[32];
    if (badHandle(h)) return toJString(env, "");
    int32_t ok = tacturn_san_for(H(h), move, san, (int32_t)sizeof(san));
    if (ok <= 0) return toJString(env, "");
    return toJString(env, san);
}

// ---- resignation ----

JNIEXPORT void JNICALL
Java_com_tacturn_chess_engine_Game_nativeResign(JNIEnv *, jobject, jlong h, jint winnerColor) {
    if (badHandle(h)) return;
    tacturn_resign(H(h), winnerColor);
}

// ---- draw by agreement ----

JNIEXPORT void JNICALL
Java_com_tacturn_chess_engine_Game_nativeAgreeDraw(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return;
    tacturn_agree_draw(H(h));
}

// ---- static evaluation ----

JNIEXPORT jint JNICALL
Java_com_tacturn_chess_engine_Game_nativeEvaluate(JNIEnv *, jobject, jlong h) {
    if (badHandle(h)) return 0;
    return tacturn_evaluate(H(h));
}

}  // extern "C"
