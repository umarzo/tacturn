package com.tacturn.chess.engine

/*
 * TacTurn Chess Engine v1 — Kotlin facade over the native engine.
 *
 * Everything chess-related is computed by the C++ engine (libtacturn.so);
 * this facade exposes a small Game/SearchLimits/PvLine/GameResult surface
 * so the UI layer stays free of JNI details. All native calls are confined
 * to the single engine-thread the ViewModel already serializes through.
 */


/** Game outcomes (values mirror GameResultValue in engine/cpp/tacturn/game.h). */
enum class GameResult {
    ONGOING, WHITE_WINS, BLACK_WINS,
    DRAW_STALEMATE, DRAW_FIFTY_MOVE, DRAW_REPETITION, DRAW_INSUFFICIENT_MATERIAL,
    DRAW_AGREEMENT;

    val isDraw: Boolean get() = this == DRAW_STALEMATE || this == DRAW_FIFTY_MOVE ||
            this == DRAW_REPETITION || this == DRAW_INSUFFICIENT_MATERIAL ||
            this == DRAW_AGREEMENT

    val isGameOver: Boolean get() = this != ONGOING

    companion object {
        fun fromNative(v: Int): GameResult = when (v) {
            1 -> WHITE_WINS
            2 -> BLACK_WINS
            3 -> DRAW_STALEMATE
            4 -> DRAW_FIFTY_MOVE
            5 -> DRAW_REPETITION
            6 -> DRAW_INSUFFICIENT_MATERIAL
            7 -> DRAW_AGREEMENT
            else -> ONGOING
        }
    }
}

/** One recorded move in the history (SAN computed natively). */
class MoveRecord(val move: Int, val san: String)

/** Search limits for a native search, covering both single-line search
 *  (Play) and Multi-PV analysis (Analyze), mirroring the native
 *  TacSearchLimits struct field-for-field. */
data class SearchLimits(
    val maxDepth: Int = 64,
    val moveTimeMs: Long = 5000,
    val hardMoveTimeMs: Long = 0,        // hard wall-clock cap; 0 -> moveTimeMs
    val adaptiveTime: Boolean = false,   // complexity-scaled budget + instability extension
    val depthFloor: Int = 8,             // never stop below this completed depth (adaptive)
    val lastScore: Int = 0,              // previous move's score (game-level context)
    val jitterCp: Int = 0,               // root-only random noise for weaker levels
    /** Draw contempt (cp). Play keeps the engine's historical 12 (avoid-draws
     *  bias); ANALYSIS passes 0 so reviewed evals are POV-neutral truth —
     *  the same convention as Contempt 0 / SideToMove off in UCI engines. */
    val contemptCp: Int = 12,
    val threads: Int = 1,                // Lazy-SMP thread count (1 = single thread)
    val interIterationDelayMs: Int = 0   // battery-saver duty cycling between iterations
)

/** One analysis line: score + principal variation. */
data class PvLine(
    val score: Int,          // centipawns (or mate scores) from mover POV
    val depth: Int,          // completed depth of the search that produced it
    val mateIn: Int,         // moves to mate (positive: we deliver)
    val pv: List<Int>        // move ints, pv[0] is the root move
)

/** Iteration progress while the engine thinks. */
data class IterationInfo(
    val depth: Int,
    val score: Int,
    val bestMove: Int,
    val nodes: Long,
    val timeMs: Long
)

/** Final search result (same shape as the old Kotlin SearchResult). */
data class SearchResult(
    val bestMove: Int,
    val score: Int,
    val depth: Int,
    val nodes: Long,
    val timeMs: Long,
    val mateIn: Int
)

/** Per-iteration callback interface marshalled through JNI. */
interface IterationListener {
    fun onIteration(depth: Int, score: Int, bestMove: Int, nodes: Long, timeMs: Long)
}

/**
 * The game session: native position + records + searcher + book, behind a
 * long handle. Mirrors the old `Game` + `Searcher` + `Book` trio.
 *
 * [ttBits] sizes the transposition table (2^bits entries at 16 bytes each —
 * v1.3.2 packs each entry into one cache line; 21 ≈ 32 MB gives the top
 * levels headroom, and the native table falls back
 * to smaller sizes automatically if the allocation fails). Loading the
 * native library is lazy — it happens on first class initialization, i.e.
 * when the user actually enters Play or Analysis, never at app launch.
 */
class Game(initialFen: String = START_FEN, ttBits: Int = 21) : AutoCloseable {

    private var handle: Long = 0L

    /** Board snapshot view — refreshed after every mutation on this thread. */
    val board = BoardView()

    init {
        handle = nativeCreate(ttBits)
        if (handle == 0L) {
            throw IllegalStateException("native engine create failed")
        }
        resetTo(initialFen)
    }

    // ---- lifecycle ----

    fun reset(fen: String = START_FEN) = resetTo(fen)

    private fun resetTo(fen: String) {
        nativeReset(handle)
        if (fen != START_FEN) nativeSetFen(handle, fen)
        refreshBoard()
    }

    fun fen(): String = nativeFen(handle)

    /**
     * Sets the position from a FEN string. The native side validates
     * the input and leaves the session UNTOUCHED when invalid — so callers
     * get a clean boolean with no half-parsed state. Move records are
     * cleared on success (same semantics as setFen in api.h).
     */
    fun setFen(fen: String): Boolean {
        if (fen.isBlank()) return false
        return nativeSetFen(handle, fen)
    }

    override fun close() {
        if (handle != 0L) {
            nativeDestroy(handle)
            handle = 0L
        }
    }

    // ---- legal moves ----

    fun legalMoves(): List<Int> {
        val out = IntArray(MAX_MOVES)
        val n = nativeLegalMoves(handle, out)
        return out.take(n)
    }

    fun legalMovesFrom(sq: Int): List<Int> = legalMoves().filter { moveFrom(it) == sq }

    fun findMoves(from: Int, to: Int): List<Int> {
        val out = IntArray(8)
        val n = nativeFindMoves(handle, from, to, out)
        return out.take(n)
    }

    // ---- making moves ----

    fun makeMove(move: Int): String {
        if (!nativeMakeMove(handle, move)) return ""
        refreshBoard()
        return nativeMoveSan(handle, nativeMoveCount(handle) - 1)
    }

    fun undo(): String? {
        val count = nativeMoveCount(handle)
        if (count == 0) return null
        val san = nativeMoveSan(handle, count - 1)
        if (!nativeUndo(handle)) return null
        refreshBoard()
        return san
    }

    fun inCheck(): Boolean = nativeInCheck(handle)

    // ---- history ----

    val moveRecords: List<MoveRecord>
        get() {
            val n = nativeMoveCount(handle)
            return (0 until n).map { i ->
                MoveRecord(nativeMoveRecordMove(handle, i), nativeMoveSan(handle, i))
            }
        }

    // ---- results ----

    fun result(): GameResult = GameResult.fromNative(nativeResult(handle))

    /** Resigns — the given color wins immediately by resignation. */
    fun resign(winnerColor: Int) = nativeResign(handle, winnerColor)

    /** Ends the game immediately as a draw by mutual agreement. */
    fun agreeDraw() = nativeAgreeDraw(handle)

    /** Static evaluation of the current position, mover POV, centipawns. */
    fun evaluate(): Int = nativeEvaluate(handle)

    fun checkSquare(): Int =
        if (nativeInCheck(handle)) nativeKingSquare(handle, board.sideToMove) else NO_SQUARE

    // ---- search ----

    fun think(
        limits: SearchLimits,
        onIteration: ((IterationInfo) -> Unit)? = null
    ): SearchResult {
        val listener = onIteration?.let { cb ->
            object : IterationListener {
                override fun onIteration(depth: Int, score: Int, bestMove: Int, nodes: Long,
                                         timeMs: Long) {
                    cb(IterationInfo(depth, score, bestMove, nodes, timeMs))
                }
            }
        }
        val out = IntArray(8)
        nativeThink(
            handle, limits.maxDepth, limits.moveTimeMs, limits.hardMoveTimeMs,
            limits.adaptiveTime, limits.depthFloor, limits.lastScore, limits.jitterCp,
            limits.contemptCp, limits.threads, limits.interIterationDelayMs, listener, out
        )
        // Native layout: out[4] = nodes high word, out[5] = nodes low word.
        val nodes = (out[5].toLong() and 0xFFFFFFFFL) or (out[4].toLong() shl 32)
        return SearchResult(out[0], out[1], out[2], nodes, out[6].toLong(), out[3])
    }

    fun requestStop() = nativeRequestStop(handle)
    fun clearSearchTable() = nativeClearSearchTable(handle)

    // ---- analysis ----

    /**
     * Multi-PV analysis of the current position. Up to [multiPv] lines are
     * produced best-first via root-exclusion sequential searches (all inside
     * one native call, sharing the transposition table). [onIteration]
     * streams live depth/score/nps for the FIRST line only.
     *
     * [limits.adaptiveTime]/[limits.depthFloor] are honored here exactly as
     * in [think] (fix: previously silently dropped between here and the
     * JNI boundary, so batch game-review analysis always ran as a flat
     * time race regardless of what was requested — see [AnalysisBudgets]
     * for the user-visible symptom this caused).
     *
     * Runs on the CALLING thread — callers must already be on the engine
     * dispatcher. Returns an empty list when the position has no legal
     * moves (checkmate/stalemate) or the search was stopped.
     */
    fun analyze(
        limits: SearchLimits,
        multiPv: Int,
        onIteration: ((IterationInfo) -> Unit)? = null
    ): List<PvLine> {
        val listener = onIteration?.let { cb ->
            object : IterationListener {
                override fun onIteration(depth: Int, score: Int, bestMove: Int, nodes: Long,
                                         timeMs: Long) {
                    cb(IterationInfo(depth, score, bestMove, nodes, timeMs))
                }
            }
        }
        val maxLines = multiPv.coerceIn(1, MAX_ANALYSIS_LINES)
        // Flat layout per line: [score, depth, mateIn, pvLen, pv0..pv23] = 28 ints.
        val out = IntArray(maxLines * (4 + NATIVE_MAX_PV))
        val n = nativeAnalyze(
            handle, limits.maxDepth, limits.moveTimeMs,
            if (limits.hardMoveTimeMs > 0) limits.hardMoveTimeMs else limits.moveTimeMs,
            limits.adaptiveTime, limits.depthFloor, limits.contemptCp,
            maxLines, limits.interIterationDelayMs, limits.threads, listener, out
        )
        if (n <= 0) return emptyList()
        val lineInts = 4 + NATIVE_MAX_PV
        return (0 until n).map { i ->
            val base = i * lineInts
            val pvLen = out[base + 3].coerceIn(0, NATIVE_MAX_PV)
            PvLine(
                score = out[base],
                depth = out[base + 1],
                mateIn = out[base + 2],
                pv = (0 until pvLen).map { out[base + 4 + it] }
            )
        }
    }

    /** SAN for a legal move in the current position, without applying it.
     *  Returns "" when the move is not legal here. */
    fun sanFor(move: Int): String = nativeSanFor(handle, move)

    // ---- book ----

    fun bookProbe(): Int = nativeBookProbe(handle)

    /** True when the current position is known opening theory. */
    fun bookContains(): Boolean = nativeBookContains(handle)

    /** True when [move] is one of the book continuations of the current
     *  position (game review uses this to tag "Book" moves). */
    fun isBookMove(move: Int): Boolean = nativeBookIsBookMove(handle, move)

    // ---- board snapshot ----

    /**
     * Cheap view over the native board: pieceTypeOf/pieceColorOf/sideToMove/
     * kingSquare are served from an IntArray snapshot refreshed after every
     * mutation (the game only ever mutates on the engine thread, so the
     * snapshot is always coherent with the session).
     */
    inner class BoardView {
        var sideToMove: Int = WHITE
            private set
        private var pieces = IntArray(64) { -1 }

        val pieceTypeOf = IntArray(64)
        val pieceColorOf = IntArray(64)

        init {
            refresh()
        }

        fun refresh() {
            sideToMove = nativeSideToMove(handle)
            nativeBoardPieces(handle, pieces)
            for (sq in 0 until 64) {
                pieceTypeOf[sq] = if (pieces[sq] < 0) NO_PIECE else pieces[sq] and 7
                pieceColorOf[sq] = if (pieces[sq] < 0) -1 else pieces[sq] shr 3
            }
        }

        fun kingSquare(color: Int): Int = nativeKingSquare(handle, color)
    }

    private fun refreshBoard() {
        board.refresh()
    }

    // ---- native entry points (implemented in engine/cpp/tacturn/jni) ----

    private external fun nativeCreate(ttBits: Int): Long
    private external fun nativeDestroy(h: Long)
    private external fun nativeReset(h: Long)
    private external fun nativeSetFen(h: Long, fen: String): Boolean
    private external fun nativeFen(h: Long): String
    private external fun nativeSideToMove(h: Long): Int
    private external fun nativeBoardPieces(h: Long, out: IntArray)
    private external fun nativeKingSquare(h: Long, color: Int): Int
    private external fun nativeInCheck(h: Long): Boolean
    private external fun nativeLegalMoves(h: Long, out: IntArray): Int
    private external fun nativeFindMoves(h: Long, from: Int, to: Int, out: IntArray): Int
    private external fun nativeMakeMove(h: Long, move: Int): Boolean
    private external fun nativeUndo(h: Long): Boolean
    private external fun nativeMoveCount(h: Long): Int
    private external fun nativeMoveSan(h: Long, index: Int): String
    private external fun nativeMoveRecordMove(h: Long, index: Int): Int
    private external fun nativeResult(h: Long): Int
    private external fun nativeResign(h: Long, winnerColor: Int)
    private external fun nativeAgreeDraw(h: Long)
    private external fun nativeEvaluate(h: Long): Int
    private external fun nativeBookProbe(h: Long): Int
    private external fun nativeRequestStop(h: Long)
    private external fun nativeClearSearchTable(h: Long)
    private external fun nativeThink(
        h: Long, maxDepth: Int, moveTimeMs: Long, hardMoveTimeMs: Long,
        adaptiveTime: Boolean, depthFloor: Int, lastScore: Int, jitterCp: Int,
        contemptCp: Int, threads: Int, interIterationDelayMs: Int,
        callback: IterationListener?, out: IntArray
    )

    // ---- analysis native entry points ----

    private external fun nativeAnalyze(
        h: Long, maxDepth: Int, moveTimeMs: Long, hardMoveTimeMs: Long,
        adaptiveTime: Boolean, depthFloor: Int, contemptCp: Int, multiPv: Int,
        interIterationDelayMs: Int, threads: Int, callback: IterationListener?,
        outLines: IntArray
    ): Int

    private external fun nativeSanFor(h: Long, move: Int): String

    private external fun nativeBookContains(h: Long): Boolean

    private external fun nativeBookIsBookMove(h: Long, move: Int): Boolean

    companion object {
        val START_FEN: String = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        /** Must mirror TACTURN_MAX_PV in api.h. */
        const val NATIVE_MAX_PV = 24

        /** Hard cap on Multi-PV lines requested from the native side. */
        const val MAX_ANALYSIS_LINES = 4

        init {
            System.loadLibrary("tacturn")
        }

        /** Engine identity string from the native side (diagnostics). */
        external fun nativeVersion(): String

        external fun nativeApiVersion(): Int

        /**
         * v1.1 PGO profile-training run (build-time tool, not a game
         * feature): drives the native engine through a deterministic
         * search workload for [seconds] and returns the nodes searched.
         * Only meaningful in a build compiled with
         * `-fprofile-generate` (see scripts/pgo/README-PGO.md); the
         * resulting .profraw is then used to rebuild the release
         * library with `-fprofile-use`.
         */
        external fun nativePgoTrain(seconds: Int): Long
    }
}
