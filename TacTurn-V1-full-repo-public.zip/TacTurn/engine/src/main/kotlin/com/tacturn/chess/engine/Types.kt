@file:Suppress("unused")

package com.tacturn.chess.engine

/*
 * TacTurn Chess Engine v1 — Kotlin-side constants & move encoding.
 *
 * The move encoding is BIT-IDENTICAL to the C++ engine's (engine/cpp/tacturn/
 * types.h) so values can cross the JNI boundary untouched. These helpers are
 * pure Kotlin (no native calls) — the UI keeps using moveFrom()/moveTo()/...
 * exactly as before.
 *
 * All chess LOGIC now lives in the native engine (libtacturn.so); this file
 * only mirrors the wire types.
 */

const val WHITE = 0
const val BLACK = 1

const val PAWN = 0
const val KNIGHT = 1
const val BISHOP = 2
const val ROOK = 3
const val QUEEN = 4
const val KING = 5
const val NO_PIECE = 6

const val NO_SQUARE = -1

const val MAX_MOVES = 256

// ---- Castling right bits ----
const val CASTLE_WK = 1
const val CASTLE_WQ = 2
const val CASTLE_BK = 4
const val CASTLE_BQ = 8

// ---- Move flags (must match engine/cpp/tacturn/types.h) ----
private const val FLAG_EP = 1 shl 21
private const val FLAG_CASTLE_K = 1 shl 22
private const val FLAG_CASTLE_Q = 1 shl 23
private const val FLAG_DOUBLE = 1 shl 24

/** Sentinel meaning "no move". A legal move can never be 0 (a1 -> a1 does not exist). */
const val MOVE_NONE = 0

fun moveFrom(m: Int): Int = m and 63
fun moveTo(m: Int): Int = (m ushr 6) and 63
fun movePiece(m: Int): Int = (m ushr 12) and 7
fun moveCaptured(m: Int): Int = (m ushr 15) and 7
fun movePromo(m: Int): Int = (m ushr 18) and 7
fun isEPMove(m: Int): Boolean = m and FLAG_EP != 0
fun isCastleK(m: Int): Boolean = m and FLAG_CASTLE_K != 0
fun isCastleQ(m: Int): Boolean = m and FLAG_CASTLE_Q != 0
fun isCastleMove(m: Int): Boolean = m and (FLAG_CASTLE_K or FLAG_CASTLE_Q) != 0
fun isDoublePush(m: Int): Boolean = m and FLAG_DOUBLE != 0
fun isCapture(m: Int): Boolean = moveCaptured(m) != NO_PIECE
fun isQuiet(m: Int): Boolean = moveCaptured(m) == NO_PIECE && movePromo(m) == 0

/** File index 0..7 ('a'..'h') of a square. */
fun fileOf(sq: Int): Int = sq and 7

/** Rank index 0..7 ('1'..'8') of a square. */
fun rankOf(sq: Int): Int = sq shr 3

/** Algebraic square name, e.g. "e4". */
fun squareName(sq: Int): String {
    val f = 'a' + (sq and 7)
    val r = '1' + (sq shr 3)
    return "$f$r"
}

/** Parses an algebraic square name such as "e4". Returns [NO_SQUARE] when invalid. */
fun squareFromName(name: String): Int {
    if (name.length != 2) return NO_SQUARE
    val f = name[0] - 'a'
    val r = name[1] - '1'
    if (f !in 0..7 || r !in 0..7) return NO_SQUARE
    return r * 8 + f
}

/** Piece letter used in SAN ("N", "B", ... — pawn is empty). */
fun sanPieceLetter(type: Int): String = when (type) {
    KNIGHT -> "N"; BISHOP -> "B"; ROOK -> "R"; QUEEN -> "Q"; KING -> "K"; else -> ""
}

/** Letter for a promotion piece type (must be KNIGHT..QUEEN). */
fun sanPromoLetter(type: Int): Char = when (type) {
    KNIGHT -> 'N'; BISHOP -> 'B'; ROOK -> 'R'; QUEEN -> 'Q'; else -> 'Q'
}

/** Piece values used by search ordering / SEE (centipawns; mirrors engine). */
val PIECE_VALUES = intArrayOf(100, 320, 330, 500, 950, 20000, 0)

// ---- Search score constants (mirror engine/cpp/tacturn/search.h) ----
object Searcher {
    const val MATE = 32000
    const val MATE_BOUND = MATE - 512
    const val INFINITE = 33000
}
