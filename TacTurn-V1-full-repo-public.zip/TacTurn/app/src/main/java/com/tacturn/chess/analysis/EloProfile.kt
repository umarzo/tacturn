package com.tacturn.chess.analysis

/*
 * TacTurn v1 — the personalization layer.
 *
 * An [EloProfile] captures EVERYTHING that changes between skill tiers:
 * score rounding, line count, sharp-move filtering, verbal feedback,
 * practicality chips and search budgets. The raw
 * engine scores (see [GameReview]) are computed ONCE per game and cached;
 * switching Elo re-applies only this profile on the UI thread — instant.
 */

enum class SkillTier(val label: String) {
    BEGINNER("Beginner"),
    CLUB("Club"),
    ADVANCED("Advanced"),
    MASTER("Master")
}

data class EloProfile(
    val elo: Int,
    val tier: SkillTier,
    /** Round centipawn scores to full pawns ("+1" instead of "+0.87"). */
    val roundWholePawns: Boolean,
    /** Max engine lines shown (Multi-PV). */
    val maxLines: Int,
    /** Hide hyper-sharp sacrificial suggestions, prefer practical moves. */
    val hideSharpLines: Boolean,
    /** Verbal coaching lines ("Solid move for your level."). */
    val verbalFeedback: Boolean,
    /** Practicality chip on each move (Solid / Risky / Sharp). */
    val practicalityIndicator: Boolean,
    /** Master tier: no filtering at all, raw PV lines with exact cp. */
    val rawMode: Boolean
) {
    companion object {
        /**
         * The personalization curve.
         *  - <= 1800  Beginner/Club: rounded pawns, 1 line, sharp filtered,
         *              verbal feedback + practicality
         *  - < 2600   Advanced: raw cp, 3 lines, sharp lines tagged
         *  - >= 2600  Master: no filtering, deepest search
         */
        fun fromElo(elo: Int): EloProfile {
            val e = elo.coerceIn(100, 3000)
            return when {
                e <= 1800 -> EloProfile(
                    elo = e,
                    tier = if (e <= 1000) SkillTier.BEGINNER else SkillTier.CLUB,
                    roundWholePawns = true,
                    maxLines = 1,
                    hideSharpLines = true,
                    verbalFeedback = true,
                    practicalityIndicator = true,
                    rawMode = false
                )
                e < 2600 -> EloProfile(
                    elo = e,
                    tier = SkillTier.ADVANCED,
                    roundWholePawns = false,
                    maxLines = 3,
                    hideSharpLines = false,
                    verbalFeedback = false,
                    practicalityIndicator = false,
                    rawMode = false
                )
                else -> EloProfile(
                    elo = e,
                    tier = SkillTier.MASTER,
                    roundWholePawns = false,
                    maxLines = 3,
                    hideSharpLines = false,
                    verbalFeedback = false,
                    practicalityIndicator = false,
                    rawMode = true
                )
            }
        }

        /** Quick-select levels offered on the Elo bottom sheet. */
        val QUICK_LEVELS = listOf(100, 800, 1200, 1500, 1800, 2200, 2700)
    }
}

/** Search budgets for the analysis phases (independent of Elo — the
 *  raw scores are canonical; only DISPLAY adapts).
 *
 *  v2 overhaul pipeline (three stages):
 *   1. FIRST PASS — every position searched once at the batch budget
 *      (contempt 0, adaptive time).
 *   2. BOOK PASS — free: positions whose played move is engine-book
 *      theory get flagged and excluded from the accuracy/Elo aggregates.
 *   3. VERIFICATION PASS — every ply whose first-pass win% drop reaches
 *      [VERIFY_SUSPECT_DROP_PCT] has BOTH flanking positions re-searched
 *      at the deeper [VERIFY_DEPTH]/[VERIFY_TIME_MS] budget (the same
 *      trick the big review platforms use): eval noise at batch depth
 *      cannot fabricate the blunders that dominate the reported rating.
 */
object AnalysisBudgets {
    /**
     * Per-position budget of the batch (whole-game) review first pass.
     *
     * The budget is the accuracy-critical trade the app makes: deep
     * enough that quiet positions resolve honestly, bounded enough that
     * a 40-move game finishes in a couple of minutes on a phone. The
     * verification pass (below) then spends EXTRA time only where it
     * matters — the flagged moments — instead of blindly deepening all
     * ~80 positions.
     */
    const val BATCH_DEPTH = 18
    const val BATCH_TIME_MS = 1200L
    const val BATCH_HARD_MS = 2000L
    /** Batch review uses the engine's complexity/instability-aware time
     *  allocation (see [TimeManager] in the native engine). */
    const val BATCH_ADAPTIVE_TIME = true
    /** Never accept a batch position resolved shallower than this, even
     *  under adaptive time pressure — depth 18 is the target, but a low
     *  floor still beats an early cutoff on a hard-capped device. */
    const val BATCH_DEPTH_FLOOR = 10

    // ---- verification pass (deep re-search of flagged moments) --------

    /** Win% drop that makes a ply's flanking evals suspect (re-search). */
    const val VERIFY_SUSPECT_DROP_PCT = 8.0
    /** Deeper budget for suspect positions. The transposition table is
     *  warm from the first pass, so most verifications finish early —
     *  the soft budget is a ceiling, not a spend. */
    const val VERIFY_DEPTH = 22
    const val VERIFY_TIME_MS = 2200L
    const val VERIFY_HARD_MS = 3200L
    const val VERIFY_DEPTH_FLOOR = 12
    /** Cap on re-searched positions per game (worst suspects first). */
    const val VERIFY_MAX_POSITIONS = 20

    /** Per-position budget of the interactive deep analysis of a ply. */
    fun interactiveDepth(elo: Int): Int = if (elo >= 2600) 20 else if (elo >= 1800) 16 else 12
    fun interactiveTimeMs(elo: Int): Long = when {
        elo >= 2600 -> 15_000L
        elo >= 1800 -> 6_000L
        else -> 3_000L
    }

    /** Battery-saver duty cycle between depth iterations (native sleep). */
    const val BATCH_INTER_ITERATION_DELAY_MS = 25

    /** Hard watchdog: no single search may exceed 60 s (double safety on
     *  top of the native hardMoveTimeMs cap). */
    const val WATCHDOG_MS = 60_000L
}
