package com.tacturn.chess.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import com.tacturn.chess.R
import com.tacturn.chess.data.Prefs
import com.tacturn.chess.databinding.ActivityMainBinding
import com.tacturn.chess.ui.analysis.AnalyzeFragment
import com.tacturn.chess.ui.play.PlayFragment
import com.tacturn.chess.ui.profile.ProfileFragment

/**
 * TacTurn v1 — the app's home: a Material 3 bottom navigation with the
 * three pillars of the personalized-coach experience:
 *
 *   [♟ Play]      Play vs Engine at a calibrated Elo level
 *   [⌕ Analyze]   The flagship game review
 *   [☰ Profile]   History, personal stats, settings
 *
 * Fragments are recreated lazily per tab switch (lightweight — none of
 * them own engine sessions, so cold start stays fast and switching tabs
 * never leaks engine threads).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val playFragment by lazy { PlayFragment() }
    private val analyzeFragment by lazy { AnalyzeFragment() }
    private val profileFragment by lazy { ProfileFragment() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Apply the persisted theme choice before the content inflates.
        applyTheme(Prefs.themeMode(this))

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val savedTab = savedInstanceState?.getInt(KEY_TAB, TAB_PLAY) ?: TAB_PLAY
        if (savedInstanceState == null) {
            switchTo(savedTab)
        } else {
            binding.bottomNav.selectedItemId = navIdOf(savedTab)
        }

        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.tab_play -> { switchTo(TAB_PLAY); true }
                R.id.tab_analyze -> { switchTo(TAB_ANALYZE); true }
                R.id.tab_profile -> { switchTo(TAB_PROFILE); true }
                else -> false
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(KEY_TAB, currentTab)
    }

    private var currentTab = TAB_PLAY

    private fun switchTo(tab: Int) {
        currentTab = tab
        val fragment: Fragment = when (tab) {
            TAB_ANALYZE -> analyzeFragment
            TAB_PROFILE -> profileFragment
            else -> playFragment
        }
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    private fun navIdOf(tab: Int): Int = when (tab) {
        TAB_ANALYZE -> R.id.tab_analyze
        TAB_PROFILE -> R.id.tab_profile
        else -> R.id.tab_play
    }

    companion object {
        const val TAB_PLAY = 0
        const val TAB_ANALYZE = 1
        const val TAB_PROFILE = 2
        private const val KEY_TAB = "tab"

        /** Maps the persisted theme mode onto AppCompat night mode. */
        fun applyTheme(mode: Int) {
            AppCompatDelegate.setDefaultNightMode(
                when (mode) {
                    Prefs.THEME_MODE_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                    Prefs.THEME_MODE_DARK -> AppCompatDelegate.MODE_NIGHT_YES
                    else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
                }
            )
        }
    }
}
