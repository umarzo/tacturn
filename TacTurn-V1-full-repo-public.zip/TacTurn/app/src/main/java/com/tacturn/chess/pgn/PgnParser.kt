package com.tacturn.chess.pgn

/*
 * TacTurn v1 — lightweight PGN parser.
 *
 * Zero external dependencies (spec: no heavy libraries, keep the APK small).
 * Two stages:
 *   1. [PgnParser.parse] — a character-level state machine that strips
 *      comments {...}, recursive variations (...), NAGs $n and move
 *      numbers, collecting headers + SAN tokens + the game result.
 *   2. [PgnReplayer] — replays SAN tokens on an engine Game session,
 *      matching each token structurally against the legal-move list.
 *
 * Robustness rules (all user input is treated as hostile):
 *   - size caps: text 256 KB, tokens 600
 *   - malformed tokens never throw: replay simply stops at the first
 *     unresolvable token and reports the ply index
 *   - headers are optional; [FEN] + [SetUp "1"] select a custom start
 */

/** Thrown when the PGN text is structurally unusable (never for a merely
 *  illegal/unknown move — those stop the replay gracefully). */
class PgnParseException(message: String) : Exception(message)

/** Header map + SAN tokens + result of ONE game (the first in the text). */
data class ParsedPgn(
    val headers: Map<String, String>,
    val sanTokens: List<String>,
    val result: String?,          // "1-0" | "0-1" | "1/2-1/2" | "*" | null
    val startFen: String?         // from [FEN] + [SetUp] headers (null = standard)
)

object PgnParser {

    private const val MAX_TEXT_CHARS = 256 * 1024
    private const val MAX_TOKENS = 600

    private val HEADER_RE = Regex("""^\[(\w+)\s+"(.*)"\]\s*$""")
    private val RESULT_RE = Regex("""^(1-0|0-1|1/2-1/2|\*)$""")
    private val MOVE_NUMBER_RE = Regex("""^\d+\.*$""")
    /** Strips a leading move number like "12." or "12..." from a token. */
    private val LEADING_NUMBER_RE = Regex("""^\d+\.(\.\.)?""")

    fun parse(text: String): ParsedPgn {
        if (text.isBlank()) throw PgnParseException("empty")
        if (text.length > MAX_TEXT_CHARS) throw PgnParseException("too large")

        val headers = LinkedHashMap<String, String>()
        val tokens = ArrayList<String>(128)
        var result: String? = null

        // ---- char-level state machine over the whole text ----
        val sb = StringBuilder(32)
        var inHeaderSection = true
        var i = 0
        val n = text.length
        while (i < n) {
            val c = text[i]

            // Comments: {...} (PGN comments do not nest).
            if (c == '{') {
                i = skipUntil(text, i + 1, '}')
                flushWord(sb, tokens)
                i++
                continue
            }
            // Rest-of-line comment (PGN ";").
            if (c == ';') {
                while (i < n && text[i] != '\n') i++
                continue
            }
            // Variations: (...) — nested; also tolerate comments inside.
            if (c == '(') {
                var depth = 1
                i++
                while (i < n && depth > 0) {
                    when (text[i]) {
                        '{' -> { i = skipUntil(text, i + 1, '}') }
                        '(' -> depth++
                        ')' -> depth--
                    }
                    i++
                }
                flushWord(sb, tokens)
                continue
            }
            // Header line: [Key "Value"] — only before any movetext token.
            if (inHeaderSection && c == '[') {
                val lineEnd = text.indexOf('\n', i)
                val line = text.substring(i, if (lineEnd == -1) n else lineEnd).trim()
                val m = HEADER_RE.matchEntire(line)
                if (m != null) {
                    headers[m.groupValues[1]] = m.groupValues[2]
                }
                i = if (lineEnd == -1) n else lineEnd + 1
                continue
            }

            if (c.isWhitespace()) {
                if (inHeaderSection && tokens.isNotEmpty()) inHeaderSection = false
                val word = sb.toString().trim()
                sb.setLength(0)
                if (word.isNotEmpty()) {
                    val r = consumeWord(word, tokens)
                    if (r != null && result == null) {
                        result = r
                        // First game in a multi-game file: stop here.
                        if (tokens.isNotEmpty()) break
                    }
                }
                if (tokens.size >= MAX_TOKENS) throw PgnParseException("game too long")
                i++
                continue
            }

            sb.append(c)
            i++
        }
        // Flush the final word.
        val word = sb.toString().trim()
        if (word.isNotEmpty()) {
            consumeWord(word, tokens)?.let { if (result == null) result = it }
        }

        if (tokens.isEmpty()) throw PgnParseException("no moves found")

        val startFen = headers["FEN"]?.takeIf { fenHeaderEnabled(headers) }
        return ParsedPgn(headers, tokens, result, startFen)
    }

    /** [SetUp "1"] is the standard marker; be forgiving and accept a bare FEN. */
    private fun fenHeaderEnabled(headers: Map<String, String>): Boolean {
        val setup = headers["SetUp"] ?: return true
        return setup == "1" || setup.equals("true", ignoreCase = true)
    }

    /** One whitespace-separated word: result, bare number, or SAN token.
     *  Returns the game-result string when the word is one, else null. */
    private fun consumeWord(word: String, tokens: MutableList<String>): String? {
        if (RESULT_RE.matches(word)) return word
        if (MOVE_NUMBER_RE.matches(word)) return null

        // Strip a leading move number glued to the SAN ("1.e4", "3...Nf6").
        var w = LEADING_NUMBER_RE.replace(word, "")
        // Tolerate a repeated prefix ("1.1.e4" junk).
        if (LEADING_NUMBER_RE.containsMatchIn(w)) w = LEADING_NUMBER_RE.replace(w, "")
        w = w.ifBlank { return null }

        // NAG: $1, $14 ...
        if (w.startsWith("$") && w.drop(1).all { it.isDigit() }) return null

        tokens.add(w)
        return null
    }

    /** Flushes a partial word when a comment/variation interrupts it. */
    private fun flushWord(sb: StringBuilder, tokens: MutableList<String>) {
        val word = sb.toString().trim()
        sb.setLength(0)
        if (word.isNotEmpty()) consumeWord(word, tokens)
    }

    private fun skipUntil(text: String, from: Int, needle: Char): Int {
        var i = from
        while (i < text.length && text[i] != needle) i++
        return i
    }
}
