package com.tacturn.chess.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import com.tacturn.chess.R
import com.tacturn.chess.engine.KNIGHT

/**
 * Standalone piece icon used in dialogs, color selection and settings.
 * XML usage: <com.tacturn.chess.ui.PieceIconView app:pieceType=".." app:pieceColor=".."/>
 */
class PieceIconView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var pieceType: Int = KNIGHT
        private set
    var pieceColor: Int = 0
        private set

    init {
        context.obtainStyledAttributes(attrs, R.styleable.PieceIconView, defStyleAttr, 0).apply {
            pieceType = getInt(R.styleable.PieceIconView_pieceType, KNIGHT)
            pieceColor = getInt(R.styleable.PieceIconView_pieceColor, 0)
            recycle()
        }
    }

    fun setPiece(type: Int, color: Int) {
        pieceType = type
        pieceColor = color
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val inset = width * 0.06f
        val rect = RectF(inset, inset, width - inset, height - inset)
        // Draw at ~2x and scale down for crisp small icons.
        PieceRenderer.drawPiece(canvas, pieceType, pieceColor, rect)
    }
}
