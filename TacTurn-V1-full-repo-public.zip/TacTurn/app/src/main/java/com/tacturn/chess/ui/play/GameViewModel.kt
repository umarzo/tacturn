package com.tacturn.chess.ui.play

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tacturn.chess.data.HistoryEntry
import com.tacturn.chess.data.HistoryRepository
import com.tacturn.chess.data.Prefs
import com.tacturn.chess.engine.BLACK
import com.tacturn.chess.engine.BISHOP
import com.tacturn.chess.engine.GameResult
import com.tacturn.chess.engine.KNIGHT
import com.tacturn.chess.engine.MOVE_NONE
import com.tacturn.chess.engine.NO_PIECE
import com.tacturn.chess.engine.NO_SQUARE
import com.tacturn.chess.engine.PAWN
import com.tacturn.chess.engine.PIECE_VALUES
import com.tacturn.chess.engine.QUEEN
import com.tacturn.chess.engine.ROOK
import com.tacturn.chess.engine.Searcher
import com.tacturn.chess.engine.SearchLimits
import com.tacturn.chess.engine.SearchResult
import com.tacturn.chess.engine.WHITE
import com.tacturn.chess.engine.Game
import com.tacturn.chess.engine.isCapture
import com.tacturn.chess.engine.moveCaptured
import com.tacturn.chess.engine.moveFrom
import com.tacturn.chess.engine.movePromo
import com.tacturn.chess.engine.moveTo
import com.tacturn.chess.ui.ClockUiState
import com.tacturn.chess.ui.GameUiState
import com.tacturn.chess.ui.MoveRow
import com.tacturn.chess.ui.NoticeEvent
import com.tacturn.chess.ui.Openings
import com.tacturn.chess.ui.SoundEvent
import com.tacturn.chess.ui.SoundType
import com.tacturn.chess.ui.StatusStyle
import com.tacturn.chess.ui.UiMove
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull

/**
 * TacTurn v2 — owns the native [Game] session and serializes every mutation
 * onto ONE engine thread (a single-slot view of Dispatchers.IO), for both
 * Play-vs-Engine and Pass-&-Play modes.
 *
 * New in v2:
 *  - [GameConfig]-driven modes (Engine opponent / two local players)
 *  - [ChessClock] with Fischer increment, low-time states and flag-fall
 *    detection (a 10 Hz ticker feeds a separate [ClockUiState] flow so
 *    clock ticks never re-render the board)
 *  - the engine's own search is clock-aware: soft/hard budgets shrink with
 *    its remaining time so it can never flag itself
 *  - draw offers (mutual agreement in Pass & Play; evaluation-based
 *    accept/decline vs the engine)
 *  - opening names, auto-queen, orientation-following player rows,
 *    time-forfeit endings with the FIDE "insufficient mating material"
 *    safeguard, and PGN export with full tags + Android share support.
 *
 * Hardening (unchanged from v1):
 *  - [gameMutex] orders every engine operation, including the final close()
 *  - watchdog: every think() gets a 15 s hard native cap AND a coroutine
 *    watchdog that calls requestStop()
 *  - onCleared(): requestStop() from the calling thread, then close() on a
 *    non-cancellable scope AFTER the mutex releases
 */
class GameViewModel(application: Application) : AndroidViewModel(application) {

    /** Single-slot IO dispatcher: engine session stays single-threaded. */
    private val engineDispatcher = Dispatchers.IO.limitedParallelism(1)
    private val engineScope = CoroutineScope(SupervisorJob() + engineDispatcher)
    private val cleanupScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Watchdogs must NOT share the engine dispatcher: its single slot is
     *  occupied by the running native search, so a watchdog launched there
     *  could never fire until the search was already over. Default has
     *  spare threads and can call requestStop() mid-search. */
    private val watchdogScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var game: Game? = null
    private val gameMutex = Mutex()

    private var config = GameConfig()
    private var playerColor = WHITE
    private var orientation = WHITE
    private var thinking = false
    private var pendingPromo: Pair<Int, Int>? = null
    private var soundId = 0
    private var noticeId = 0
    private var lastEngineScore = 0
    private var engineElo = 1200
    /** TT size (log2 entries) of the current native session; 0 = none yet. */
    private var gameTtBits = 0
    private var watchdog: Job? = null
    private var autoQueen = false

    /** The chess clock; null only until the first game starts. */
    private var clock: ChessClock? = null

    /** 10 Hz clock ticker (pure reads + a dedicated flag-detection launch). */
    private var ticker: Job? = null

    /** Why a finished game ended ("time" / "agreement" / "resignation" / …). */
    private var endReason = ""

    /** Color that lost on time (-1 when not a time forfeit). */
    private var timeForfeitLoser = -1

    /** Pass & Play: color whose draw offer awaits the opponent's answer. */
    private var drawOfferFrom = -1

    /** Engine mode: earliest move count at which a new draw offer is allowed. */
    private var drawCooldownUntilMove = 0

    /** One-shot latch: the UI persists each finished game exactly once,
     *  even across rotation recreations of the Activity. */
    private var resultPersisted = false

    private val _ui = MutableStateFlow(GameUiState())
    val ui: StateFlow<GameUiState> = _ui.asStateFlow()

    private val _clockUi = MutableStateFlow(ClockUiState())
    val clockUi: StateFlow<ClockUiState> = _clockUi.asStateFlow()

    // ------------------------------------------------------------------
    // Public API (called from the UI thread)
    // ------------------------------------------------------------------

    /** Returns true if the current result was ALREADY persisted;
     *  arms the latch on first call. Call once per finished game render. */
    fun consumeResultPersistFlag(): Boolean {
        val already = resultPersisted
        resultPersisted = true
        return already
    }

    fun startGame(cfg: GameConfig) {
        config = cfg
        autoQueen = Prefs.autoQueen(getApplication())
        engineElo = cfg.engineElo.coerceIn(EloLevels.MIN_ELO, EloLevels.MAX_ELO)
        engineScope.launch {
            gameMutex.withLock {
                ensureGame()
                beginFreshGame(cfg)
            }
            maybeEngineMove()
        }
    }

    /** Same settings, brand-new game ("New" button). */
    fun newGame() {
        engineScope.launch {
            gameMutex.withLock {
                ensureGame()
                beginFreshGame(config)
            }
            maybeEngineMove()
        }
    }

    /** Rematch: engine mode swaps the player's color, Pass & Play swaps the
     *  two players — then starts fresh with everything else unchanged. */
    fun rematch() {
        engineScope.launch {
            val cfg = when (config.mode) {
                GameMode.ENGINE -> config.copy(playerColor = config.playerColor xor 1)
                GameMode.HUMAN -> config.copy(
                    whiteName = config.blackName,
                    blackName = config.whiteName
                )
            }
            gameMutex.withLock {
                ensureGame()
                config = cfg
                beginFreshGame(cfg)
            }
            maybeEngineMove()
        }
    }

    fun requestMove(from: Int, to: Int) {
        engineScope.launch {
            var applied = false
            gameMutex.withLock {
                if (thinking || pendingPromo != null) return@withLock
                val g = game ?: return@withLock
                if (g.result().isGameOver) return@withLock
                val mover = g.board.sideToMove
                if (config.mode == GameMode.ENGINE && mover != playerColor) return@withLock
                // Making a move implicitly withdraws any pending draw offer.
                drawOfferFrom = -1
                val candidates = g.findMoves(from, to)
                if (candidates.isEmpty()) return@withLock
                if (candidates.size > 1 || movePromo(candidates[0]) != 0) {
                    val auto = if (autoQueen) candidates.firstOrNull { movePromo(it) == QUEEN } else null
                    if (auto != null) {
                        applyMove(auto)
                        applied = true
                    } else {
                        pendingPromo = from to to
                        publish()
                    }
                } else {
                    applyMove(candidates[0])
                    applied = true
                }
            }
            if (applied) maybeEngineMove()
        }
    }

    fun completePromotion(promoPiece: Int) {
        engineScope.launch {
            var applied = false
            gameMutex.withLock {
                val p = pendingPromo ?: return@withLock
                pendingPromo = null
                val g = game ?: return@withLock
                val move = g.findMoves(p.first, p.second).firstOrNull { movePromo(it) == promoPiece }
                if (move != null) {
                    applyMove(move)
                    applied = true
                } else publish()
            }
            if (applied) maybeEngineMove()
        }
    }

    fun cancelPromotion() {
        engineScope.launch {
            gameMutex.withLock {
                pendingPromo = null
                publish()
            }
        }
    }

    /**
     * Undo: a full move pair vs the engine (so it is the player's turn
     * again), a single ply in Pass & Play. Clocks are NOT restored —
     * standard online-chess behavior. Time forfeits are final (no undo).
     */
    fun undo() {
        engineScope.launch {
            gameMutex.withLock {
                if (thinking || pendingPromo != null) return@withLock
                if (endReason == END_TIME || endReason == END_TIMEOUT_DRAW) return@withLock
                val g = game ?: return@withLock
                if (g.moveRecords.isEmpty()) return@withLock
                g.undo()
                if (config.mode == GameMode.ENGINE &&
                    g.moveRecords.isNotEmpty() && g.board.sideToMove != playerColor
                ) {
                    g.undo()
                }
                // The game may be revived (resign/draw agreement cleared).
                if (!g.result().isGameOver) {
                    endReason = ""
                    timeForfeitLoser = -1
                    drawOfferFrom = -1
                    clock?.setRunning(g.board.sideToMove)
                }
                lastEngineScore = 0
                publish()
            }
        }
    }

    fun flip() {
        engineScope.launch {
            gameMutex.withLock {
                orientation = orientation xor 1
                publish()
            }
        }
    }

    /**
     * Resign — mode aware:
     *  - vs the engine: the player resigns (existing v1 behavior)
     *  - Pass & Play: the side to move resigns
     */
    fun resign() {
        engineScope.launch {
            gameMutex.withLock {
                if (thinking) return@withLock
                val g = game ?: return@withLock
                if (g.result().isGameOver) return@withLock
                val loser = if (config.mode == GameMode.HUMAN) g.board.sideToMove else playerColor
                g.resign(loser xor 1)
                endReason = END_RESIGN
                timeForfeitLoser = -1
                thinking = false
                clock?.pause()
                publish(resignSound(loser))
            }
        }
    }

    /**
     * Offers a draw.
     *  - Pass & Play: sets a pending offer the opponent answers in a dialog.
     *  - vs the engine: the engine decides from the CURRENT static eval
     *    (mover POV = the offering player). It accepts when clearly worse,
     *    or in a dead-equal late endgame; otherwise it declines and a
     *    cooldown blocks re-offering for 8 plies.
     */
    fun offerDraw() {
        engineScope.launch {
            gameMutex.withLock {
                if (thinking || pendingPromo != null) return@withLock
                val g = game ?: return@withLock
                if (g.result().isGameOver || drawOfferFrom != -1) return@withLock
                val moves = g.moveRecords.size
                when (config.mode) {
                    GameMode.HUMAN -> {
                        drawOfferFrom = g.board.sideToMove
                        publish()
                    }
                    GameMode.ENGINE -> {
                        if (g.board.sideToMove != playerColor) return@withLock
                        if (moves < drawCooldownUntilMove) return@withLock
                        val evalCp = try {
                            g.evaluate()   // mover (player) POV, centipawns
                        } catch (t: Throwable) {
                            lastEngineScore
                        }
                        val accept = evalCp >= 150 ||
                                (kotlin.math.abs(evalCp) <= 40 && moves >= 40)
                        if (accept) {
                            g.agreeDraw()
                            endReason = END_AGREEMENT
                            clock?.pause()
                            publish(SoundType.DRAW)
                        } else {
                            drawCooldownUntilMove = moves + 8
                            publish(notice = "The engine declines the draw offer.")
                        }
                    }
                }
            }
        }
    }

    /** Pass & Play: the opponent accepts the pending draw offer. */
    fun acceptDraw() {
        engineScope.launch {
            gameMutex.withLock {
                if (drawOfferFrom == -1) return@withLock
                drawOfferFrom = -1
                val g = game ?: return@withLock
                if (g.result().isGameOver) return@withLock
                g.agreeDraw()
                endReason = END_AGREEMENT
                clock?.pause()
                publish(SoundType.DRAW)
            }
        }
    }

    /** Pass & Play: the opponent declines the pending draw offer. */
    fun declineDraw() {
        engineScope.launch {
            gameMutex.withLock {
                if (drawOfferFrom == -1) return@withLock
                drawOfferFrom = -1
                publish()
            }
        }
    }

    /** Freezes the running clock (app went to the background). */
    fun pauseClock() {
        engineScope.launch {
            gameMutex.withLock {
                clock?.pause()
                publishClock()
            }
        }
    }

    /** Resumes the paused clock (app came back to the foreground). */
    fun resumeClock() {
        engineScope.launch {
            gameMutex.withLock {
                val g = game
                if (g == null || !g.result().isGameOver) clock?.resume()
                publishClock()
            }
        }
    }

    /** Exports the current game as PGN — computed on the engine thread
     *  (the session may only be touched there); the result is delivered
     *  back to the caller on the main thread. */
    fun exportPgn(onReady: (String) -> Unit) {
        engineScope.launch {
            val pgn = gameMutex.withLock { exportPgnLocked() }
            android.os.Handler(android.os.Looper.getMainLooper()).post { onReady(pgn) }
        }
    }

    /**
     * Persists a finished played game to the Profile history. Runs on the
     * ViewModel scope (survives Activity recreation). Called at most once
     * per finished game via the [resultPersisted] latch owned by the UI.
     */
    fun persistPlayedGame(state: GameUiState) {
        if (state.moveCounter < 1) return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val app = getApplication<Application>()
                val vsEngine = config.mode == GameMode.ENGINE
                val entry = HistoryEntry(
                    id = "pl_${System.currentTimeMillis()}",
                    kind = "played",
                    date = System.currentTimeMillis(),
                    white = config.nameOf(WHITE),
                    black = config.nameOf(BLACK),
                    result = resultString(state.result),
                    startFen = null,
                    sanMoves = state.moveRows.flatMap { listOfNotNull(it.whiteSan, it.blackSan) },
                    engineElo = if (vsEngine) state.engineElo else null,
                    playerColor = if (vsEngine) state.playerColor else null,
                    userElo = null,
                    accuracy = null,
                    performanceElo = null,
                    reviewScores = null,
                    reviewBestMoves = null,
                    reviewDepths = null,
                    importSource = null,
                    mode = if (vsEngine) HistoryEntry.MODE_ENGINE else HistoryEntry.MODE_PVP,
                    timeControl = config.timeControl.label.takeIf { !config.timeControl.isUnlimited }
                )
                HistoryRepository(app).save(entry)
            } catch (t: Throwable) {
                Log.e("TacTurn", "persist played game failed", t)
            }
        }
    }

    // ------------------------------------------------------------------
    // Fresh-game setup (engine thread, under mutex)
    // ------------------------------------------------------------------

    private fun beginFreshGame(cfg: GameConfig) {
        val g = game!!
        g.reset()
        playerColor = cfg.playerColor
        orientation = if (cfg.mode == GameMode.HUMAN) WHITE else cfg.playerColor
        pendingPromo = null
        thinking = false
        lastEngineScore = 0
        resultPersisted = false
        endReason = ""
        timeForfeitLoser = -1
        drawOfferFrom = -1
        drawCooldownUntilMove = 0
        clock = ChessClock(cfg.timeControl)
        clock?.start()          // standard rule: White's clock runs from move one
        publish()
        publishClock()
        startTicker()
    }

    /** (Re)starts the 10 Hz clock ticker; it self-terminates on ViewModel
     *  clear via viewModelScope cancellation. */
    private fun startTicker() {
        ticker?.cancel()
        ticker = viewModelScope.launch {
            while (isActive) {
                delay(TICK_MS)
                val c = clock ?: continue
                if (!c.hasClock) continue
                // Pure reads — never blocks on the engine mutex from main.
                _clockUi.value = clockSnapshot()
                val active = c.activeSide()
                if (active != -1 && c.remaining(active) <= 0L) {
                    // Authoritative flag handling happens on the engine
                    // thread (settle + game-end under the mutex).
                    engineScope.launch { handleFlagFall() }
                }
            }
        }
    }

    /** Engine-thread flag-fall resolution (idempotent). */
    private suspend fun handleFlagFall() {
        gameMutex.withLock {
            val c = clock ?: return@withLock
            if (!c.hasClock) return@withLock
            val flagged = c.checkFlag()
            if (flagged == -1) return@withLock
            val g = game ?: return@withLock
            if (g.result().isGameOver) {
                c.pause()
                return@withLock
            }
            // Stop any in-flight search (the engine may have been thinking).
            try {
                g.requestStop()
            } catch (_: Throwable) {
            }
            val winner = flagged xor 1
            val sound: SoundType
            if (hasMatingMaterial(g, winner)) {
                g.resign(winner)          // winner "wins" — reason carried by endReason
                endReason = END_TIME
                timeForfeitLoser = flagged
                sound = if (config.mode == GameMode.ENGINE) {
                    if (winner == playerColor) SoundType.WIN else SoundType.LOSE
                } else SoundType.WIN
            } else {
                // FIDE 6.9: a flag fall is only a loss if the opponent could
                // still deliver mate — otherwise it's a draw.
                g.agreeDraw()
                endReason = END_TIMEOUT_DRAW
                timeForfeitLoser = flagged
                sound = SoundType.DRAW
            }
            pendingPromo = null
            drawOfferFrom = -1
            thinking = false
            c.pause()
            publish(sound)
            publishClock()
        }
    }

    /** FIDE "any series of legal moves" mating-material approximation:
     *  any pawn/rook/queen, or at least two minor pieces. */
    private fun hasMatingMaterial(g: Game, color: Int): Boolean {
        var minors = 0
        val b = g.board
        for (sq in 0 until 64) {
            val t = b.pieceTypeOf[sq]
            if (t == NO_PIECE || b.pieceColorOf[sq] != color) continue
            when (t) {
                PAWN, ROOK, QUEEN -> return true
                KNIGHT, BISHOP -> minors++
            }
        }
        return minors >= 2
    }

    // ------------------------------------------------------------------
    // Engine coroutine internals (already on the engine dispatcher)
    // ------------------------------------------------------------------

    /** Lazily creates the native session on first use (fast app start).
     *  The transposition table grows with the level: the 2800+ engine
     *  levels run 8-thread deep searches, so they get a 2^22-entry TT
     *  (~100 MB; the native side auto-falls back to smaller sizes on
     *  low-RAM devices). It only ever grows, and only between games —
     *  never mid-search. Pass & Play keeps the standard 2^21 (~50 MB). */
    private fun ensureGame() {
        val wantBits = if (config.mode == GameMode.ENGINE && engineElo >= 2800) 22 else 21
        if (game == null || gameTtBits < wantBits) {
            game?.close()
            game = Game(ttBits = wantBits)
            gameTtBits = wantBits
        }
    }

    private fun applyMove(move: Int) {
        val g = game ?: return
        val mover = g.board.sideToMove
        val captured = moveCaptured(move)
        g.makeMove(move)
        clock?.onMoveMade(mover)
        val result = g.result()
        if (result.isGameOver) {
            endReason = if (endReason.isEmpty()) naturalEndReason(result) else endReason
            clock?.pause()
        } else if (config.mode == GameMode.HUMAN && config.autoFlip) {
            // Pass & Play: keep the board pointed at the side to move
            // (but freeze the view once the game is over).
            orientation = g.board.sideToMove
        }

        val sound = when {
            result.isDraw -> SoundType.DRAW
            result == GameResult.WHITE_WINS || result == GameResult.BLACK_WINS ->
                if (config.mode == GameMode.HUMAN) SoundType.WIN else {
                    if ((result == GameResult.WHITE_WINS && playerColor == WHITE) ||
                        (result == GameResult.BLACK_WINS && playerColor == BLACK)
                    ) SoundType.WIN else SoundType.LOSE
                }
            g.inCheck() -> SoundType.CHECK
            captured != NO_PIECE -> SoundType.CAPTURE
            else -> SoundType.MOVE
        }

        publish(sound)
    }

    /** Reason string for games that ended by the rules (not resignation
     *  / agreement / time). */
    private fun naturalEndReason(result: GameResult): String = when (result) {
        GameResult.WHITE_WINS, GameResult.BLACK_WINS -> END_CHECKMATE
        GameResult.DRAW_STALEMATE -> END_STALEMATE
        GameResult.DRAW_FIFTY_MOVE -> END_FIFTY
        GameResult.DRAW_REPETITION -> END_REPETITION
        GameResult.DRAW_INSUFFICIENT_MATERIAL -> END_INSUFFICIENT
        else -> ""
    }

    private suspend fun maybeEngineMove() {
        val g = game ?: return
        gameMutex.withLock {
            if (config.mode == GameMode.HUMAN) return
            if (g.result().isGameOver) return
            if (g.board.sideToMove == playerColor) return

            thinking = true
            publish()

            val limits = engineLimitsFor(g)
            val minThinkMs = engineDelayBudget()
            val started = android.os.SystemClock.elapsedRealtime()

            // Opening book: weighted-random probe for variety at higher levels.
            val bookMove = if (limits.adaptiveTime) g.bookProbe() else MOVE_NONE
            val searchResult: SearchResult
            var fromBook = false
            if (bookMove != MOVE_NONE) {
                searchResult = SearchResult(bookMove, 0, 0, 0, 0, 0)
                fromBook = true
            } else {
                searchResult = thinkWithWatchdog(g, limits)
            }

            // Abort paths: no move, the game ended, or a flag fell while
            // the search ran (flag handling then ends the game).
            if (searchResult.bestMove == MOVE_NONE || g.result().isGameOver ||
                clock?.checkFlag() != -1
            ) {
                thinking = false
                publish()
                return
            }

            // The engine always takes a moment: replying instantly feels
            // broken and races the move animation.
            val elapsed = android.os.SystemClock.elapsedRealtime() - started
            val minimum = if (fromBook) minThinkMs / 2 else minThinkMs
            if (elapsed < minimum) delay(minimum - elapsed)

            thinking = false
            lastEngineScore = searchResult.score
            applyMove(searchResult.bestMove)
        }
    }

    /**
     * Elo-level search limits clamped by the engine's own remaining time,
     * so a timed game can never be lost on the engine's clock:
     *  soft budget ≈ remaining/30 + ¾ increment (capped by the level budget)
     *  hard budget ≈ remaining/10 + increment (capped by soft x2)
     */
    private fun engineLimitsFor(g: Game): SearchLimits {
        val base = EloLevels.limits(engineElo, lastEngineScore)
        val c = clock ?: return base
        if (!c.hasClock) return base
        val remaining = c.remaining(g.board.sideToMove).coerceAtLeast(0L)
        if (remaining <= 0L) return base
        val inc = c.incrementMs
        // v1.4.7: /30 -> /22 — the TimeManager already shrinks easy and
        // stable moves by 25-50% (branching, stability pacing, node
        // fraction), so a /30 base allocation caused severe clock
        // under-utilization in timed games: the engine banked reserves it
        // never spent and got out-searched by a full ply on stable moves.
        // /22 re-centers the soft allocation under the adaptive shrink.
        val soft = (remaining / 22L + (inc * 3L) / 4L)
            .coerceIn(MIN_ENGINE_THINK_MS, base.moveTimeMs)
        val hard = minOf(base.hardMoveTimeMs, remaining / 10L + inc, soft * 2L)
            .coerceAtLeast(soft)
            .coerceAtMost((remaining * 9L) / 10L + inc)
        return base.copy(
            moveTimeMs = soft,
            hardMoveTimeMs = maxOf(soft, hard),
            depthFloor = if (soft < 300L) 4 else base.depthFloor
        )
    }

    /** The cosmetic "engine is thinking" pause, capped by its clock. */
    private fun engineDelayBudget(): Long {
        val base = EloLevels.minThinkMs(engineElo)
        val c = clock ?: return base
        if (!c.hasClock) return base
        val remaining = c.remaining(playerColor xor 1).coerceAtLeast(0L)
        return if (remaining <= 0L) 0L else minOf(base, remaining / 8L).coerceAtLeast(0L)
    }

    /**
     * Runs one native search with double crash protection:
     *  1. native hardMoveTimeMs caps the search inside C++
     *  2. a coroutine watchdog calls requestStop() as a backstop — the
     *     native stop flag unwinds the search within ~2048 nodes
     * Any JNI failure returns MOVE_NONE and the game continues gracefully.
     */
    private suspend fun thinkWithWatchdog(g: Game, limits: SearchLimits): SearchResult {
        watchdog?.cancel()
        watchdog = watchdogScope.launch {
            delay(WATCHDOG_MS)
            try {
                g.requestStop()
                Log.w("TacTurn", "watchdog fired: force-stopping engine search")
            } catch (t: Throwable) {
                Log.e("TacTurn", "watchdog requestStop failed", t)
            }
        }
        try {
            return withTimeoutOrNull(WATCHDOG_MS + 2000) {
                g.think(limits) { info ->
                    _ui.update {
                        it.copy(
                            thinking = true,
                            engineInfo = "d${info.depth}  ${formatScore(info.score)}  " +
                                nodesPerSec(info.nodes, info.timeMs)
                        )
                    }
                }
            } ?: SearchResult(MOVE_NONE, 0, 0, 0, 0, 0)
        } catch (t: Throwable) {
            // JNI boundary violation / native hiccup: never crash the app.
            Log.e("TacTurn", "engine think failed, continuing without move", t)
            return SearchResult(MOVE_NONE, 0, 0, 0, 0, 0)
        } finally {
            watchdog?.cancel()
            watchdog = null
        }
    }

    private fun nodesPerSec(nodes: Long, timeMs: Long): String {
        if (timeMs <= 0) return ""
        val kn = nodes / timeMs   // nodes per ms == thousands of nodes per second
        return if (kn >= 1000) "${kn / 1000}Mn/s" else "${kn}kn/s"
    }

    // ------------------------------------------------------------------
    // Snapshot building (engine thread, under mutex)
    // ------------------------------------------------------------------

    private fun publish(
        sound: SoundType? = null,
        notice: String? = null
    ) {
        val g = game ?: return
        val b = g.board
        val boardSnapshot = List(64) { sq ->
            val type = b.pieceTypeOf[sq]
            if (type == NO_PIECE) -1 else (b.pieceColorOf[sq] shl 3) or type
        }

        val result = g.result()
        val bottomColor = orientation
        val yourTurn = !result.isGameOver && pendingPromo == null && (
                config.mode == GameMode.HUMAN || b.sideToMove == playerColor
                )
        val legal = if (yourTurn) {
            g.legalMoves().map { m ->
                UiMove(m, moveFrom(m), moveTo(m), isCapture(m), movePromo(m) != 0)
            }
        } else emptyList()

        val recs = g.moveRecords
        val lastRec = recs.lastOrNull()
        val lastFrom = lastRec?.let { moveFrom(it.move) } ?: NO_SQUARE
        val lastTo = lastRec?.let { moveTo(it.move) } ?: NO_SQUARE

        val rows = ArrayList<MoveRow>()
        var i = 0
        var number = 1
        while (i < recs.size) {
            rows.add(MoveRow(number++, recs[i].san, recs.getOrNull(i + 1)?.san))
            i += 2
        }

        // Captured strips follow the ORIENTATION: the bottom row shows what
        // the bottom-side player captured (chess.com convention).
        val capturedByBottom = ArrayList<Pair<Int, Int>>()
        val capturedByTop = ArrayList<Pair<Int, Int>>()
        var material = 0
        for ((idx, rec) in recs.withIndex()) {
            val victim = moveCaptured(rec.move)
            if (victim == NO_PIECE) continue
            val moverColor = if (idx % 2 == 0) WHITE else BLACK
            val victimColor = moverColor xor 1
            if (moverColor == bottomColor) {
                capturedByBottom.add(victim to victimColor)
                material += PIECE_VALUES[victim]
            } else {
                capturedByTop.add(victim to victimColor)
                material -= PIECE_VALUES[victim]
            }
        }

        val inCheck = g.inCheck()
        val moves = recs.size
        val status: String
        val style: StatusStyle
        val moverName = config.nameOf(b.sideToMove)
        val bottomName = config.nameOf(bottomColor)
        val topName = config.nameOf(bottomColor xor 1)
        when {
            result.isGameOver -> {
                status = gameOverText(result); style = gameOverStyle(result)
            }
            drawOfferFrom != -1 -> {
                status = "${config.nameOf(drawOfferFrom)} offers a draw"
                style = StatusStyle.THINKING
            }
            thinking -> {
                status = if (inCheck) "Thinking… you are in check" else "Engine thinking…"
                style = StatusStyle.THINKING
            }
            config.mode == GameMode.HUMAN -> {
                status = if (inCheck) "$moverName to move — check!" else "$moverName to move"
                style = if (inCheck) StatusStyle.CHECK else StatusStyle.PLAYER
            }
            yourTurn && inCheck -> { status = "Your move — check!"; style = StatusStyle.CHECK }
            else -> { status = "Your move"; style = StatusStyle.PLAYER }
        }

        val event = sound?.let { SoundEvent(++soundId, it) }
        val noticeEvent = notice?.let { NoticeEvent(++noticeId, it) }

        val tcLabel = if (config.timeControl.isUnlimited) "" else
            "${config.timeControl.label} ${config.timeControl.category.label}"

        val difficulty = when (config.mode) {
            GameMode.ENGINE -> {
                val tier = "${EloLevels.tierLabel(engineElo)} · $engineElo Elo"
                if (tcLabel.isEmpty()) tier else "$tier · ${config.timeControl.label}"
            }
            GameMode.HUMAN ->
                if (tcLabel.isEmpty()) "Pass & Play" else "Pass & Play · ${config.timeControl.label}"
        }

        _ui.value = GameUiState(
            started = true,
            board = boardSnapshot,
            playerColor = playerColor,
            orientation = orientation,
            moverColor = b.sideToMove,
            yourTurn = yourTurn,
            legalMoves = legal,
            lastFrom = lastFrom,
            lastTo = lastTo,
            checkSquare = if (inCheck) b.kingSquare(b.sideToMove) else NO_SQUARE,
            statusText = status,
            statusStyle = style,
            thinking = thinking,
            engineInfo = if (thinking) _ui.value.engineInfo else engineBadge(g),
            moveRows = rows,
            capturedByPlayer = capturedByBottom,
            capturedByEngine = capturedByTop,
            materialDiff = material,
            result = result,
            moveCounter = moves,
            soundEvent = event,
            pendingPromotion = pendingPromo,
            difficultyLabel = difficulty,
            engineElo = engineElo,
            mode = config.mode,
            timeControlLabel = tcLabel,
            openingName = Openings.name(recs.map { it.san }),
            topLabel = topName,
            bottomLabel = bottomName,
            hasClock = clock?.hasClock == true,
            drawOfferFrom = drawOfferFrom,
            canOfferDraw = !result.isGameOver && !thinking && pendingPromo == null &&
                    drawOfferFrom == -1 && moves >= drawCooldownUntilMove &&
                    // vs the engine an offer is only valid on the player's own
                    // turn — otherwise the button was tappable yet silently
                    // no-oped.
                    (config.mode == GameMode.HUMAN || b.sideToMove == playerColor),
            endReason = endReason,
            timeForfeitLoser = timeForfeitLoser,
            noticeEvent = noticeEvent
        )
    }

    /** Status text for a finished game, honoring the end reason. */
    private fun gameOverText(result: GameResult): String {
        val whiteName = config.nameOf(WHITE)
        val blackName = config.nameOf(BLACK)
        return when {
            result == GameResult.WHITE_WINS || result == GameResult.BLACK_WINS -> {
                val winner = if (result == GameResult.WHITE_WINS) whiteName else blackName
                val youWon = config.mode == GameMode.ENGINE &&
                        ((result == GameResult.WHITE_WINS && playerColor == WHITE) ||
                                (result == GameResult.BLACK_WINS && playerColor == BLACK))
                when (endReason) {
                    END_TIME -> if (youWon) "Time's up — you win!" else "$winner wins on time"
                    END_RESIGN -> if (youWon) "You win by resignation" else "$winner wins by resignation"
                    else -> if (youWon) "Checkmate — you win!" else "Checkmate — $winner wins"
                }
            }
            result.isDraw -> when {
                endReason == END_AGREEMENT -> "Draw by agreement"
                endReason == END_TIMEOUT_DRAW -> "Draw — timeout vs insufficient material"
                result == GameResult.DRAW_STALEMATE -> "Draw — stalemate"
                result == GameResult.DRAW_FIFTY_MOVE -> "Draw — fifty-move rule"
                result == GameResult.DRAW_REPETITION -> "Draw — threefold repetition"
                else -> "Draw — insufficient material"
            }
            else -> ""
        }
    }

    private fun gameOverStyle(result: GameResult): StatusStyle = when {
        result.isDraw -> StatusStyle.DRAW
        config.mode == GameMode.HUMAN -> StatusStyle.WIN
        (result == GameResult.WHITE_WINS && playerColor == WHITE) ||
                (result == GameResult.BLACK_WINS && playerColor == BLACK) -> StatusStyle.WIN
        else -> StatusStyle.LOSE
    }

    private fun resignSound(loser: Int): SoundType = when (config.mode) {
        GameMode.HUMAN -> SoundType.WIN
        GameMode.ENGINE -> if (loser == playerColor) SoundType.LOSE else SoundType.WIN
    }

    /** Clock snapshot for the dedicated clock flow (cheap — no board work). */
    private fun clockSnapshot(): ClockUiState {
        val c = clock ?: return ClockUiState()
        return ClockUiState(
            visible = c.hasClock,
            whiteMs = c.remaining(WHITE),
            blackMs = c.remaining(BLACK),
            activeColor = c.activeSide(),
            whiteLow = c.isLowTime(WHITE),
            blackLow = c.isLowTime(BLACK),
            paused = c.isPaused(),
            flaggedColor = c.flagged()
        )
    }

    private fun publishClock() {
        _clockUi.value = clockSnapshot()
    }

    /** Engine's last score from the player's point of view. */
    private fun engineBadge(g: Game): String {
        if (config.mode == GameMode.HUMAN) return ""
        if (lastEngineScore == 0 || g.moveRecords.isEmpty()) return ""
        // Engine searched with itself to move -> negate for the player POV.
        return formatScore(-lastEngineScore)
    }

    private fun formatScore(score: Int): String = when {
        score >= Searcher.MATE_BOUND -> "M${(Searcher.MATE - score + 1) / 2}"
        score <= -Searcher.MATE_BOUND -> "-M${(Searcher.MATE + score + 1) / 2}"
        else -> {
            // Locale-independent: chess scores always use a decimal point.
            val pawns = score / 100.0
            if (pawns >= 0) "+" + "%.1f".format(java.util.Locale.US, pawns)
            else "%.1f".format(java.util.Locale.US, pawns)
        }
    }

    private fun resultString(result: GameResult): String = when (result) {
        GameResult.WHITE_WINS -> "1-0"
        GameResult.BLACK_WINS -> "0-1"
        GameResult.DRAW_STALEMATE, GameResult.DRAW_FIFTY_MOVE,
        GameResult.DRAW_REPETITION, GameResult.DRAW_INSUFFICIENT_MATERIAL,
        GameResult.DRAW_AGREEMENT -> "1/2-1/2"
        GameResult.ONGOING -> "*"
    }

    // ------------------------------------------------------------------
    // PGN export
    // ------------------------------------------------------------------

    private fun exportPgnLocked(): String {
        val g = game ?: return ""
        val recs = g.moveRecords
        if (recs.isEmpty()) return ""
        val result = g.result()
        val sb = StringBuilder()
        sb.append("[Event \"${if (config.mode == GameMode.ENGINE) "TacTurn vs Engine" else "TacTurn Pass & Play"}\"]\n")
        sb.append("[Site \"TacTurn Android\"]\n")
        sb.append("[Date \"${pgnDate()}\"]\n")
        sb.append("[Round \"-\"]\n")
        sb.append("[White \"${config.nameOf(WHITE)}\"]\n")
        sb.append("[Black \"${config.nameOf(BLACK)}\"]\n")
        sb.append("[Result \"${resultString(result)}\"]\n")
        if (config.mode == GameMode.ENGINE) {
            // The Elo tag must follow the engine's actual color — the engine
            // plays the opposite side of the player.
            if (playerColor == WHITE) sb.append("[BlackElo \"$engineElo\"]\n")
            else sb.append("[WhiteElo \"$engineElo\"]\n")
        }
        if (!config.timeControl.isUnlimited) {
            sb.append("[TimeControl \"${config.timeControl.label}\"]\n")
        }
        val opening = Openings.name(recs.map { it.san })
        if (opening.isNotEmpty()) sb.append("[Opening \"$opening\"]\n")
        val termination = when (endReason) {
            END_TIME -> "time forfeit"
            END_RESIGN -> "resignation"
            END_AGREEMENT -> "agreement"
            else -> "normal"
        }
        if (result.isGameOver) sb.append("[Termination \"$termination\"]\n")
        sb.append('\n')

        var moveNumber = 1
        var i = 0
        while (i < recs.size) {
            sb.append(moveNumber).append(". ").append(recs[i].san).append(' ')
            i++
            if (i < recs.size) {
                sb.append(recs[i].san).append(' ')
                i++
            }
            moveNumber++
        }
        sb.append(resultString(result))
        return sb.toString()
    }

    private fun pgnDate(): String {
        val cal = java.util.Calendar.getInstance()
        return "%04d.%02d.%02d".format(
            cal.get(java.util.Calendar.YEAR),
            cal.get(java.util.Calendar.MONTH) + 1,
            cal.get(java.util.Calendar.DAY_OF_MONTH)
        )
    }

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    override fun onCleared() {
        val g = game
        ticker?.cancel()
        watchdog?.cancel()
        try {
            g?.requestStop()   // atomic flag: unwinds any in-flight search in ms
        } catch (t: Throwable) {
            Log.e("TacTurn", "requestStop on clear failed", t)
        }
        engineScope.cancel()
        watchdogScope.cancel()
        if (g != null) {
            // close() AFTER the mutex releases (the in-flight think holds it),
            // on a scope that is NOT being cancelled — this is the exact
            // ordering that prevents use-after-free of the native session.
            cleanupScope.launch {
                gameMutex.withLock {
                    try {
                        g.close()
                    } catch (t: Throwable) {
                        Log.e("TacTurn", "engine close failed", t)
                    }
                }
            }
        }
        super.onCleared()
    }

    companion object {
        /** Absolute cap for any single engine move (double safety). */
        private const val WATCHDOG_MS = 15_000L

        /** Clock tick period. */
        private const val TICK_MS = 100L

        /** Floor for clock-clamped engine thinking. */
        private const val MIN_ENGINE_THINK_MS = 60L

        // ---- end reasons -------------------------------------------------
        const val END_CHECKMATE = "checkmate"
        const val END_STALEMATE = "stalemate"
        const val END_FIFTY = "fifty"
        const val END_REPETITION = "repetition"
        const val END_INSUFFICIENT = "insufficient"
        const val END_TIME = "time"
        const val END_AGREEMENT = "agreement"
        const val END_RESIGN = "resignation"
        const val END_TIMEOUT_DRAW = "timeout-insufficient"
    }
}
