package com.tacturn.chess.ui.analysis

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tacturn.chess.analysis.Accuracy
import com.tacturn.chess.analysis.AnalysisBudgets
import com.tacturn.chess.analysis.AnalysisPresenter
import com.tacturn.chess.analysis.EloProfile
import com.tacturn.chess.analysis.GameReview
import com.tacturn.chess.analysis.LineModel
import com.tacturn.chess.analysis.MoveChip
import com.tacturn.chess.analysis.MoveClass
import com.tacturn.chess.analysis.PlyFacts
import com.tacturn.chess.analysis.PositionEval
import com.tacturn.chess.analysis.Practicality
import com.tacturn.chess.analysis.ScoreFormat
import com.tacturn.chess.analysis.Sharpness
import com.tacturn.chess.data.HistoryEntry
import com.tacturn.chess.data.HistoryRepository
import com.tacturn.chess.data.Prefs
import com.tacturn.chess.engine.BLACK
import com.tacturn.chess.engine.Game
import com.tacturn.chess.engine.GameResult
import com.tacturn.chess.engine.NO_PIECE
import com.tacturn.chess.engine.PvLine
import com.tacturn.chess.engine.SearchLimits
import com.tacturn.chess.engine.Searcher
import com.tacturn.chess.engine.WHITE
import com.tacturn.chess.engine.moveFrom
import com.tacturn.chess.engine.moveTo
import com.tacturn.chess.pgn.ParsedPgn
import com.tacturn.chess.pgn.PgnParseException
import com.tacturn.chess.pgn.PgnParser
import com.tacturn.chess.pgn.PgnReplayer
import com.tacturn.chess.pgn.Ply
import com.tacturn.chess.pgn.SanMatcher
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.abs

/**
 * TacTurn v1 — THE flagship: "Analyze My Game".
 *
 * Pipeline:
 *   import (PGN text / file / FEN / history)  -> replay on the engine thread
 *   -> [AnalysisPhase.NeedsElo]               -> user picks Elo (bottom sheet)
 *   -> batch review: every position searched ONCE, raw scores cached
 *   -> [AnalysisPhase.Ready]                  -> browsing + interactive Multi-PV
 *
 * Personalization is PURELY a display concern: switching Elo re-runs
 * [AnalysisPresenter] on the cached raw scores (<1 ms) — the engine never
 * re-runs (the incremental-analysis requirement).
 *
 * Engine safety (the whole crash-prevention spec):
 *  - one engine session on a single-slot Dispatchers.IO view + Mutex
 *  - [withStopOnCancel]: coroutine cancellation fires requestStop() so the
 *    native search unwinds within ~2048 nodes instead of blocking
 *  - hard native time caps + a 60 s watchdog backstop on every search
 *  - malformed PGN/FEN never crash — they surface as ImportFailed
 *  - [haltEngine] (ON_STOP) cancels jobs + stops the native search; the
 *    batch resumes from the last completed position on ON_START
 *  - engine results live in CopyOnWriteArrayLists so the UI thread can
 *    read partial results while the batch appends (no torn reads)
 */
class AnalysisViewModel(application: Application) : AndroidViewModel(application) {

    /** Single-slot IO dispatcher — the native session stays single-threaded. */
    private val engineDispatcher = Dispatchers.IO.limitedParallelism(1)
    private val engineScope = CoroutineScope(SupervisorJob() + engineDispatcher)
    private val cleanupScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Watchdogs must NOT share the engine dispatcher: its single slot is
     *  occupied by the running native search, so a watchdog launched there
     *  could never fire until the search was already over. */
    private val watchdogScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val gameMutex = Mutex()
    private var engine: Game? = null

    private val history = HistoryRepository(application)

    // ---- raw review state (Elo-independent; COW for cross-thread reads) --
    private var startFen: String = Game.START_FEN
    private var plies: List<Ply> = emptyList()                     // immutable
    private var headers: Map<String, String> = emptyMap()
    private var gameResultHeader: String? = null
    private var source: GameReview.Source = GameReview.Source.PGN_TEXT
    private var positions = CopyOnWriteArrayList<PositionEval>()
    private var swings = CopyOnWriteArrayList<Int>()               // per PLY
    private var bestSans = CopyOnWriteArrayList<String?>()         // per POSITION
    /** Per PLY: the played move was known opening theory (book). */
    private var bookFlags = CopyOnWriteArrayList<Boolean>()        // per PLY
    private var boards: List<List<Int>> = listOf(List(64) { -1 })  // immutable

    private var batchJob: Job? = null
    private var interactiveJob: Job? = null
    private var watchdogJob: Job? = null
    /** true while the board should auto-follow the running batch. */
    private var followBatch = true

    private val _ui = MutableStateFlow(AnalysisUiState())
    val ui: StateFlow<AnalysisUiState> = _ui.asStateFlow()

    private val profile: EloProfile?
        get() = _ui.value.profile

    // ------------------------------------------------------------------
    // Importing
    // ------------------------------------------------------------------

    /** PGN pasted as text. */
    fun loadFromPgnText(text: String) {
        loadInternal(text, GameReview.Source.PGN_TEXT)
    }

    /** PGN picked via SAF (content Uri). Reads + size-caps on IO. */
    fun loadFromPgnFile(uri: Uri) {
        viewModelScope.launch {
            val text = withContext(Dispatchers.IO) { readTextFromUri(uri) }
            if (text == null) {
                failImport("Could not read the selected file.")
            } else {
                loadInternal(text, GameReview.Source.PGN_FILE)
            }
        }
    }

    /** A bare FEN string — a one-position "game". */
    fun loadFromFen(fen: String) {
        engineScope.launch {
            gameMutex.withLock {
                val g = ensureEngine()
                if (!g.setFen(fen.trim())) {
                    failImport("Invalid FEN string.")
                    return@withLock
                }
                adoptImport(
                    startFen = g.fen(),
                    plies = emptyList(),
                    headers = emptyMap(),
                    result = fenResultString(g.result()),
                    source = GameReview.Source.FEN,
                    boardSnapshots = listOf(snapshotBoard(g))
                )
            }
        }
    }

    /** Loads a game previously saved by this app (instant when cached). */
    fun loadFromHistory(entryId: String) {
        val entry = history.get(entryId) ?: run {
            failImport("That game could not be found.")
            return
        }
        engineScope.launch {
            gameMutex.withLock {
                val g = ensureEngine()
                val cachedScores = entry.reviewScores
                val cachedBest = entry.reviewBestMoves
                val cachedDepths = entry.reviewDepths
                val hasCache = cachedScores != null && cachedBest != null && cachedDepths != null &&
                    cachedScores.size == entry.sanMoves.size + 1

                if (entry.startFen != null) {
                    if (!g.setFen(entry.startFen)) {
                        failImport("Stored game is corrupt.")
                        return@withLock
                    }
                } else {
                    g.reset()
                }
                val rebuilt = ArrayList<Ply>(entry.sanMoves.size)
                val snapshots = ArrayList<List<Int>>(entry.sanMoves.size + 1)
                snapshots.add(snapshotBoard(g))
                var corrupt = false
                for (san in entry.sanMoves) {
                    val before = g.fen()
                    val move = SanMatcher.match(san, g.legalMoves())
                    if (move == null) { corrupt = true; break }
                    g.makeMove(move)
                    rebuilt.add(Ply(move, san, before))
                    snapshots.add(snapshotBoard(g))
                }
                if (corrupt) {
                    failImport("Stored game is corrupt.")
                    return@withLock
                }

                startFen = entry.startFen ?: Game.START_FEN
                plies = rebuilt
                headers = mapOf("White" to entry.white, "Black" to entry.black)
                gameResultHeader = entry.result
                source = if (entry.kind == "played") GameReview.Source.PLAYED_GAME else GameReview.Source.HISTORY
                boards = snapshots
                positions = CopyOnWriteArrayList()
                swings = CopyOnWriteArrayList()
                bestSans = CopyOnWriteArrayList()
                bookFlags = CopyOnWriteArrayList()

                if (hasCache) {
                    // Instant restore: the raw engine cache is on disk.
                    for (i in cachedScores!!.indices) {
                        positions.add(PositionEval(cachedScores[i], cachedBest!![i], cachedDepths!![i]))
                        swings.add(0)
                        bestSans.add(null)
                    }
                    // One cheap pass fills the best-move SANs (display only)
                    // and the book flags (the session walks the game anyway).
                    fillBestSans(g)
                    val elo = entry.userElo ?: Prefs.userElo(getApplication())
                    applyProfile(elo)
                    val hero = entry.playerColor ?: WHITE
                    _ui.update {
                        it.copy(
                            phase = AnalysisPhase.Ready,
                            heroSide = hero,
                            userElo = elo,
                            plyCount = plies.size
                        )
                    }
                    finishBatchOnUi()
                } else {
                    adoptImport(
                        startFen = startFen,
                        plies = rebuilt,
                        headers = headers,
                        result = entry.result,
                        source = source,
                        boardSnapshots = snapshots
                    )
                }
            }
        }
    }

    private fun loadInternal(text: String, src: GameReview.Source) {
        engineScope.launch {
            val parsed: ParsedPgn = try {
                PgnParser.parse(text)
            } catch (e: PgnParseException) {
                failImport(publicParseError(e))
                return@launch
            }
            gameMutex.withLock {
                val g = ensureEngine()
                val outcome = try {
                    PgnReplayer(g).replay(parsed)
                } catch (e: PgnParseException) {
                    failImport("Invalid FEN header in the game.")
                    return@withLock
                }
                if (outcome.plies.isEmpty()) {
                    failImport("No valid chess moves were found in this game.")
                    return@withLock
                }

                // Snapshots: replay once more from the verified start FEN.
                val start = parsed.startFen ?: Game.START_FEN
                g.reset(start)
                val snapshots = ArrayList<List<Int>>(outcome.plies.size + 1)
                snapshots.add(snapshotBoard(g))
                for (p in outcome.plies) {
                    g.makeMove(p.move)
                    snapshots.add(snapshotBoard(g))
                }

                adoptImport(
                    startFen = start,
                    plies = outcome.plies,
                    headers = parsed.headers,
                    result = parsed.result,
                    source = src,
                    boardSnapshots = snapshots
                )
                if (outcome.failedAt >= 0) {
                    // Partial import: keep the game, inform the user gently.
                    _ui.update { it.copy(errorMessage = PgnReplayer.describeFailure(outcome)) }
                }
            }
        }
    }

    /** Common post-replay state adoption + "What is your current Elo?" hook. */
    private fun adoptImport(
        startFen: String,
        plies: List<Ply>,
        headers: Map<String, String>,
        result: String?,
        source: GameReview.Source,
        boardSnapshots: List<List<Int>>
    ) {
        this.startFen = startFen
        this.plies = plies
        this.headers = headers
        this.gameResultHeader = result
        this.source = source
        this.boards = boardSnapshots
        this.positions = CopyOnWriteArrayList()
        this.swings = CopyOnWriteArrayList()
        this.bestSans = CopyOnWriteArrayList()
        this.bookFlags = CopyOnWriteArrayList()

        val white = headerOrDefault(headers, "White", "White")
        val black = headerOrDefault(headers, "Black", "Black")
        _ui.value = AnalysisUiState(
            phase = AnalysisPhase.NeedsElo,
            gameTitle = "$white vs $black",
            whiteName = white,
            blackName = black,
            result = result,
            plyCount = plies.size,
            board = boardSnapshots.first(),
            selectedPly = 0,
            userElo = Prefs.userElo(getApplication()),
            heroSide = guessHeroSide(white, black)
        )
    }

    // ------------------------------------------------------------------
    // Elo + batch analysis
    // ------------------------------------------------------------------

    /** Bottom-sheet confirm: begin the whole-game review. */
    fun confirmElo(elo: Int) {
        val e = elo.coerceIn(100, 3000)
        Prefs.setUserElo(getApplication(), e)
        applyProfile(e)
        startBatch()
    }

    /** Instant re-filter on cached scores — no engine work at all. Also
     *  safe mid-batch: the running review is Elo-independent, so only the
     *  already-computed chips are re-classified. */
    fun changeElo(elo: Int) {
        val e = elo.coerceIn(100, 3000)
        Prefs.setUserElo(getApplication(), e)
        applyProfile(e)
        when (_ui.value.phase) {
            AnalysisPhase.Ready -> {
                republishPresentation()
                interactiveJob?.cancel()
                runInteractive(_ui.value.selectedPly)
            }
            AnalysisPhase.BatchRunning -> publishPartialChips()
            else -> {}
        }
    }

    fun changeHeroSide(side: Int) {
        _ui.update { it.copy(heroSide = side) }
        if (_ui.value.phase == AnalysisPhase.Ready) republishPresentation()
    }

    // ------------------------------------------------------------------
    // Browsing
    // ------------------------------------------------------------------

    fun selectPly(index: Int) {
        val clamped = index.coerceIn(0, plies.size)
        followBatch = false
        _ui.update { it.copy(selectedPly = clamped) }
        publishBoardAt(clamped)
        publishDetailAt(clamped)
        if (_ui.value.phase == AnalysisPhase.Ready) {
            interactiveJob?.cancel()
            runInteractive(clamped)
        }
    }

    fun stepPly(delta: Int) = selectPly(_ui.value.selectedPly + delta)

    fun goToStart() = selectPly(0)

    fun goToEnd() = selectPly(plies.size)

    fun flipBoard() {
        _ui.update { it.copy(orientation = it.orientation xor 1) }
        publishBoardAt(_ui.value.selectedPly)
    }

    // ------------------------------------------------------------------
    // Lifecycle: halt/resume when the UI goes away
    // ------------------------------------------------------------------

    /** ON_STOP: halt the search immediately (coroutine cancel + nativeStop). */
    fun haltEngine() {
        interactiveJob?.cancel()
        batchJob?.cancel()
        try {
            engine?.requestStop()
        } catch (t: Throwable) {
            Log.e("TacTurn", "haltEngine requestStop failed", t)
        }
    }

    /** ON_START: resume an interrupted batch + re-run the shown position. */
    fun resumeEngine() {
        if (_ui.value.phase == AnalysisPhase.BatchRunning && positions.size < plies.size + 1) {
            startBatch(resume = true)
        } else if (_ui.value.phase == AnalysisPhase.Ready) {
            runInteractive(_ui.value.selectedPly)
        }
    }

    override fun onCleared() {
        val g = engine
        watchdogJob?.cancel()
        interactiveJob?.cancel()
        batchJob?.cancel()
        try { g?.requestStop() } catch (t: Throwable) { Log.e("TacTurn", "stop on clear", t) }
        engineScope.cancel()
        watchdogScope.cancel()
        if (g != null) {
            // close() AFTER the in-flight search releases the mutex — the
            // exact ordering that prevents use-after-free of the session.
            cleanupScope.launch {
                gameMutex.withLock {
                    try { g.close() } catch (t: Throwable) { Log.e("TacTurn", "close", t) }
                }
            }
        }
        super.onCleared()
    }

    // ==================================================================
    // Internals
    // ==================================================================

    private fun ensureEngine(): Game {
        if (engine == null) {
            // 2^20 entries (~16 MB): deep enough for depth-16+ interactive
            // searches while staying light for fast app start.
            engine = Game(ttBits = 20)
        }
        return engine!!
    }

    private fun applyProfile(elo: Int) {
        _ui.update { it.copy(userElo = elo, profile = EloProfile.fromElo(elo)) }
    }

    private fun startBatch(resume: Boolean = false) {
        batchJob?.cancel()
        followBatch = true
        batchJob = viewModelScope.launch {
            val total = plies.size + 1
            _ui.update { it.copy(phase = AnalysisPhase.BatchRunning, progressTotal = total) }
            try {
                withContext(engineDispatcher) {
                    withStopOnCancel {
                        gameMutex.withLock {
                            val g = ensureEngine()
                            val from = if (resume) positions.size else 0
                            if (!resume) {
                                positions = CopyOnWriteArrayList()
                                swings = CopyOnWriteArrayList()
                                bestSans = CopyOnWriteArrayList()
                                bookFlags = CopyOnWriteArrayList()
                            }
                            gotoPositionLocked(g, from)
                            for (i in from until total) {
                                // Cooperative cancellation between positions.
                                if (!currentCoroutineContext().isActive) break

                                // Book flag: judged BEFORE the move is made (the
                                // engine's book is keyed by the CURRENT position)
                                // but APPENDED only together with the position —
                                // analyzeOne() is a suspension point, and a flag
                                // committed ahead of its position would misalign
                                // the two lists on a mid-search cancel/resume.
                                // Book moves are excluded from the accuracy/Elo
                                // aggregates: judging opening theory with a
                                // depth-18 search only measures the engine's
                                // opening taste, not the player.
                                val isBook = if (i < plies.size) g.isBookMove(plies[i].move) else false

                                val limits = SearchLimits(
                                    maxDepth = AnalysisBudgets.BATCH_DEPTH,
                                    moveTimeMs = AnalysisBudgets.BATCH_TIME_MS,
                                    hardMoveTimeMs = AnalysisBudgets.BATCH_HARD_MS,
                                    adaptiveTime = AnalysisBudgets.BATCH_ADAPTIVE_TIME,
                                    depthFloor = AnalysisBudgets.BATCH_DEPTH_FLOOR,
                                    contemptCp = 0,   // analysis truth, not play bias
                                    threads = 1,
                                    interIterationDelayMs = if (Prefs.batterySaver(getApplication()))
                                        AnalysisBudgets.BATCH_INTER_ITERATION_DELAY_MS else 0
                                )
                                val line = analyzeOne(g, limits, multiPv = 1).firstOrNull()
                                val bestMove = line?.pv?.firstOrNull() ?: 0
                                // analyze() legitimately returns no line at a TERMINAL
                                // position (checkmate/stalemate — no legal moves), which
                                // is expected and must NOT be treated as "eval unknown,
                                // assume dead equal." A fabricated 0 there corrupts the
                                // loss/accuracy of the preceding decisive move (e.g. the
                                // checkmating move itself reads as a near-blunder). Ask
                                // the game's actual result and encode the correct
                                // extreme score for whichever side is nominally "to
                                // move" at this dead position, matching the same
                                // mover-POV convention used everywhere else (mate found
                                // = large POSITIVE for the mover; mated = large
                                // NEGATIVE). A genuine timeout/error (still ONGOING with
                                // no line) is the one case a neutral 0 is the right
                                // fallback, since the position there truly is unresolved.
                                val fallbackScore = if (line == null) {
                                    // At a genuine terminal position the side with no
                                    // moves IS the mated side (whichever GameResult says
                                    // lost); a mismatch here would mean this wasn't
                                    // actually terminal (a timeout), so fall through to 0.
                                    val result = g.result()
                                    val mated = when (result) {
                                        GameResult.WHITE_WINS -> g.board.sideToMove == BLACK
                                        GameResult.BLACK_WINS -> g.board.sideToMove == WHITE
                                        else -> false
                                    }
                                    if (mated) -Searcher.MATE else 0   // draw, or an unresolved timeout
                                } else 0
                                positions.add(PositionEval(line?.score ?: fallbackScore, bestMove, line?.depth ?: 0))
                                swings.add(line?.let { Sharpness.materialGivenUp(it.pv) } ?: 0)
                                bestSans.add(
                                    if (bestMove != 0) g.sanFor(bestMove).ifBlank { null } else null
                                )
                                // Committed atomically with the position (see above).
                                if (i < plies.size) bookFlags.add(isBook)

                                // Advance the game by the played move.
                                if (i < plies.size) g.makeMove(plies[i].move)

                                // Live partial results + progress.
                                val shown = if (followBatch) minOf(i + 1, plies.size) else _ui.value.selectedPly
                                _ui.update { it.copy(progressDone = i + 1) }
                                if (followBatch) {
                                    _ui.update { it.copy(selectedPly = shown) }
                                    publishBoardAt(shown)
                                }
                                publishPartialChips()
                                publishDetailAt(shown)
                            }

                            // ---- verification pass: re-search flagged moments ----
                            // The first pass evaluates every position once at the batch
                            // budget; consecutive evals carry ±30-60 cp of search noise
                            // on a phone. A fabricated blunder (or a masked real one)
                            // would dominate the reported rating, so every ply whose
                            // win% drop reaches the suspect threshold gets BOTH flanking
                            // positions re-searched at the deeper verification budget —
                            // the same trick the big review platforms use, and the single
                            // most effective defense against "the rating is wrong".
                            if (positions.size >= plies.size + 1) {
                                verifySuspectsLocked(g)
                            }
                        }
                    }
                }
                finishBatchOnUi()
                persistAnalyzedEntry()
            } catch (e: CancellationException) {
                throw e   // paused (ON_STOP) or replaced — resume keeps state
            } catch (t: Throwable) {
                Log.e("TacTurn", "batch analysis failed", t)
                failImport("The engine hit an unexpected problem. Try again.")
            }
        }
    }

    /** Runs one multi-PV analysis of the CURRENT engine position. */
    private suspend fun analyzeOne(g: Game, limits: SearchLimits, multiPv: Int): List<PvLine> {
        watchdogJob?.cancel()
        watchdogJob = watchdogScope.launch {
            delay(AnalysisBudgets.WATCHDOG_MS)
            Log.w("TacTurn", "analysis watchdog fired: force-stopping search")
            try { g.requestStop() } catch (_: Throwable) {}
        }
        try {
            return withTimeoutOrNull(AnalysisBudgets.WATCHDOG_MS + 2000) {
                g.analyze(limits, multiPv) { info ->
                    _ui.update {
                        it.copy(
                            linesAnalyzing = true,
                            linesDepth = info.depth,
                            linesInfo = "d${info.depth}  ${formatEngineScore(info.score)}"
                        )
                    }
                }
            } ?: emptyList()
        } catch (t: Throwable) {
            Log.e("TacTurn", "analyze failed", t)
            return emptyList()
        } finally {
            watchdogJob?.cancel()
            watchdogJob = null
        }
    }

    /**
     * Wraps a block so coroutine cancellation IMMEDIATELY calls
     * requestStop() on the engine — the native search unwinds within
     * ~2048 nodes instead of blocking until its budget expires.
     */
    private suspend fun <T> withStopOnCancel(block: suspend () -> T): T = coroutineScope {
        val job = coroutineContext[Job]!!
        val handle = job.invokeOnCompletion { cause ->
            if (cause != null) {
                try { engine?.requestStop() } catch (_: Throwable) {}
            }
        }
        try {
            block()
        } finally {
            handle.dispose()
        }
    }

    /** Repositions the engine session at position [index] (caller holds mutex). */
    private fun gotoPositionLocked(g: Game, index: Int) {
        g.reset(if (startFen == Game.START_FEN) Game.START_FEN else startFen)
        val upto = index.coerceIn(0, plies.size)
        for (i in 0 until upto) g.makeMove(plies[i].move)
    }

    /**
     * The verification pass (caller holds the mutex; runs after the first
     * full pass). Re-searches the flanking positions of every flagged ply
     * at the deeper [AnalysisBudgets.VERIFY_DEPTH] budget, replacing the
     * first-pass evals. This is what stops search noise from fabricating
     * the blunders that dominate a game's reported rating — and from
     * masking real ones the batch budget couldn't see.
     */
    private suspend fun verifySuspectsLocked(g: Game) {
        val n = plies.size
        if (n == 0 || positions.size < n + 1) return

        // Suspect plies: judged (non-book) moves whose win% drop reached the
        // threshold, worst first.
        val drops = ArrayList<Pair<Int, Double>>(n)   // ply -> win% drop
        for (i in 0 until n) {
            if (bookFlags.getOrNull(i) == true) continue
            val drop = Accuracy.winDrop(positions[i].score, -positions[i + 1].score)
            if (drop >= AnalysisBudgets.VERIFY_SUSPECT_DROP_PCT) drops.add(i to drop)
        }
        if (drops.isEmpty()) return
        drops.sortByDescending { it.second }

        // Positions to re-verify: both flanks of each suspect, capped.
        val verifySet = LinkedHashSet<Int>()
        for ((ply, _) in drops) {
            if (verifySet.size >= AnalysisBudgets.VERIFY_MAX_POSITIONS) break
            verifySet.add(ply)
            verifySet.add(ply + 1)
        }
        val order = verifySet.sorted()

        val base = n + 1
        _ui.update { it.copy(progressTotal = base + order.size, progressDone = base) }
        var done = 0
        for (idx in order) {
            if (!currentCoroutineContext().isActive) break
            gotoPositionLocked(g, idx)

            // Terminal positions carry their game-result score already.
            if (g.legalMoves().isEmpty()) {
                done++
                _ui.update { it.copy(progressDone = base + done) }
                continue
            }

            val limits = SearchLimits(
                maxDepth = AnalysisBudgets.VERIFY_DEPTH,
                moveTimeMs = AnalysisBudgets.VERIFY_TIME_MS,
                hardMoveTimeMs = AnalysisBudgets.VERIFY_HARD_MS,
                adaptiveTime = true,
                depthFloor = AnalysisBudgets.VERIFY_DEPTH_FLOOR,
                contemptCp = 0,   // analysis truth
                threads = 1,
                interIterationDelayMs = if (Prefs.batterySaver(getApplication()))
                    AnalysisBudgets.BATCH_INTER_ITERATION_DELAY_MS else 0
            )
            val line = analyzeOne(g, limits, multiPv = 1).firstOrNull()
            if (line != null) {
                val bestMove = line.pv.firstOrNull() ?: 0
                positions[idx] = PositionEval(line.score, bestMove, line.depth)
                if (idx < n) swings[idx] = Sharpness.materialGivenUp(line.pv)
                bestSans[idx] = if (bestMove != 0) g.sanFor(bestMove).ifBlank { null } else null
            }
            done++
            _ui.update { it.copy(progressDone = base + done) }
            publishPartialChips()
            publishDetailAt(_ui.value.selectedPly)
        }
    }

    /** Fills bestSans (and book flags) for a restored cache (caller holds the mutex). */
    private fun fillBestSans(g: Game) {
        gotoPositionLocked(g, 0)
        for (i in 0 until plies.size + 1) {
            if (i < plies.size) bookFlags.add(g.isBookMove(plies[i].move))
            val bm = positions.getOrNull(i)?.bestMove ?: 0
            bestSans.add(if (bm != 0) g.sanFor(bm).ifBlank { null } else null)
            if (i < plies.size) g.makeMove(plies[i].move)
        }
    }

    private fun finishBatchOnUi() {
        _ui.update { it.copy(phase = AnalysisPhase.Ready, linesAnalyzing = false) }
        republishPresentation()
    }

    /** Builds the raw [GameReview] from cached data and presents it. */
    private fun republishPresentation() {
        val review = buildReview() ?: return
        val p = profile ?: return
        val hero = _ui.value.heroSide
        val presentation = AnalysisPresenter.present(review, p, hero)
        _ui.update { it.copy(presentation = presentation, moveChips = presentation.moveChips) }
        publishDetailAt(_ui.value.selectedPly)
        publishBoardAt(_ui.value.selectedPly)
    }

    private fun buildReview(): GameReview? {
        if (plies.isEmpty() || positions.size < plies.size + 1) return null
        val facts = plies.mapIndexed { i, ply ->
            // Engine scores are side-to-move POV:
            //   before = positions[i].score          (the mover's view)
            //   after  = -positions[i+1].score       (opponent to move)
            val afterCp = -positions[i + 1].score
            PlyFacts(
                loss = Accuracy.cpLoss(positions[i].score, afterCp),
                winDrop = Accuracy.winDrop(positions[i].score, afterCp),
                playedBest = ply.move == positions[i].bestMove,
                isBook = bookFlags.getOrNull(i) ?: false,
                materialSwing = swings.getOrNull(i) ?: 0
            )
        }

        // Per-side judged moves in the MOVER's POV — the input to the
        // accuracy + performance-Elo model (see Accuracy).
        val whiteEvals = ArrayList<Accuracy.MoveEval>()
        val blackEvals = ArrayList<Accuracy.MoveEval>()
        for (i in plies.indices) {
            val ev = Accuracy.MoveEval(
                beforeCp = positions[i].score,
                afterCp = -positions[i + 1].score,
                isBook = bookFlags.getOrNull(i) ?: false
            )
            if (sideToMoveAt(i) == WHITE) whiteEvals.add(ev) else blackEvals.add(ev)
        }
        val wAcc = Accuracy.gameAccuracy(whiteEvals)
        val bAcc = Accuracy.gameAccuracy(blackEvals)
        val wPerf = if (whiteEvals.isEmpty()) 0 else Accuracy.performanceElo(whiteEvals)
        val bPerf = if (blackEvals.isEmpty()) 0 else Accuracy.performanceElo(blackEvals)

        val hero = _ui.value.heroSide
        val heroMoves = plies.indices.filter { sideToMoveAt(it) == hero }
        val bestPly = heroMoves
            .filter { facts.getOrNull(it)?.playedBest == true }
            .minByOrNull { facts[it].loss }
            ?: heroMoves.minByOrNull { facts.getOrNull(it)?.loss ?: Int.MAX_VALUE }
            ?: -1

        return GameReview(
            startFen = startFen,
            plies = plies,
            headers = headers,
            result = gameResultHeader,
            positions = positions.toList(),
            plyFacts = facts,
            whiteAccuracy = wAcc,
            blackAccuracy = bAcc,
            whitePerformanceElo = wPerf,
            blackPerformanceElo = bPerf,
            bestPlyIndex = bestPly,
            source = source
        )
    }

    /** Side to move at position [i] (start FEN side + parity). */
    private fun sideToMoveAt(i: Int): Int {
        val startBlack = startFen.split(" ").getOrNull(1) == "b"
        return if (startBlack) (i + 1) % 2 else i % 2
    }

    // ---- interactive Multi-PV on the selected position -------------------

    private fun runInteractive(positionIndex: Int) {
        if (positions.size < plies.size + 1) return
        val p = profile ?: return
        interactiveJob = viewModelScope.launch {
            try {
                withContext(engineDispatcher) {
                    withStopOnCancel {
                        gameMutex.withLock {
                            val g = ensureEngine()
                            gotoPositionLocked(g, positionIndex)
                            val legal = g.legalMoves()

                            // Local engine: analyze (extra lines pre-filtered).
                            _ui.update { it.copy(linesAnalyzing = true, lines = emptyList()) }
                            val limits = SearchLimits(
                                maxDepth = AnalysisBudgets.interactiveDepth(p.elo),
                                moveTimeMs = AnalysisBudgets.interactiveTimeMs(p.elo),
                                hardMoveTimeMs = (AnalysisBudgets.interactiveTimeMs(p.elo) * 140) / 100,
                                contemptCp = 0,   // analysis truth, not play bias
                                threads = if (p.elo >= 2200) 2 else 1
                            )
                            val extra = if (p.hideSharpLines) 2 else 0
                            val rawLines = analyzeOne(g, limits, multiPv = p.maxLines + extra)
                            val models = rawLines.mapIndexed { rank, line ->
                                LineModel(
                                    rank = rank + 1,
                                    scoreText = ScoreFormat.format(line.score, p),
                                    depth = line.depth,
                                    pvSan = pvToSan(g, line.pv.take(8)),
                                    isSharp = Sharpness.isSharpLine(line.pv)
                                )
                            }
                            _ui.update {
                                it.copy(
                                    lines = AnalysisPresenter.filterLines(models, p),
                                    linesAnalyzing = false
                                )
                            }
                            publishDetailAt(positionIndex)
                        }
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                Log.e("TacTurn", "interactive analysis failed", t)
                _ui.update { it.copy(linesAnalyzing = false) }
            }
        }
    }

    /** Converts a PV of move ints to SAN strings (make/undo walk). */
    private fun pvToSan(g: Game, pv: List<Int>): List<String> {
        val out = ArrayList<String>(pv.size)
        var applied = 0
        try {
            for (m in pv) {
                val san = g.makeMove(m)
                if (san.isEmpty()) break
                out.add(san)
                applied++
            }
        } catch (t: Throwable) {
            // best-effort
        } finally {
            repeat(applied) { runCatching { g.undo() } }
        }
        return out
    }

    // ---- board/detail/chips publishing (thread-safe reads of COW lists) --

    private fun publishBoardAt(positionIndex: Int) {
        val idx = positionIndex.coerceIn(0, boards.size - 1)
        val lastPly = if (idx > 0) plies.getOrNull(idx - 1) else null
        val best = positions.getOrNull(idx)
        _ui.update {
            it.copy(
                board = boards[idx],
                lastFrom = lastPly?.let { p -> moveFrom(p.move) } ?: -1,
                lastTo = lastPly?.let { p -> moveTo(p.move) } ?: -1,
                bestFrom = best?.let { b -> if (b.bestMove != 0) moveFrom(b.bestMove) else -1 } ?: -1,
                bestTo = best?.let { b -> if (b.bestMove != 0) moveTo(b.bestMove) else -1 } ?: -1
            )
        }
    }

    private fun publishDetailAt(positionIndex: Int) {
        val p = profile ?: return
        val plyIndex = positionIndex - 1
        if (plyIndex < 0) {
            _ui.update { it.copy(detail = null) }
            return
        }
        if (positions.size < plies.size + 1) {
            _ui.update { it.copy(detail = null) }
            return
        }
        val review = buildReview() ?: return
        var detail = AnalysisPresenter.detail(review, p, plyIndex) ?: return
        val san = bestSans.getOrNull(positionIndex)
        if (san != null) detail = detail.copy(bestMoveSan = san)
        _ui.update { it.copy(detail = detail) }
    }

    /**
     * Partial chips while the batch runs (moves whose evals exist) and
     * during verification updates. ONE classification path for the whole
     * app: book -> BOOK; otherwise MoveClass.fromWinDrop on the SAME raw
     * evals the final presenter consumes — the v1 duplicate
     * (raw-cp-loss chips here vs. presenter chips there) is gone, so the
     * two views can never diverge again.
     */
    private fun publishPartialChips() {
        val p = profile ?: return
        val known = positions.size - 1     // plies with before+after evals
        if (known <= 0) return
        val count = minOf(known, plies.size)
        val chips = (0 until count).map { i ->
            val before = positions[i]
            val after = positions[i + 1]
            val afterCp = -after.score
            val drop = Accuracy.winDrop(before.score, afterCp)
            val loss = Accuracy.cpLoss(before.score, afterCp)
            val isBook = bookFlags.getOrNull(i) ?: false
            val playedBest = plies[i].move == before.bestMove
            MoveChip(
                plyIndex = i,
                number = i / 2 + 1,
                san = plies[i].san,
                isWhite = sideToMoveAt(i) == WHITE,
                moveClass = if (isBook) MoveClass.BOOK
                else MoveClass.fromWinDrop(drop, playedBest, p.elo),
                playedBest = playedBest,
                practicality = if (p.practicalityIndicator) {
                    Practicality.of(drop, swings.getOrNull(i) ?: 0)
                } else null
            )
        }
        _ui.update { it.copy(moveChips = chips) }
    }

    // ---- misc helpers -----------------------------------------------------

    private fun failImport(reason: String) {
        _ui.update { it.copy(phase = AnalysisPhase.ImportFailed, errorMessage = reason) }
    }

    /** One-shot errors are cleared after the UI shows them. */
    fun clearError() {
        _ui.update { it.copy(errorMessage = null) }
    }

    private fun publicParseError(e: PgnParseException): String = when (e.message) {
        "empty" -> "The PGN text is empty."
        "too large" -> "That game is too large to import."
        "game too long" -> "That game is too long to import."
        "no moves found" -> "No chess moves were found in this PGN."
        else -> "Invalid game format."
    }

    private fun snapshotBoard(g: Game): List<Int> = List(64) { sq ->
        val b = g.board
        val type = b.pieceTypeOf[sq]
        if (type == NO_PIECE) -1 else (b.pieceColorOf[sq] shl 3) or type
    }

    private fun headerOrDefault(headers: Map<String, String>, key: String, def: String): String =
        headers[key]?.takeIf { it.isNotBlank() } ?: def

    /** Guesses which side the user played from PGN headers. */
    private fun guessHeroSide(white: String, black: String): Int {
        val me = Prefs.userName(getApplication()).lowercase()
        val w = white.lowercase()
        val b = black.lowercase()
        return when {
            w.contains(me) || w.contains("player") || w.contains("you") -> WHITE
            b.contains(me) || b.contains("player") || b.contains("you") -> BLACK
            else -> WHITE
        }
    }

    private fun fenResultString(result: GameResult): String = when (result) {
        GameResult.WHITE_WINS -> "1-0"
        GameResult.BLACK_WINS -> "0-1"
        GameResult.DRAW_STALEMATE, GameResult.DRAW_FIFTY_MOVE,
        GameResult.DRAW_REPETITION, GameResult.DRAW_INSUFFICIENT_MATERIAL,
        GameResult.DRAW_AGREEMENT -> "1/2-1/2"
        GameResult.ONGOING -> "*"
    }

    private fun formatEngineScore(score: Int): String = when {
        score >= Searcher.MATE_BOUND -> "M${(Searcher.MATE - score + 1) / 2}"
        score <= -Searcher.MATE_BOUND -> "-M${(Searcher.MATE + score + 1) / 2}"
        else -> {
            val pawns = score / 100.0
            if (abs(pawns) < 0.005) "0.00"
            else if (pawns > 0) "+${"%.2f".format(java.util.Locale.US, pawns)}"
            else "${"%.2f".format(java.util.Locale.US, pawns)}"
        }
    }

    private fun readTextFromUri(uri: Uri): String? = try {
        val resolver = getApplication<Application>().contentResolver
        ByteArrayOutputStream().use { out ->
            resolver.openInputStream(uri)?.use { input ->
                val buf = ByteArray(64 * 1024)
                var total = 0
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_FILE_BYTES) return null
                    out.write(buf, 0, n)
                }
            } ?: return null
            out.toString("UTF-8")
        }
    } catch (t: Throwable) {
        null
    }

    // ---- persistence --------------------------------------------------------

    private fun persistAnalyzedEntry() {
        if (positions.size < plies.size + 1) return
        val review = buildReview() ?: return
        val hero = _ui.value.heroSide
        val entry = HistoryEntry(
            id = "an_${System.currentTimeMillis()}",
            kind = "analyzed",
            date = System.currentTimeMillis(),
            white = headerOrDefault(headers, "White", "White"),
            black = headerOrDefault(headers, "Black", "Black"),
            result = gameResultHeader,
            startFen = if (startFen == Game.START_FEN) null else startFen,
            sanMoves = plies.map { it.san },
            engineElo = null,
            playerColor = hero,
            userElo = _ui.value.userElo,
            accuracy = if (hero == WHITE) review.whiteAccuracy else review.blackAccuracy,
            performanceElo = if (hero == WHITE) review.whitePerformanceElo else review.blackPerformanceElo,
            reviewScores = positions.map { it.score },
            reviewBestMoves = positions.map { it.bestMove },
            reviewDepths = positions.map { it.depth },
            importSource = source.name
        )
        // Persist off the engine thread; persistence is best-effort.
        viewModelScope.launch(Dispatchers.IO) { history.save(entry) }
    }

    companion object {
        private const val MAX_FILE_BYTES = 512 * 1024
    }
}
