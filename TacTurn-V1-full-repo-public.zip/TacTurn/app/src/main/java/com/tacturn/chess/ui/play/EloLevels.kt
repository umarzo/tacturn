package com.tacturn.chess.ui.play

import com.tacturn.chess.engine.SearchLimits

/*
 * TacTurn — Elo-calibrated engine strength (Play vs Engine).
 *
 * The engine's practical ceiling is ~3000 Elo at full power (deepest
 * searches, every helper thread, longest adaptive budgets). We map the
 * user's chosen level (100..3000) onto FOUR coupled skill parameters:
 *
 *   - search depth      : tactical horizon (what the engine can see)
 *   - think time        : search effort within that horizon
 *   - root jitter (cp)  : random noise added to root scores — the main
 *                         weakener; produces human-looking slips instead of
 *                         artificial "random legal moves"
 *   - threads/adaptive  : full-strength extras, enabled only at the top
 *
 * Anchor points are tuned so each band feels like a real human league:
 *   100 -> spills pieces, misses simple threats
 *   800 -> knows piece values, blunders tactics
 *   1200 -> solid openings, occasional one-move mistakes
 *   1500 -> club player: punishes weak moves
 *   1800 -> strong club: very few gifts
 *   2200 -> expert: deep tactics, endgame technique
 *   2700 -> near-ceiling: 4 threads, full adaptive time
 *   3000 -> the engine's absolute ceiling: all 8 Lazy-SMP threads, deepest
 *           searches, the longest adaptive budget
 */

object EloLevels {

    const val MIN_ELO = 100
    const val MAX_ELO = 3000

    private data class Anchor(
        val elo: Int,
        val depth: Int,
        val timeMs: Long,
        val jitterCp: Int,
        val threads: Int,
        val adaptive: Boolean,
        val minThinkMs: Long
    )

    private val ANCHORS = listOf(
        Anchor(100, 1, 220, 260, 1, false, 400),
        Anchor(300, 2, 300, 170, 1, false, 450),
        Anchor(600, 3, 450, 105, 1, false, 500),
        Anchor(900, 4, 600, 75, 1, false, 550),
        Anchor(1200, 6, 850, 50, 1, false, 650),
        Anchor(1500, 8, 1100, 30, 1, false, 750),
        Anchor(1800, 10, 1500, 14, 1, false, 900),
        Anchor(2100, 13, 2000, 5, 2, true, 1000),
        Anchor(2400, 16, 2800, 0, 3, true, 1100),
        Anchor(2700, 22, 4000, 0, 4, true, 1200),
        Anchor(MAX_ELO, 64, 8000, 0, 8, true, 1200)
    )

    /** Search limits for the given Elo level (piecewise-linear between anchors). */
    fun limits(elo: Int, lastScore: Int = 0): SearchLimits {
        val e = elo.coerceIn(MIN_ELO, MAX_ELO)
        val (lo, hi) = neighbors(e)
        val t = if (hi.elo == lo.elo) 0.0 else (e - lo.elo).toDouble() / (hi.elo - lo.elo)

        val depth = lerp(lo.depth.toDouble(), hi.depth.toDouble(), t).toInt().coerceAtLeast(1)
        val timeMs = lerp(lo.timeMs.toDouble(), hi.timeMs.toDouble(), t).toLong().coerceAtLeast(150)
        val jitter = lerp(lo.jitterCp.toDouble(), hi.jitterCp.toDouble(), t).toInt().coerceAtLeast(0)
        val threads = if (t >= 0.5) hi.threads else lo.threads
        val adaptive = if (t >= 0.5) hi.adaptive else lo.adaptive

        return SearchLimits(
            maxDepth = depth,
            moveTimeMs = timeMs,
            hardMoveTimeMs = (timeMs * 150) / 100,     // 1.5x soft budget
            adaptiveTime = adaptive,
            depthFloor = if (adaptive) 8 else 4,
            lastScore = lastScore,
            jitterCp = jitter,
            threads = threads
        )
    }

    /** Minimum wall-clock "thinking" so replies never feel instant. */
    fun minThinkMs(elo: Int): Long {
        val e = elo.coerceIn(MIN_ELO, MAX_ELO)
        val (lo, hi) = neighbors(e)
        val t = if (hi.elo == lo.elo) 0.0 else (e - lo.elo).toDouble() / (hi.elo - lo.elo)
        return lerp(lo.minThinkMs.toDouble(), hi.minThinkMs.toDouble(), t).toLong()
    }

    fun tierLabel(elo: Int): String = when {
        elo <= 400 -> "Beginner"
        elo <= 900 -> "Casual"
        elo <= 1400 -> "Intermediate"
        elo <= 1800 -> "Club"
        elo <= 2200 -> "Expert"
        else -> "Master"
    }

    /** One-line hint under the slider, changes as the user drags. */
    fun hint(elo: Int): String = when {
        elo <= 300 -> "Learning the ropes — the engine plays gentle, human-like slips."
        elo <= 700 -> "Knows piece values; still misses two-move tactics."
        elo <= 1100 -> "Plays sensible openings and punishes loose pieces."
        elo <= 1500 -> "Solid club strength — mistakes get rare."
        elo <= 1900 -> "Strong club play: precise tactics, no free gifts."
        elo <= 2400 -> "Expert level: deep calculations and endgame technique."
        elo < MAX_ELO -> "Near the ceiling: full adaptive time and parallel search."
        else -> "The engine's full ~3000 power. Good luck."
    }

    // ---- helpers ------------------------------------------------------------

    private fun neighbors(elo: Int): Pair<Anchor, Anchor> {
        for (i in 0 until ANCHORS.size - 1) {
            if (elo >= ANCHORS[i].elo && elo <= ANCHORS[i + 1].elo) {
                return ANCHORS[i] to ANCHORS[i + 1]
            }
        }
        return ANCHORS.last() to ANCHORS.last()
    }

    private fun lerp(a: Double, b: Double, t: Double): Double = a + (b - a) * t
}
