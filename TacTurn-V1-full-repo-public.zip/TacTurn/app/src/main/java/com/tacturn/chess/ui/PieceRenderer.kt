package com.tacturn.chess.ui

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import com.tacturn.chess.engine.BISHOP
import com.tacturn.chess.engine.KING
import com.tacturn.chess.engine.KNIGHT
import com.tacturn.chess.engine.PAWN
import com.tacturn.chess.engine.QUEEN
import com.tacturn.chess.engine.ROOK

/**
 * Draws the TacTurn piece set: bold, smooth, single-mass
 * silhouettes with confident continuous curves, gradient shading, soft
 * ground shadows and minimal high-contrast detail strokes.
 *
 * Designed to read as sharp and
 * contemporary at every size — from a 24dp captured-piece icon up to a
 * full-screen board square — while keeping the exact same white/black
 * material identity (light gradient + dark outline / dark gradient + pale
 * detail lines) so it drops into every existing call site unchanged.
 *
 * Coordinates live in a 100x100 art space (0 = top-left); the caller maps
 * that onto a square of any size. All paths are built once and reused; the
 * fill gradients live in art space too, so two shaders cover everything.
 */
object PieceRenderer {

    // ---- Palette ----
    // Slightly warmer/brighter white and a cooler, deeper charcoal black than
    // Reads crisply on both light and dark board squares.
    private const val WHITE_TOP = 0xFFFFFFFF.toInt()
    private const val WHITE_BOTTOM = 0xFFE8E5DC.toInt()
    private const val WHITE_STROKE = 0xFF23262B.toInt()

    private const val BLACK_TOP = 0xFF52585F.toInt()
    private const val BLACK_BOTTOM = 0xFF1C1F24.toInt()
    private const val BLACK_STROKE = 0xFF0E1013.toInt()
    private const val BLACK_DETAIL = 0xFFCDD2D9.toInt()

    private const val SHADOW_ALPHA = 0x33000000.toInt()

    // ---- Paints (shared; colors set per draw) ----
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.4f
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }
    private val detailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.4f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = SHADOW_ALPHA
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    // ---- Gradient shaders (lazily built, one per color) ----
    private var whiteShader: Shader? = null
    private var blackShader: Shader? = null

    // ------------------------------------------------------------------
    // Piece paths (built once, reused). Art space: 100x100.
    // ------------------------------------------------------------------

    /** Single bold plinth shared by every piece — one confident mass instead of a tiered stack. */
    private val plinth = Path().apply {
        moveTo(19f, 90f)
        lineTo(81f, 90f)
        cubicTo(81f, 83.5f, 78f, 79.5f, 70f, 78.5f)
        lineTo(30f, 78.5f)
        cubicTo(22f, 79.5f, 19f, 83.5f, 19f, 90f)
        close()
    }

    // -- Pawn: one smooth teardrop head over a defined collar, no seam lines --
    private val pawnBody = Path().apply {
        moveTo(50f, 22f)
        cubicTo(59f, 22f, 66f, 29f, 66f, 38f)
        cubicTo(66f, 43.5f, 63.5f, 48.5f, 59.5f, 51.5f)
        cubicTo(62.5f, 53.5f, 64.5f, 56f, 64.5f, 59f)
        cubicTo(64.5f, 62.5f, 61.5f, 65f, 58f, 65f)
        lineTo(42f, 65f)
        cubicTo(38.5f, 65f, 35.5f, 62.5f, 35.5f, 59f)
        cubicTo(35.5f, 56f, 37.5f, 53.5f, 40.5f, 51.5f)
        cubicTo(36.5f, 48.5f, 34f, 43.5f, 34f, 38f)
        cubicTo(34f, 29f, 41f, 22f, 50f, 22f)
        close()
    }
    private val pawnCollar = Path().apply {
        moveTo(40f, 68f)
        lineTo(60f, 68f)
        cubicTo(64f, 68f, 66f, 71f, 66f, 74.5f)
        cubicTo(60f, 76.5f, 40f, 76.5f, 34f, 74.5f)
        cubicTo(34f, 71f, 36f, 68f, 40f, 68f)
        close()
    }

    // -- Rook: fused battlement mass, one confident block --
    private val rookBody = Path().apply {
        moveTo(25f, 29f)
        lineTo(25f, 16f)
        lineTo(34f, 16f); lineTo(34f, 21f); lineTo(41f, 21f); lineTo(41f, 16f)
        lineTo(59f, 16f); lineTo(59f, 21f); lineTo(66f, 21f); lineTo(66f, 16f)
        lineTo(75f, 16f)
        lineTo(75f, 29f)
        cubicTo(75f, 33f, 72.5f, 35.5f, 69f, 36.5f)
        cubicTo(72f, 45f, 71f, 58f, 68.5f, 78f)
        lineTo(31.5f, 78f)
        cubicTo(29f, 58f, 28f, 45f, 31f, 36.5f)
        cubicTo(27.5f, 35.5f, 25f, 33f, 25f, 29f)
        close()
    }
    private val rookBand = Path().apply {
        moveTo(34f, 44f)
        lineTo(66f, 44f)
    }

    // -- Bishop: fused finial ball, gentle waist, classic diagonal slit --
    private val bishopBody = Path().apply {
        moveTo(50f, 6f)
        cubicTo(53f, 6f, 55.4f, 8.3f, 55.4f, 11.2f)
        cubicTo(55.4f, 12.9f, 54.6f, 14.4f, 53.4f, 15.4f)
        cubicTo(62.5f, 21.5f, 68.5f, 30.5f, 67f, 41f)
        cubicTo(65.8f, 49.8f, 59.2f, 56.2f, 51f, 57.6f)
        lineTo(51f, 61.5f)
        cubicTo(57.8f, 63f, 62.8f, 67.5f, 65.3f, 76.5f)
        lineTo(34.7f, 76.5f)
        cubicTo(37.2f, 67.5f, 42.2f, 63f, 49f, 61.5f)
        lineTo(49f, 57.6f)
        cubicTo(40.8f, 56.2f, 34.2f, 49.8f, 33f, 41f)
        cubicTo(31.5f, 30.5f, 37.5f, 21.5f, 46.6f, 15.4f)
        cubicTo(45.4f, 14.4f, 44.6f, 12.9f, 44.6f, 11.2f)
        cubicTo(44.6f, 8.3f, 47f, 6f, 50f, 6f)
        close()
    }
    private val bishopSlit = Path().apply {
        moveTo(59f, 25f)
        cubicTo(54f, 29f, 48.5f, 34f, 42.5f, 39.5f)
    }

    // -- Knight: true horse profile — two pointed ears, dished stop, tapered
    // muzzle, defined jaw and a bold crest — same single-mass language as the
    // rest of the set. Detail strokes: crest mane, forelock, lip line.
    private val knightBody = Path().apply {
        moveTo(72.5f, 78f)
        cubicTo(76.5f, 66f, 77.5f, 52f, 73f, 40f)
        cubicTo(69.5f, 29.5f, 64f, 21.5f, 57.5f, 17f)
        lineTo(60.5f, 7.5f)
        cubicTo(57f, 10f, 54f, 12.5f, 51.5f, 15f)
        lineTo(44f, 7.5f)
        cubicTo(41f, 11.5f, 39.6f, 15.5f, 39.4f, 19.5f)
        cubicTo(34.5f, 22f, 30.8f, 25.5f, 28.3f, 30f)
        cubicTo(25.8f, 34.5f, 22.3f, 38.8f, 20.3f, 42.3f)
        cubicTo(18.3f, 45.3f, 17.8f, 47.8f, 19f, 49.8f)
        cubicTo(20.3f, 51.8f, 22.6f, 52.5f, 25f, 52f)
        cubicTo(27.8f, 54.6f, 30.6f, 55.6f, 33.6f, 54.9f)
        cubicTo(32.4f, 60f, 31.5f, 66f, 31.4f, 78f)
        close()
    }
    private val knightMane1 = Path().apply {
        // crest/mane stroke hugging the back edge
        moveTo(54.5f, 19.5f)
        cubicTo(63f, 26.5f, 67.8f, 37f, 68.3f, 52.5f)
    }
    private val knightMane2 = Path().apply {
        // forelock stroke below the front ear
        moveTo(46.8f, 18.2f)
        cubicTo(50.3f, 23f, 51.8f, 29f, 50.6f, 35.5f)
    }
    private val knightMouth = Path().apply {
        // lip-corner line under the muzzle
        moveTo(21f, 50.2f)
        cubicTo(23.4f, 51.6f, 26f, 51.7f, 28.2f, 50.6f)
    }

    // -- Queen: smooth rounded five-point coronet, no jagged spikes --
    private val queenBody = Path().apply {
        moveTo(26f, 46f)
        cubicTo(24.3f, 46f, 23f, 44.6f, 23f, 42.9f)
        cubicTo(23f, 41.6f, 23.8f, 40.4f, 25f, 39.9f)
        cubicTo(24.2f, 38.3f, 24.6f, 36.4f, 26.1f, 35.4f)
        cubicTo(27.6f, 34.4f, 29.5f, 34.7f, 30.7f, 36f)
        lineTo(35f, 26.5f)
        cubicTo(34f, 25.6f, 33.4f, 24.3f, 33.4f, 22.9f)
        cubicTo(33.4f, 20.2f, 35.6f, 18f, 38.3f, 18f)
        cubicTo(41f, 18f, 43.2f, 20.2f, 43.2f, 22.9f)
        cubicTo(43.2f, 24.1f, 42.7f, 25.3f, 42f, 26.1f)
        lineTo(46f, 38f)
        lineTo(47.7f, 17.6f)
        cubicTo(46.5f, 16.6f, 45.8f, 15.1f, 45.8f, 13.5f)
        cubicTo(45.8f, 10.5f, 48.2f, 8f, 51.2f, 8f)
        cubicTo(54.2f, 8f, 56.6f, 10.5f, 56.6f, 13.5f)
        cubicTo(56.6f, 15.1f, 55.9f, 16.6f, 54.7f, 17.6f)
        lineTo(56.4f, 38f)
        lineTo(60.4f, 26.1f)
        cubicTo(59.7f, 25.3f, 59.2f, 24.1f, 59.2f, 22.9f)
        cubicTo(59.2f, 20.2f, 61.4f, 18f, 64.1f, 18f)
        cubicTo(66.8f, 18f, 69f, 20.2f, 69f, 22.9f)
        cubicTo(69f, 24.3f, 68.4f, 25.6f, 67.4f, 26.5f)
        lineTo(71.7f, 36f)
        cubicTo(72.9f, 34.7f, 74.8f, 34.4f, 76.3f, 35.4f)
        cubicTo(77.8f, 36.4f, 78.2f, 38.3f, 77.4f, 39.9f)
        cubicTo(78.6f, 40.4f, 79.4f, 41.6f, 79.4f, 42.9f)
        cubicTo(79.4f, 44.6f, 78.1f, 46f, 76.4f, 46f)
        lineTo(71f, 52f)
        lineTo(29f, 52f)
        close()
    }
    private val queenSkirt = Path().apply {
        moveTo(32f, 55f)
        lineTo(68f, 55f)
        cubicTo(66f, 62f, 68f, 69f, 70f, 76f)
        cubicTo(60f, 78.5f, 40f, 78.5f, 30f, 76f)
        cubicTo(32f, 69f, 34f, 62f, 32f, 55f)
        close()
    }
    private val queenBand = Path().apply {
        moveTo(39f, 65f)
        lineTo(61f, 65f)
    }

    // -- King: crown fused directly to the cross, flatter dome distinguishes it from the bishop --
    private val kingBody = Path().apply {
        moveTo(46.5f, 5f); lineTo(53.5f, 5f); lineTo(53.5f, 12.5f); lineTo(60f, 12.5f); lineTo(60f, 19f)
        lineTo(53.5f, 19f); lineTo(53.5f, 26f)
        cubicTo(62f, 27.3f, 68.5f, 34f, 69.5f, 43f)
        lineTo(72f, 52f)
        lineTo(28f, 52f)
        lineTo(30.5f, 43f)
        cubicTo(31.5f, 34f, 38f, 27.3f, 46.5f, 26f)
        lineTo(46.5f, 19f)
        lineTo(40f, 19f); lineTo(40f, 12.5f); lineTo(46.5f, 12.5f)
        close()
    }
    // King's lower body/skirt mirrors the queen's for a matching regal
    // silhouette; kept as a separate Path instance so each piece can evolve
    // independently later without cross-coupling.
    private val kingSkirt = Path().apply {
        moveTo(32f, 55f)
        lineTo(68f, 55f)
        cubicTo(66f, 62f, 68f, 69f, 70f, 76f)
        cubicTo(60f, 78.5f, 40f, 78.5f, 30f, 76f)
        cubicTo(32f, 69f, 34f, 62f, 32f, 55f)
        close()
    }
    private val kingBrow = Path().apply {
        moveTo(33f, 44f)
        cubicTo(41f, 38f, 50f, 36f, 59f, 38f)
    }
    private val kingBand = Path().apply {
        moveTo(39f, 65f)
        lineTo(61f, 65f)
    }

    // ------------------------------------------------------------------
    // Public drawing API (unchanged signatures — every call site keeps working)
    // ------------------------------------------------------------------

    /**
     * Draws a piece of [type] and [color] centered inside [rect].
     * [elevated] adds a stronger shadow (used for the dragged piece).
     */
    fun drawPiece(c: Canvas, type: Int, color: Int, rect: RectF, elevated: Boolean = false) {
        drawPiece(c, type, color, rect.left, rect.top, rect.width(), elevated)
    }

    /**
     * Draws a piece of [type]/[color] with its 100x100 art space mapped onto
     * the square whose top-left is ([left],[top]) with side [size].
     */
    fun drawPiece(
        c: Canvas, type: Int, color: Int, left: Float, top: Float, size: Float,
        elevated: Boolean = false
    ) {
        val scale = size / 100f
        val white = color == 0

        if (white) {
            if (whiteShader == null) {
                whiteShader = LinearGradient(
                    0f, 0f, 0f, 100f, WHITE_TOP, WHITE_BOTTOM, Shader.TileMode.CLAMP
                )
            }
            fillPaint.shader = whiteShader
            strokePaint.color = WHITE_STROKE
            detailPaint.color = WHITE_STROKE
        } else {
            if (blackShader == null) {
                blackShader = LinearGradient(
                    0f, 0f, 0f, 100f, BLACK_TOP, BLACK_BOTTOM, Shader.TileMode.CLAMP
                )
            }
            fillPaint.shader = blackShader
            strokePaint.color = BLACK_STROKE
            detailPaint.color = BLACK_DETAIL
        }
        dotPaint.color = if (white) WHITE_STROKE else BLACK_DETAIL

        c.save()
        c.translate(left, top)
        c.scale(scale, scale)

        // Ground shadow (silhouette offset down) — softer and slightly wider
        // for a contemporary, floating feel.
        c.save()
        c.translate(0f, if (elevated) 6f else 3.2f)
        shadowPaint.alpha = if (elevated) 0x4A else 0x30
        paintShape(c, type, shadowPaint, null, null)
        c.restore()

        // Fill + outline + details.
        paintShape(c, type, fillPaint, strokePaint, detailPaint)

        c.restore()
    }

    private fun paintShape(c: Canvas, type: Int, fill: Paint, stroke: Paint?, detail: Paint?) {
        fun p(path: Path) {
            c.drawPath(path, fill)
            stroke?.let { c.drawPath(path, it) }
        }

        when (type) {
            PAWN -> {
                p(pawnBody)
                p(pawnCollar)
                p(plinth)
            }
            KNIGHT -> {
                p(knightBody)
                p(plinth)
                if (detail != null) {
                    c.drawPath(knightMane1, detail)
                    c.drawPath(knightMane2, detail)
                    c.drawPath(knightMouth, detail)
                    c.drawCircle(35.2f, 27.8f, 2.3f, dotPaint)   // eye
                    c.drawCircle(24.2f, 45f, 1.6f, dotPaint)     // nostril
                }
            }
            BISHOP -> {
                p(bishopBody)
                p(plinth)
                if (detail != null) c.drawPath(bishopSlit, detail)
            }
            ROOK -> {
                p(rookBody)
                p(plinth)
                if (detail != null) c.drawPath(rookBand, detail)
            }
            QUEEN -> {
                p(queenBody)
                p(queenSkirt)
                p(plinth)
                if (detail != null) c.drawPath(queenBand, detail)
            }
            KING -> {
                p(kingBody)
                p(kingSkirt)
                p(plinth)
                if (detail != null) {
                    c.drawPath(kingBrow, detail)
                    c.drawPath(kingBand, detail)
                }
            }
        }
    }

    /** Dominant piece color — handy for tinting. */
    fun pieceFillColor(color: Int): Int = if (color == 0) Color.WHITE else BLACK_BOTTOM
}
