package com.tacturn.chess.data

import android.content.Context
import android.content.SharedPreferences

/*
 * TacTurn v1 — settings storage (SharedPreferences, no DataStore to keep
 * the dependency set unchanged and the APK small).
 */

object Prefs {
    private const val FILE = "tacturn_prefs"

    // keys
    private const val KEY_ENGINE_ELO = "engine_elo"          // Play vs Engine difficulty
    private const val KEY_USER_ELO = "user_elo"              // analysis personalization
    private const val KEY_SOUND = "sound_enabled"
    private const val KEY_BOARD_THEME = "board_theme"
    private const val KEY_THEME_MODE = "theme_mode"          // 0 system, 1 light, 2 dark
    private const val KEY_LAST_COLOR = "last_color"
    private const val KEY_BATTERY_SAVER = "battery_saver"
    private const val KEY_USER_NAME = "user_name"

    // v2 keys
    private const val KEY_LAST_GAME_MODE = "last_game_mode"  // 0 engine, 1 pass & play
    private const val KEY_LAST_TC_INDEX = "last_tc_index"    // TimeControl.PRESETS index
    private const val KEY_PVP_WHITE_NAME = "pvp_white_name"
    private const val KEY_PVP_BLACK_NAME = "pvp_black_name"
    private const val KEY_PVP_AUTO_FLIP = "pvp_auto_flip"
    private const val KEY_AUTO_QUEEN = "auto_queen"
    private const val KEY_HAPTICS = "haptics"
    private const val KEY_CUSTOM_TC_MINUTES = "custom_tc_minutes"
    private const val KEY_CUSTOM_TC_INC = "custom_tc_inc"

    // legacy difficulty constants
    const val THEME_RED = 0
    const val THEME_WOOD = 1
    const val THEME_SLATE = 2
    const val THEME_EMERALD = 3

    const val THEME_MODE_SYSTEM = 0
    const val THEME_MODE_LIGHT = 1
    const val THEME_MODE_DARK = 2

    private fun prefs(context: Context): SharedPreferences =
        context.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ---- Play vs Engine ---------------------------------------------------

    fun engineElo(context: Context): Int =
        prefs(context).getInt(KEY_ENGINE_ELO, 1200).coerceIn(100, 3000)

    fun setEngineElo(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_ENGINE_ELO, value.coerceIn(100, 3000)).apply()
    }

    // ---- Analysis personalization -----------------------------------------

    fun userElo(context: Context): Int =
        prefs(context).getInt(KEY_USER_ELO, 1200).coerceIn(100, 3000)

    fun setUserElo(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_USER_ELO, value.coerceIn(100, 3000)).apply()
    }

    // ---- misc -------------------------------------------------------------

    fun soundEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SOUND, true)

    fun setSoundEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_SOUND, value).apply()
    }

    fun boardTheme(context: Context): Int =
        prefs(context).getInt(KEY_BOARD_THEME, THEME_EMERALD)

    fun setBoardTheme(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_BOARD_THEME, value).apply()
    }

    fun themeMode(context: Context): Int =
        prefs(context).getInt(KEY_THEME_MODE, THEME_MODE_SYSTEM)

    fun setThemeMode(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_THEME_MODE, value).apply()
    }

    fun lastColor(context: Context): Int =
        prefs(context).getInt(KEY_LAST_COLOR, 0)   // 0 = white

    fun setLastColor(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_LAST_COLOR, value).apply()
    }

    // ---- v2: game setup ---------------------------------------------------

    /** Last used game mode on the Play tab (0 = engine, 1 = pass & play). */
    fun lastGameMode(context: Context): Int =
        prefs(context).getInt(KEY_LAST_GAME_MODE, 0)

    fun setLastGameMode(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_LAST_GAME_MODE, value).apply()
    }

    /** Index into [com.tacturn.chess.ui.play.TimeControl.PRESETS]. */
    fun lastTimeControlIndex(context: Context): Int =
        prefs(context).getInt(KEY_LAST_TC_INDEX, 0)

    fun setLastTimeControlIndex(context: Context, value: Int) {
        prefs(context).edit().putInt(KEY_LAST_TC_INDEX, value).apply()
    }

    /** Last custom time control (used when lastTimeControlIndex == -1). */
    fun customTcMinutes(context: Context): Int =
        prefs(context).getInt(KEY_CUSTOM_TC_MINUTES, 5)

    fun customTcIncrement(context: Context): Int =
        prefs(context).getInt(KEY_CUSTOM_TC_INC, 3)

    fun setCustomTc(context: Context, minutes: Int, incrementSeconds: Int) {
        prefs(context).edit()
            .putInt(KEY_CUSTOM_TC_MINUTES, minutes)
            .putInt(KEY_CUSTOM_TC_INC, incrementSeconds)
            .apply()
    }

    fun pvpWhiteName(context: Context): String =
        prefs(context).getString(KEY_PVP_WHITE_NAME, null)?.takeIf { it.isNotBlank() } ?: "White"

    fun setPvpWhiteName(context: Context, value: String) {
        prefs(context).edit().putString(KEY_PVP_WHITE_NAME, cleanName(value, "White")).apply()
    }

    fun pvpBlackName(context: Context): String =
        prefs(context).getString(KEY_PVP_BLACK_NAME, null)?.takeIf { it.isNotBlank() } ?: "Black"

    fun setPvpBlackName(context: Context, value: String) {
        prefs(context).edit().putString(KEY_PVP_BLACK_NAME, cleanName(value, "Black")).apply()
    }

    fun pvpAutoFlip(context: Context): Boolean =
        prefs(context).getBoolean(KEY_PVP_AUTO_FLIP, true)

    fun setPvpAutoFlip(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_PVP_AUTO_FLIP, value).apply()
    }

    /** Promotions become queens without showing the picker. */
    fun autoQueen(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_QUEEN, false)

    fun setAutoQueen(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_QUEEN, value).apply()
    }

    /** Light vibration feedback on moves / captures / results. */
    fun hapticsEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_HAPTICS, true)

    fun setHapticsEnabled(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_HAPTICS, value).apply()
    }

    private fun cleanName(raw: String, fallback: String): String {
        val clean = raw.trim().take(18)
        return if (clean.isEmpty()) fallback else clean
    }

    fun batterySaver(context: Context): Boolean =
        prefs(context).getBoolean(KEY_BATTERY_SAVER, true)

    fun setBatterySaver(context: Context, value: Boolean) {
        prefs(context).edit().putBoolean(KEY_BATTERY_SAVER, value).apply()
    }

    fun userName(context: Context): String =
        prefs(context).getString(KEY_USER_NAME, "You") ?: "You"

    fun setUserName(context: Context, value: String) {
        val clean = value.trim().take(24).ifBlank { "You" }
        prefs(context).edit().putString(KEY_USER_NAME, clean).apply()
    }
}
