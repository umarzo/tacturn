package com.tacturn.chess.ui

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.View.MeasureSpec
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import com.tacturn.chess.engine.BLACK
import com.tacturn.chess.engine.KING
import com.tacturn.chess.engine.NO_SQUARE
import com.tacturn.chess.engine.WHITE
import kotlin.math.abs
import kotlin.math.min

/** One legal move as presented to the board (mirrors engine move fields). */
data class BoardTarget(val from: Int, val to: Int, val isCapture: Boolean, val isPromotion: Boolean)

/**
 * The chess board: Canvas-rendered squares, pieces, highlights and hints.
 *
 * Visual upgrades over v1:
 *  - a crisp frame ring around the board (theme colored)
 *  - rounded, soft-edged last-move and selection highlights
 *  - a pulsing glow on the checked king
 *  - smaller, cleaner legal-move hints
 *  - a fourth board theme (Emerald)
 *
 * Interaction model:
 *  - Tap an own piece -> selects it and shows legal targets (dots / rings).
 *  - Tap a target square -> plays the move.
 *  - Drag a piece and drop it on a target square -> plays the move.
 *
 * The view is render-only + input; all game logic lives in [GameViewModel].
 */
class ChessBoardView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        /** light, dark, lastMove overlay, selected overlay, check fill/ring, coords, frame. */
        class BoardTheme(
            val light: Int, val dark: Int,
            val lastMove: Int, val selected: Int,
            val checkFill: Int, val checkRing: Int,
            val coordDark: Int, val coordLight: Int,
            val frame: Int
        )

        val THEMES = listOf(
            BoardTheme(                                   // TacTurn Red
                0xFFFFF6F6.toInt(), 0xFFE45050.toInt(),
                0x59FFC800.toInt(), 0x8CFFC800.toInt(),
                0x59E53935.toInt(), 0xD6E53935.toInt(),
                0x66FFFFFF.toInt(), 0x47000000.toInt(),
                0xFFC23A3A.toInt()
            ),
            BoardTheme(                                   // Classic Wood
                0xFFF0D9B5.toInt(), 0xFFB58863.toInt(),
                0x73F7EC5B.toInt(), 0x99E8C34A.toInt(),
                0x59E53935.toInt(), 0xCCC0392B.toInt(),
                0x66F0D9B5.toInt(), 0x47503C2D.toInt(),
                0xFF7D5A44.toInt()
            ),
            BoardTheme(                                   // Minimal Slate
                0xFFE8E8E8.toInt(), 0xFF9AA0A5.toInt(),
                0x59FFC800.toInt(), 0x8CFFC800.toInt(),
                0x59E53935.toInt(), 0xCCE53935.toInt(),
                0x66FFFFFF.toInt(), 0x47000000.toInt(),
                0xFF6D7278.toInt()
            ),
            BoardTheme(                                   // Emerald
                0xFFEEEED2.toInt(), 0xFF6E9B57.toInt(),
                0x73F7D774.toInt(), 0x99DCC26A.toInt(),
                0x59E53935.toInt(), 0xCCE23A3A.toInt(),
                0x99EEEED2.toInt(), 0x47302B20.toInt(),
                0xFF51713F.toInt()
            )
        )

        private const val ANIM_MS = 200L
        private const val PULSE_MS = 700L
    }

    /** piece code per square: -1 empty, else color*8 + type. */
    private var squares: IntArray = IntArray(64) { -1 }
    private var lastBoardCopy: IntArray = IntArray(64) { -1 }

    private var orientation = WHITE
    private var playerColor = WHITE
    private var inputEnabled = false
    private var targets: List<BoardTarget> = emptyList()

    private var lastFrom = NO_SQUARE
    private var lastTo = NO_SQUARE
    private var checkSquare = NO_SQUARE
    private var selectedSq = NO_SQUARE
    private var themeIndex = 0

    var onMoveAttempt: ((from: Int, to: Int) -> Unit)? = null

    // optional engine best-move arrow (from -> to), drawn on top.
    private var arrow: Pair<Int, Int>? = null

    /** Shows (or clears) the engine's best-move arrow for the current position. */
    fun setBestMoveArrow(arrow: Pair<Int, Int>?) {
        this.arrow = arrow
        invalidate()
    }

    // Drag state.
    private var dragCandidateSq = NO_SQUARE
    private var dragCandidateValid = false
    private var dragging = false
    private var dragX = 0f
    private var dragY = 0f
    private var downX = 0f
    private var downY = 0f
    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop

    // Move animation.
    private var anim: MoveAnim? = null
    private var animator: ValueAnimator? = null

    // Check pulse animation (0..1 while the king is in check).
    private var pulse = 0f
    private var pulseAnimator: ValueAnimator? = null

    private class MoveAnim(
        val piece: Int, val from: Int, val to: Int,
        val rookPiece: Int, val rookFrom: Int, val rookTo: Int
    ) {
        var t = 0f
    }

    // Paints.
    private val squarePaint = Paint()
    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val coordPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 24f
    }

    // ------------------------------------------------------------------
    // State injection
    // ------------------------------------------------------------------

    fun setPosition(
        squares: IntArray,
        targets: List<BoardTarget>,
        lastFrom: Int,
        lastTo: Int,
        checkSquare: Int,
        orientation: Int,
        playerColor: Int,
        inputEnabled: Boolean,
        themeIndex: Int
    ) {
        val boardChanged = !squares.contentEquals(lastBoardCopy)
        this.squares = squares.copyOf()
        lastBoardCopy = squares.copyOf()
        this.targets = targets
        this.lastFrom = lastFrom
        this.lastTo = lastTo
        this.checkSquare = checkSquare
        this.orientation = orientation
        this.playerColor = playerColor
        this.inputEnabled = inputEnabled
        this.themeIndex = themeIndex
        if (boardChanged) selectedSq = NO_SQUARE
        dragging = false
        dragCandidateSq = NO_SQUARE
        updatePulse()
        invalidate()
    }

    /** Starts/stops the check glow so it only runs when a king is in check. */
    private fun updatePulse() {
        val active = checkSquare != NO_SQUARE
        if (active && pulseAnimator == null) {
            pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = PULSE_MS
                repeatMode = ValueAnimator.REVERSE
                repeatCount = ValueAnimator.INFINITE
                interpolator = DecelerateInterpolator()
                addUpdateListener {
                    pulse = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else if (!active) {
            pulseAnimator?.cancel()
            pulseAnimator = null
            pulse = 0f
        }
    }

    override fun onDetachedFromWindow() {
        pulseAnimator?.cancel()
        animator?.cancel()
        super.onDetachedFromWindow()
    }

    /** Animates the piece travel for the most recent move (call after setPosition). */
    fun animateLastMove(onDone: (() -> Unit)? = null) {
        if (lastFrom == NO_SQUARE || lastTo == NO_SQUARE) return
        val piece = squares[lastTo]
        if (piece < 0) return
        var rookFrom = NO_SQUARE
        var rookTo = NO_SQUARE
        var rookPiece = -1
        if ((piece and 7) == KING && abs(lastFrom - lastTo) == 2) {
            // Castling: the rook travels too.
            if (lastTo > lastFrom) {
                rookFrom = lastTo + 1; rookTo = lastTo - 1
            } else {
                rookFrom = lastTo - 2; rookTo = lastTo + 1
            }
            rookPiece = squares[rookTo]
        }
        anim = MoveAnim(piece, lastFrom, lastTo, rookPiece, rookFrom, rookTo)
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ANIM_MS
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                anim?.t = it.animatedValue as Float
                invalidate()
            }
            addListener(object : android.animation.Animator.AnimatorListener {
                override fun onAnimationStart(a: android.animation.Animator) {}
                override fun onAnimationRepeat(a: android.animation.Animator) {}
                override fun onAnimationCancel(a: android.animation.Animator) {}
                override fun onAnimationEnd(a: android.animation.Animator) {
                    anim = null
                    invalidate()
                    onDone?.invoke()
                }
            })
            start()
        }
    }

    // ------------------------------------------------------------------
    // Geometry
    // ------------------------------------------------------------------

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        val h = MeasureSpec.getSize(heightSpec)
        val size = when {
            MeasureSpec.getMode(widthSpec) == MeasureSpec.EXACTLY &&
                    MeasureSpec.getMode(heightSpec) == MeasureSpec.EXACTLY -> min(w, h)
            MeasureSpec.getMode(widthSpec) == MeasureSpec.EXACTLY -> w
            MeasureSpec.getMode(heightSpec) == MeasureSpec.EXACTLY -> h
            else -> min(w, h)
        }
        setMeasuredDimension(size, size)
    }

    private val cell: Float get() = width / 8f

    /** board square -> screen row/col honoring orientation. */
    private fun rowOf(sq: Int): Int = if (orientation == WHITE) 7 - (sq shr 3) else (sq shr 3)
    private fun colOf(sq: Int): Int = if (orientation == WHITE) sq and 7 else 7 - (sq and 7)

    private fun squareAt(x: Float, y: Float): Int {
        val col = (x / cell).toInt()
        val row = (y / cell).toInt()
        if (row < 0 || row > 7 || col < 0 || col > 7) return NO_SQUARE
        return if (orientation == WHITE) (7 - row) * 8 + col else row * 8 + (7 - col)
    }

    private fun cellRect(row: Int, col: Int, r: RectF) {
        r.set(col * cell, row * cell, (col + 1) * cell, (row + 1) * cell)
    }

    private val tmpRect = RectF()

    // ------------------------------------------------------------------
    // Input
    // ------------------------------------------------------------------

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (animator?.isRunning == true) return true

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                val sq = squareAt(event.x, event.y)
                dragCandidateSq = sq
                dragCandidateValid = sq != NO_SQUARE && isOwnPiece(sq) && inputEnabled
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragCandidateValid) {
                    if (!dragging && (abs(event.x - downX) > touchSlop || abs(event.y - downY) > touchSlop)) {
                        dragging = true
                        selectedSq = dragCandidateSq
                    }
                    if (dragging) {
                        dragX = event.x; dragY = event.y
                        invalidate()
                    }
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                handleUp(squareAt(event.x, event.y))
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                dragCandidateSq = NO_SQUARE
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun handleUp(target: Int) {
        val wasDragging = dragging
        dragging = false
        val candidate = dragCandidateSq
        dragCandidateSq = NO_SQUARE

        if (wasDragging) {
            when {
                target == candidate -> { /* dropped in place: keep selection */ }
                target != NO_SQUARE && hasTarget(candidate, target) -> {
                    onMoveAttempt?.invoke(candidate, target)
                    selectedSq = NO_SQUARE
                }
                target != NO_SQUARE && isOwnPiece(target) -> selectedSq = target
                else -> selectedSq = NO_SQUARE
            }
        } else {
            if (selectedSq != NO_SQUARE) {
                when {
                    target == selectedSq -> selectedSq = NO_SQUARE   // toggle off
                    target != NO_SQUARE && hasTarget(selectedSq, target) -> {
                        onMoveAttempt?.invoke(selectedSq, target)
                        selectedSq = NO_SQUARE
                    }
                    target != NO_SQUARE && isOwnPiece(target) -> selectedSq = target
                    else -> selectedSq = NO_SQUARE
                }
            } else if (candidate != NO_SQUARE && dragCandidateValid) {
                selectedSq = candidate
            }
        }
    }

    private fun isOwnPiece(sq: Int): Boolean {
        if (sq == NO_SQUARE) return false
        val v = squares[sq]
        if (v < 0) return false
        return (v shr 3) == playerColor
    }

    private fun hasTarget(from: Int, to: Int): Boolean =
        targets.any { it.from == from && it.to == to }

    // ------------------------------------------------------------------
    // Drawing
    // ------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val theme = THEMES[themeIndex.coerceIn(THEMES.indices)]

        // Squares + static overlays.
        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val sq = if (orientation == WHITE) (7 - row) * 8 + col else row * 8 + (7 - col)
                val dark = ((sq shr 3) + (sq and 7)) and 1 == 0
                cellRect(row, col, tmpRect)
                squarePaint.color = if (dark) theme.dark else theme.light
                canvas.drawRect(tmpRect, squarePaint)
            }
        }

        // Rounded, soft highlights for the last move (from + to).
        if (lastFrom != NO_SQUARE) {
            overlayPaint.color = theme.lastMove
            drawRoundedOverlay(canvas, lastFrom, theme.lastMove)
            drawRoundedOverlay(canvas, lastTo, theme.lastMove)
        }

        // Selected square: stronger golden overlay + a crisper outline.
        if (selectedSq != NO_SQUARE) {
            drawRoundedOverlay(canvas, selectedSq, theme.selected)
            ringPaint.color = 0xE6FFFFFF.toInt()
            ringPaint.strokeWidth = cell * 0.05f
            cellRect(rowOf(selectedSq), colOf(selectedSq), tmpRect)
            val inset = cell * 0.06f
            canvas.drawRoundRect(
                tmpRect.left + inset, tmpRect.top + inset,
                tmpRect.right - inset, tmpRect.bottom - inset,
                cell * 0.09f, cell * 0.09f, ringPaint
            )
        }

        // Pulsing check glow on the king square.
        if (checkSquare != NO_SQUARE) {
            cellRect(rowOf(checkSquare), colOf(checkSquare), tmpRect)
            overlayPaint.color = withAlpha(theme.checkFill, 0x59 + (0x2D * pulse).toInt())
            canvas.drawRect(tmpRect, overlayPaint)
            ringPaint.color = withAlpha(theme.checkRing, 0xB3 + (0x4C * pulse).toInt())
            ringPaint.strokeWidth = cell * (0.05f + 0.015f * pulse)
            val r = cell * (0.40f + 0.05f * pulse)
            canvas.drawCircle(tmpRect.centerX(), tmpRect.centerY(), r, ringPaint)
        }

        // Coordinates on the board edges — bold weight for a more confident, modern label.
        coordPaint.textSize = cell * 0.18f
        coordPaint.isFakeBoldText = true
        for (row in 0 until 8) {
            for (col in 0 until 8) {
                val sq = if (orientation == WHITE) (7 - row) * 8 + col else row * 8 + (7 - col)
                val dark = ((sq shr 3) + (sq and 7)) and 1 == 0
                cellRect(row, col, tmpRect)
                if (col == 0) {
                    coordPaint.color = if (dark) theme.coordDark else theme.coordLight
                    val rankChar = '1' + (sq shr 3)
                    canvas.drawText(
                        rankChar.toString(),
                        tmpRect.left + cell * 0.055f,
                        tmpRect.bottom - cell * 0.07f,
                        coordPaint
                    )
                }
                if (row == 7) {
                    coordPaint.color = if (dark) theme.coordDark else theme.coordLight
                    val fileChar = 'a' + (sq and 7)
                    canvas.drawText(
                        fileChar.toString(),
                        tmpRect.right - cell * 0.23f,
                        tmpRect.bottom - cell * 0.07f,
                        coordPaint
                    )
                }
            }
        }

        // Legal-move hints for the selected square.
        if (selectedSq != NO_SQUARE) {
            for (t in targets) {
                if (t.from != selectedSq) continue
                cellRect(rowOf(t.to), colOf(t.to), tmpRect)
                val dark = ((t.to shr 3) + (t.to and 7)) and 1 == 0
                if (t.isCapture) {
                    ringPaint.color = if (dark) 0xB3FFFFFF.toInt() else 0xB3000000.toInt()
                    ringPaint.strokeWidth = cell * 0.065f
                    val inset = cell * 0.13f
                    canvas.drawRoundRect(
                        tmpRect.left + inset, tmpRect.top + inset,
                        tmpRect.right - inset, tmpRect.bottom - inset,
                        cell * 0.1f, cell * 0.1f, ringPaint
                    )
                } else {
                    dotPaint.color = if (dark) 0x8CFFFFFF.toInt() else 0x8C000000.toInt()
                    canvas.drawCircle(tmpRect.centerX(), tmpRect.centerY(), cell * 0.115f, dotPaint)
                }
            }
        }

        // Pieces (skip the ones being animated or dragged).
        for (sq in 0 until 64) {
            val v = squares[sq]
            if (v < 0) continue
            if (anim != null && (sq == anim!!.to || sq == anim!!.rookTo)) continue
            if (dragging && sq == dragCandidateSq) continue
            cellRect(rowOf(sq), colOf(sq), tmpRect)
            PieceRenderer.drawPiece(canvas, v and 7, v shr 3, tmpRect)
        }

        // Animated pieces travel between cells.
        anim?.let { a ->
            val ease = a.t
            cellRect(rowOf(a.from), colOf(a.from), tmpRect)
            val fx = tmpRect.left; val fy = tmpRect.top
            cellRect(rowOf(a.to), colOf(a.to), tmpRect)
            val tx = tmpRect.left; val ty = tmpRect.top
            PieceRenderer.drawPiece(
                canvas, a.piece and 7, a.piece shr 3,
                fx + (tx - fx) * ease, fy + (ty - fy) * ease, cell
            )
            if (a.rookPiece >= 0) {
                cellRect(rowOf(a.rookFrom), colOf(a.rookFrom), tmpRect)
                val rfx = tmpRect.left; val rfy = tmpRect.top
                cellRect(rowOf(a.rookTo), colOf(a.rookTo), tmpRect)
                val rtx = tmpRect.left; val rty = tmpRect.top
                PieceRenderer.drawPiece(
                    canvas, a.rookPiece and 7, a.rookPiece shr 3,
                    rfx + (rtx - rfx) * ease, rfy + (rty - rfy) * ease, cell
                )
            }
        }

        // Dragged piece floats above everything, slightly enlarged.
        if (dragging && dragCandidateSq != NO_SQUARE) {
            val v = squares[dragCandidateSq]
            if (v >= 0) {
                val size = cell * 1.14f
                PieceRenderer.drawPiece(
                    canvas, v and 7, v shr 3,
                    dragX - size / 2f, dragY - size / 2f, size, elevated = true
                )
            }
        }

        // Board frame — bolder ring plus a thin inner bevel line, so the
        // board reads as one confident sharp-edged object rather than a
        // floating grid. Squares themselves stay perfectly square (rounding
        // them would soften the whole board); only the frame gets weight.
        framePaint.color = theme.frame
        framePaint.strokeWidth = (cell * 0.07f).coerceAtLeast(4.5f)
        val half = framePaint.strokeWidth / 2f
        canvas.drawRect(half, half, width - half, height - half, framePaint)

        framePaint.color = withAlpha(theme.frame, 0x4D)
        framePaint.strokeWidth = (cell * 0.018f).coerceAtLeast(1.5f)
        val bevelInset = framePaint.strokeWidth * 3f
        canvas.drawRect(
            bevelInset, bevelInset, width - bevelInset, height - bevelInset, framePaint
        )

        // engine best-move arrow on top of everything.
        arrow?.let { (from, to) -> drawBestMoveArrow(canvas, from, to) }
    }

    /** Translucent green arrow with a solid arrowhead — the coach's hint. */
    private fun drawBestMoveArrow(canvas: Canvas, from: Int, to: Int) {
        val fr = rowOf(from); val fc = colOf(from)
        val tr = rowOf(to); val tc = colOf(to)
        val x0 = (fc + 0.5f) * cell
        val y0 = (fr + 0.5f) * cell
        val x1 = (tc + 0.5f) * cell
        val y1 = (tr + 0.5f) * cell

        val stroke = cell * 0.16f
        val headLen = cell * 0.38f

        // Shorten the shaft so the arrowhead lands cleanly on the target.
        val dx = x1 - x0
        val dy = y1 - y0
        val len = kotlin.math.hypot(dx, dy).coerceAtLeast(1f)
        val ux = dx / len
        val uy = dy / len
        val shaftEndX = x1 - ux * headLen * 0.7f
        val shaftEndY = y1 - uy * headLen * 0.7f

        // Best-move hint colors reuse the app's "best/excellent" move-class
        // semantics (class_excellent / class_best) so the coach arrow speaks
        // the same color language as the rest of the analysis UI.
        arrowPaint.color = 0x662E7D32.toInt()
        arrowPaint.strokeCap = Paint.Cap.ROUND
        arrowPaint.strokeWidth = stroke
        canvas.drawLine(x0, y0, shaftEndX, shaftEndY, arrowPaint)

        // Arrowhead: triangle perpendicular to the shaft direction.
        headPaint.color = 0xCC1B5E20.toInt()
        val p1x = x1
        val p1y = y1
        val p2x = x1 - ux * headLen + uy * headLen * 0.42f
        val p2y = y1 - uy * headLen - ux * headLen * 0.42f
        val p3x = x1 - ux * headLen - uy * headLen * 0.42f
        val p3y = y1 - uy * headLen + ux * headLen * 0.42f
        val path = arrowPath
        path.reset()
        path.moveTo(p1x, p1y)
        path.lineTo(p2x, p2y)
        path.lineTo(p3x, p3y)
        path.close()
        canvas.drawPath(path, headPaint)
    }

    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val headPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arrowPath = android.graphics.Path()

    /** Rounded translucent overlay for a square — a tight radius for a sharp feel. */
    private fun drawRoundedOverlay(canvas: Canvas, sq: Int, color: Int) {
        if (sq == NO_SQUARE) return
        overlayPaint.color = color
        cellRect(rowOf(sq), colOf(sq), tmpRect)
        val inset = cell * 0.035f
        canvas.drawRoundRect(
            tmpRect.left + inset, tmpRect.top + inset,
            tmpRect.right - inset, tmpRect.bottom - inset,
            cell * 0.09f, cell * 0.09f, overlayPaint
        )
    }

    private fun withAlpha(color: Int, alpha: Int): Int {
        val a = alpha.coerceIn(0, 255)
        return (color and 0x00FFFFFF) or (a shl 24)
    }
}
