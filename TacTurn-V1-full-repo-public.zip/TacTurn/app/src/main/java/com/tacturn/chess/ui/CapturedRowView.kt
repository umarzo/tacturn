package com.tacturn.chess.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import com.google.android.material.color.MaterialColors

/**
 * Horizontal row of miniature captured pieces. Each entry is a
 * (type, color) pair supplied by the view model.
 *
 * The view is budgeted: it draws at most as many pieces as fit its measured
 * width (plus a "+N" overflow marker), so a growing capture list can never
 * push surrounding layout around.
 */
class CapturedRowView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var pieces: List<Pair<Int, Int>> = emptyList()
    private val rect = RectF()
    private val overflowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11f
        isFakeBoldText = true
    }

    fun setCaptured(pieces: List<Pair<Int, Int>>) {
        this.pieces = pieces
        invalidate()
    }

    private fun dp(v: Int): Float = v * resources.displayMetrics.density

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val h = resolveSize(24, heightMeasureSpec)
        setMeasuredDimension(resolveSize(120, widthMeasureSpec), h)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = height * 0.95f
        val y = (height - size) / 2f
        val step = size + dp(2)
        var x = dp(1)
        val maxW = width - dp(6) // reserve for "+N"

        var drawn = 0
        for ((type, color) in pieces) {
            if (x + size > maxW) break
            rect.set(x, y, x + size, y + size)
            PieceRenderer.drawPiece(canvas, type, color, rect)
            x += step
            drawn++
        }
        val overflow = pieces.size - drawn
        if (overflow > 0) {
            // Theme-aware so "+N" keeps proper contrast on the dark canvas
            // (was a fixed grey that washed out in night mode).
            overflowPaint.color = MaterialColors.getColor(
                this, com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF777777.toInt()
            )
            overflowPaint.textSize = height * 0.5f
            canvas.drawText("+$overflow", x + dp(1), y + size * 0.78f, overflowPaint)
        }
    }
}
