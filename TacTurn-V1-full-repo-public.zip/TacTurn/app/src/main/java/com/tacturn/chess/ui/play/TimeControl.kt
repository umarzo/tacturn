package com.tacturn.chess.ui.play

/*
 * TacTurn v2 — time controls for every game mode.
 *
 * A TimeControl is the classic minutes + Fischer-increment pair
 * (e.g. "3+2" = 3 minutes base, 2 seconds added after every move).
 * initialMs <= 0 means "Unlimited" (no clock at all).
 */

/** Coarse category used for labels and stats ("Bullet", "Blitz", …). */
enum class TimeCategory(val label: String) {
    UNLIMITED("Unlimited"),
    BULLET("Bullet"),
    BLITZ("Blitz"),
    RAPID("Rapid"),
    CLASSICAL("Classical");
}

/**
 * Immutable time-control description. Pure data + formatting helpers —
 * no Android dependencies, trivially unit-testable.
 */
data class TimeControl(val initialMs: Long, val incrementMs: Long) {

    val isUnlimited: Boolean get() = initialMs <= 0L

    /** Human label: "3+2", "30+20", "Unlimited" or "12+5 Custom". */
    val label: String
        get() = if (isUnlimited) TimeCategory.UNLIMITED.label else "${initialMs / 60000}+${incrementMs / 1000}"

    /** Standard chess.com/lichess-style category for this control. */
    val category: TimeCategory
        get() = when {
            isUnlimited -> TimeCategory.UNLIMITED
            initialMs < 3 * 60000L -> TimeCategory.BULLET      // 1+0 … 2+1
            initialMs <= 8 * 60000L -> TimeCategory.BLITZ      // 3+0 … 8+X
            initialMs < 30 * 60000L -> TimeCategory.RAPID      // 10+0 … 25+X
            else -> TimeCategory.CLASSICAL                     // 30+0 and up
        }

    /**
     * Formats a remaining-time value for the clock display:
     *  - 10 h+  -> "h:mm:ss"
     *  - >= 20 s -> "m:ss"
     *  - < 20 s  -> "m:ss.t" (tenths — the classic low-time scramble view)
     *  - <= 0    -> "0:00.0"
     */
    fun format(ms: Long): String {
        val clamped = if (ms < 0L) 0L else ms
        if (clamped >= 3_600_000L) {
            val h = clamped / 3_600_000L
            val m = (clamped % 3_600_000L) / 60_000L
            val s = (clamped % 60_000L) / 1000L
            return "%d:%02d:%02d".format(h, m, s)
        }
        if (clamped >= 20_000L) {
            val m = clamped / 60_000L
            val s = (clamped % 60_000L) / 1000L
            return "%d:%02d".format(m, s)
        }
        val m = clamped / 60_000L
        val s = (clamped % 60_000L) / 1000L
        val t = (clamped % 1000L) / 100L
        return "%d:%02d.%d".format(m, s, t)
    }

    /** True when the remaining time should render in "low time" style. */
    fun isLowTime(ms: Long): Boolean = !isUnlimited && ms in 1..LOW_TIME_THRESHOLD_MS

    companion object {
        const val LOW_TIME_THRESHOLD_MS = 15_000L

        /** Sentinel used when no clock is attached to a game. */
        val UNLIMITED = TimeControl(0L, 0L)

        /**
         * The curated preset grid shown on the Play tab, in display order.
         * Kept in a companion so the chip UI and serialization share one list.
         */
        val PRESETS: List<TimeControl> = listOf(
            UNLIMITED,                       // Unlimited
            TimeControl(60_000L, 0L),        // Bullet 1+0
            TimeControl(60_000L, 1_000L),    // Bullet 1+1
            TimeControl(120_000L, 0L),       // Bullet 2+0
            TimeControl(120_000L, 1_000L),   // Bullet 2+1
            TimeControl(180_000L, 0L),       // Blitz 3+0
            TimeControl(180_000L, 2_000L),   // Blitz 3+2
            TimeControl(300_000L, 0L),       // Blitz 5+0
            TimeControl(300_000L, 3_000L),   // Blitz 5+3
            TimeControl(600_000L, 0L),       // Rapid 10+0
            TimeControl(600_000L, 5_000L),   // Rapid 10+5
            TimeControl(900_000L, 10_000L),  // Rapid 15+10
            TimeControl(1_800_000L, 0L),     // Classical 30+0
            TimeControl(1_800_000L, 20_000L),// Classical 30+20
            TimeControl(3_600_000L, 30_000L) // Classical 60+30
        )

        /** Builds a custom control from minutes + increment seconds. */
        fun custom(minutes: Int, incrementSeconds: Int): TimeControl =
            TimeControl(minutes.coerceIn(1, 180) * 60_000L, incrementSeconds.coerceIn(0, 120) * 1000L)
    }
}
