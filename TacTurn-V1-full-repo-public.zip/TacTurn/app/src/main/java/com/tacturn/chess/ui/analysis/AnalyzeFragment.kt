package com.tacturn.chess.ui.analysis

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.tacturn.chess.R
import com.tacturn.chess.databinding.FragmentAnalyzeBinding
import com.tacturn.chess.data.HistoryRepository
import com.tacturn.chess.data.Prefs

/**
 * The Analyze tab — the import hub for "Analyze My Game":
 *
 *   • Paste PGN text
 *   • Pick a .pgn file (SAF — no storage permission needed)
 *   • Paste a FEN string
 *
 * Every input is validated by the parser + engine before anything happens;
 * malformed input degrades to a friendly toast, never a crash.
 */
class AnalyzeFragment : Fragment() {

    private var _binding: FragmentAnalyzeBinding? = null
    private val binding get() = _binding!!

    private val filePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            uri?.let { openAnalysis(it, AnalysisActivity.SOURCE_PGN_FILE) }
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAnalyzeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.cardPgnText.setOnClickListener { showPgnInputDialog() }
        binding.cardPgnFile.setOnClickListener {
            filePicker.launch(arrayOf("text/*", "application/x-chess-pgn", "application/pgn"))
        }
        binding.cardFen.setOnClickListener { showFenDialog() }
        binding.cardSampleGame.setOnClickListener {
            openAnalysis(
                Uri.parse("tacturn://sample"),
                AnalysisActivity.SOURCE_SAMPLE
            )
        }
    }

    override fun onResume() {
        super.onResume()
        renderRecent()
    }

    private fun renderRecent() {
        val recent = HistoryRepository(requireContext()).all().take(4)
        val container = binding.recentList
        container.removeAllViews()
        if (recent.isEmpty()) {
            binding.recentLabel.visibility = View.GONE
            return
        }
        binding.recentLabel.visibility = View.VISIBLE
        val inflater = layoutInflater
        for (entry in recent) {
            val item = inflater.inflate(R.layout.item_history, container, false)
            item.findViewById<android.widget.TextView>(R.id.itemTitle).text =
                "${entry.white} vs ${entry.black}"
            item.findViewById<android.widget.TextView>(R.id.itemSubtitle).text =
                describe(entry)
            item.setOnClickListener {
                openAnalysis(
                    Uri.parse("tacturn://history/${entry.id}"),
                    AnalysisActivity.SOURCE_HISTORY
                )
            }
            container.addView(item)
        }
    }

    private fun describe(entry: com.tacturn.chess.data.HistoryEntry): String {
        val date = java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM)
            .format(java.util.Date(entry.date))
        return when (entry.kind) {
            "played" -> {
                val res = entry.result ?: "*"
                // Mode-aware label: Pass & Play entries used to render as
                // "vs engine ?" in the recent list.
                val mode = if (entry.mode == com.tacturn.chess.data.HistoryEntry.MODE_PVP)
                    "pass & play"
                else "vs engine ${entry.engineElo ?: "?"}"
                "$mode · $res · $date"
            }
            else -> {
                val acc = entry.accuracy?.let { "acc ${it.toInt()}%" } ?: ""
                val perf = entry.performanceElo?.let { "played at $it" } ?: ""
                "$acc $perf · $date".trim()
            }
        }
    }

    /** PGN paste dialog: multiline input, live hint, friendly errors. */
    private fun showPgnInputDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_text_input, null)
        val input = view.findViewById<TextInputEditText>(R.id.inputField)
        input.setHint(R.string.pgn_hint)
        view.findViewById<android.widget.TextView>(R.id.inputCounter).apply {
            addCounter(input)
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.import_pgn_title)
            .setView(view)
            .setPositiveButton(R.string.import_action) { _, _ ->
                val text = input.text?.toString().orEmpty()
                if (text.isBlank()) {
                    toast(R.string.import_empty)
                } else {
                    openAnalysis(text, AnalysisActivity.SOURCE_PGN_TEXT)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showFenDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_text_input, null)
        val input = view.findViewById<TextInputEditText>(R.id.inputField)
        input.setHint(R.string.fen_hint)
        view.findViewById<android.widget.TextView>(R.id.inputCounter).apply {
            addCounter(input, showLines = false)
        }
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.import_fen_title)
            .setView(view)
            .setPositiveButton(R.string.import_action) { _, _ ->
                val fen = input.text?.toString().orEmpty()
                if (fen.isBlank()) {
                    toast(R.string.import_empty)
                } else {
                    openAnalysis(fen, AnalysisActivity.SOURCE_FEN)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun android.widget.TextView.addCounter(
        input: TextInputEditText,
        showLines: Boolean = true
    ) {
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val t = s?.toString().orEmpty()
                text = if (showLines && t.isNotBlank()) {
                    val est = t.lineSequence().count()
                    getString(R.string.import_counter, est)
                } else if (t.isNotBlank()) {
                    getString(R.string.import_counter_chars, t.length)
                } else ""
            }
        })
    }

    private fun openAnalysis(payload: String, source: String) {
        startActivity(AnalysisActivity.intent(requireContext(), payload, source))
    }

    private fun openAnalysis(uri: Uri, source: String) {
        startActivity(AnalysisActivity.intent(requireContext(), uri, source))
    }

    private fun toast(resId: Int) {
        Toast.makeText(requireContext(), getString(resId), Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }
}
