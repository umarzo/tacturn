package com.tacturn.chess.ui

import com.tacturn.chess.engine.BLACK
import com.tacturn.chess.engine.GameResult
import com.tacturn.chess.engine.WHITE
import com.tacturn.chess.engine.moveFrom
import com.tacturn.chess.engine.isCapture
import com.tacturn.chess.engine.movePromo
import com.tacturn.chess.engine.moveTo
import com.tacturn.chess.ui.play.GameMode

/** A legal move as shown by the board, plus everything the renderer needs. */
data class UiMove(
    val move: Int,
    val from: Int,
    val to: Int,
    val isCapture: Boolean,
    val isPromotion: Boolean
)

/** One row of the move history strip ("1. e4 e5"). */
data class MoveRow(val number: Int, val whiteSan: String?, val blackSan: String?)

data class SoundEvent(val id: Int, val type: SoundType)

/** A transient user-visible notice (snackbar), deduplicated by [id]. */
data class NoticeEvent(val id: Int, val text: String)

enum class StatusStyle { PLAYER, THINKING, CHECK, WIN, LOSE, DRAW }

/**
 * Live snapshot of the chess clock, published on its own flow so 10 Hz
 * ticks never trigger a full board re-render.
 */
data class ClockUiState(
    val visible: Boolean = false,
    val whiteMs: Long = 0L,
    val blackMs: Long = 0L,
    /** Side whose clock is running (-1 when paused / game over / no clock). */
    val activeColor: Int = -1,
    val whiteLow: Boolean = false,
    val blackLow: Boolean = false,
    val paused: Boolean = false,
    /** Set once a flag fell — the game layer ends the game off this. */
    val flaggedColor: Int = -1
)

data class GameUiState(
    val started: Boolean = false,
    /** Piece code per square (-1 empty, else color*8 + type). */
    val board: List<Int> = List(64) { -1 },
    val playerColor: Int = WHITE,
    val orientation: Int = WHITE,
    /** Color whose turn it is (drives board input ownership in PvP). */
    val moverColor: Int = WHITE,
    val yourTurn: Boolean = false,
    val legalMoves: List<UiMove> = emptyList(),
    val lastFrom: Int = -1,
    val lastTo: Int = -1,
    val checkSquare: Int = -1,
    val statusText: String = "",
    val statusStyle: StatusStyle = StatusStyle.PLAYER,
    val thinking: Boolean = false,
    val engineInfo: String = "",
    val moveRows: List<MoveRow> = emptyList(),
    /** (type, color) of pieces captured by the player / engine. */
    val capturedByPlayer: List<Pair<Int, Int>> = emptyList(),
    val capturedByEngine: List<Pair<Int, Int>> = emptyList(),
    val materialDiff: Int = 0,
    val result: GameResult = GameResult.ONGOING,
    val moveCounter: Int = 0,
    val soundEvent: SoundEvent? = null,
    /** from/to of a pending promotion (engine square ids). */
    val pendingPromotion: Pair<Int, Int>? = null,
    /** prominent difficulty display, e.g. "Club · 1500 Elo". */
    val difficultyLabel: String = "",
    val engineElo: Int = 0,

    // ---- TacTurn v2: modes, clocks, openings, draw offers ----------------

    val mode: GameMode = GameMode.ENGINE,
    /** "3+2 Blitz" / "" when unlimited. */
    val timeControlLabel: String = "",
    /** Current opening name ("" = unknown / hidden). */
    val openingName: String = "",
    /** Player-row labels, orientation-aware (top = far side). */
    val topLabel: String = "",
    val bottomLabel: String = "",
    /** True when the clock flow should render at all. */
    val hasClock: Boolean = false,
    /** Pass & Play: color whose draw offer awaits the opponent's answer. */
    val drawOfferFrom: Int = -1,
    /** Draw offers currently possible (turn + cooldowns respected). */
    val canOfferDraw: Boolean = false,
    /** Set once the game ended: "time" / "agreement" / "resignation" / … */
    val endReason: String = "",
    /** Color that lost on time (-1 when not a time forfeit). */
    val timeForfeitLoser: Int = -1,
    /** Transient snackbar notices (engine declines draw etc.). */
    val noticeEvent: NoticeEvent? = null
)
