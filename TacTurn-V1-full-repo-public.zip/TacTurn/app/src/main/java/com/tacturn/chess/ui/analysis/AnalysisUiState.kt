package com.tacturn.chess.ui.analysis

import com.tacturn.chess.analysis.EloProfile
import com.tacturn.chess.analysis.LineModel
import com.tacturn.chess.analysis.MoveChip
import com.tacturn.chess.analysis.PlyDetail
import com.tacturn.chess.analysis.ReviewPresentation
import com.tacturn.chess.engine.GameResult

/*
 * TacTurn v1 — the Analysis screen's UI state (immutable snapshots
 * published through a StateFlow; the Activity only renders).
 */

/** Where the analysis session is in its lifecycle. */
sealed interface AnalysisPhase {
    object Idle : AnalysisPhase
    object Importing : AnalysisPhase
    /** Import rejected — the reason is in [AnalysisUiState.errorMessage]. */
    object ImportFailed : AnalysisPhase
    /** Game loaded + replayed; waiting for the user's Elo (bottom sheet). */
    object NeedsElo : AnalysisPhase
    /** Whole-game review running (resumable, live partial results). */
    object BatchRunning : AnalysisPhase
    /** Review complete — browsing + deep interactive analysis available. */
    object Ready : AnalysisPhase
}

data class AnalysisUiState(
    val phase: AnalysisPhase = AnalysisPhase.Idle,

    // ---- game identity ----
    val gameTitle: String = "",
    val whiteName: String = "",
    val blackName: String = "",
    val result: String? = null,
    val plyCount: Int = 0,

    // ---- batch progress ----
    val progressDone: Int = 0,
    val progressTotal: Int = 0,

    // ---- board browsing ----
    /** Piece code per square (-1 empty, else color*8 + type). */
    val board: List<Int> = List(64) { -1 },
    val orientation: Int = 0,
    /** Position index shown: 0..plyCount (k = position BEFORE ply k). */
    val selectedPly: Int = 0,
    val lastFrom: Int = -1,
    val lastTo: Int = -1,
    /** Engine best-move arrow at the shown position (from/to). */
    val bestFrom: Int = -1,
    val bestTo: Int = -1,
    val gameResult: GameResult = GameResult.ONGOING,

    // ---- Elo-personalized presentation (re-filtered instantly) ----
    val userElo: Int = 1200,
    val profile: EloProfile? = null,
    val presentation: ReviewPresentation? = null,
    val moveChips: List<MoveChip> = emptyList(),
    val detail: PlyDetail? = null,

    // ---- interactive engine lines for the selected position ----
    val lines: List<LineModel> = emptyList(),
    val linesAnalyzing: Boolean = false,
    val linesDepth: Int = 0,
    val linesInfo: String = "",

    // ---- misc ----
    val heroSide: Int = 0,
    val errorMessage: String? = null
)
