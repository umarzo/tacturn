package com.tacturn.chess.ui.play

import android.content.Context
import android.content.Intent
import com.tacturn.chess.data.Prefs
import com.tacturn.chess.engine.BLACK
import com.tacturn.chess.engine.WHITE

/*
 * TacTurn v2 — the full description of a game about to start.
 *
 * Everything the game screen needs is bundled here and passed through the
 * launch intent, so a process death recreates the Activity with the same
 * configuration the user picked on the Play tab.
 */

/** Where the opponent's moves come from. */
enum class GameMode { ENGINE, HUMAN }

data class GameConfig(
    val mode: GameMode = GameMode.ENGINE,
    /** Player's color in ENGINE mode (ignored in HUMAN mode). */
    val playerColor: Int = WHITE,
    /** Opponent strength in ENGINE mode. */
    val engineElo: Int = 1200,
    /** Clock settings; [TimeControl.UNLIMITED] = no clock. */
    val timeControl: TimeControl = TimeControl.UNLIMITED,
    /** Pass-and-play display names. */
    val whiteName: String = "White",
    val blackName: String = "Black",
    /** Pass & Play: auto-flip the board to the side to move after every move. */
    val autoFlip: Boolean = true
) {

    /** Display name for a color under this config. */
    fun nameOf(color: Int): String = when (mode) {
        GameMode.HUMAN -> if (color == WHITE) whiteName else blackName
        GameMode.ENGINE ->
            if (color == playerColor) "You" else "TacTurn Engine"
    }

    // ---- intent marshalling -------------------------------------------

    companion object {
        // Intent keys live here (not in GameActivity) so that the reader
        // (fromIntent) and the writer (GameActivity.intent) can never drift.
        internal const val EXTRA_MODE = "mode"
        internal const val EXTRA_COLOR = "color"
        internal const val EXTRA_ELO = "elo"
        internal const val EXTRA_TC_INITIAL = "tcInitial"
        internal const val EXTRA_TC_INC = "tcInc"
        internal const val EXTRA_WHITE_NAME = "whiteName"
        internal const val EXTRA_BLACK_NAME = "blackName"
        internal const val EXTRA_AUTO_FLIP = "autoFlip"

        fun fromIntent(intent: Intent): GameConfig {
            val tc = TimeControl(
                intent.getLongExtra(EXTRA_TC_INITIAL, 0L),
                intent.getLongExtra(EXTRA_TC_INC, 0L)
            )
            return GameConfig(
                mode = if (intent.getIntExtra(EXTRA_MODE, 0) == 1) GameMode.HUMAN else GameMode.ENGINE,
                playerColor = if (intent.getIntExtra(EXTRA_COLOR, WHITE) == BLACK) BLACK else WHITE,
                engineElo = intent.getIntExtra(EXTRA_ELO, 1200),
                timeControl = tc,
                whiteName = intent.getStringExtra(EXTRA_WHITE_NAME) ?: "White",
                blackName = intent.getStringExtra(EXTRA_BLACK_NAME) ?: "Black",
                autoFlip = intent.getBooleanExtra(EXTRA_AUTO_FLIP, true)
            )
        }

        /** Restores the last-used setup from prefs (Play tab's initial state). */
        fun fromPrefs(context: Context): GameConfig {
            val tcIndex = Prefs.lastTimeControlIndex(context)
            val presets = TimeControl.PRESETS
            val tc = when {
                tcIndex in presets.indices -> presets[tcIndex]
                tcIndex == -1 -> TimeControl.custom(
                    Prefs.customTcMinutes(context),
                    Prefs.customTcIncrement(context)
                )
                else -> TimeControl.UNLIMITED
            }
            return GameConfig(
                mode = if (Prefs.lastGameMode(context) == 1) GameMode.HUMAN else GameMode.ENGINE,
                playerColor = Prefs.lastColor(context),
                engineElo = Prefs.engineElo(context),
                timeControl = tc,
                whiteName = Prefs.pvpWhiteName(context),
                blackName = Prefs.pvpBlackName(context),
                autoFlip = Prefs.pvpAutoFlip(context)
            )
        }

        /** Persists the user's current setup choices for the next visit. */
        fun saveToPrefs(context: Context, config: GameConfig, presetIndex: Int) {
            Prefs.setLastGameMode(context, config.mode.ordinal)
            if (config.mode == GameMode.ENGINE) {
                Prefs.setEngineElo(context, config.engineElo)
                Prefs.setLastColor(context, config.playerColor)
            }
            if (presetIndex >= -1) {
                // -1 is valid: the user selected a custom control (its
                // minutes/increment are persisted separately), so it must
                // survive restarts just like a preset index.
                Prefs.setLastTimeControlIndex(context, presetIndex)
            }
            Prefs.setPvpWhiteName(context, config.whiteName)
            Prefs.setPvpBlackName(context, config.blackName)
            Prefs.setPvpAutoFlip(context, config.autoFlip)
        }
    }
}
