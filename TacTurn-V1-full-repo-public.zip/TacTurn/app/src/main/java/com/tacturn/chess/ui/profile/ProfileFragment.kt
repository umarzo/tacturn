package com.tacturn.chess.ui.profile

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.tacturn.chess.R
import com.tacturn.chess.data.HistoryEntry
import com.tacturn.chess.data.HistoryRepository
import com.tacturn.chess.data.Prefs
import com.tacturn.chess.databinding.FragmentProfileBinding
import com.tacturn.chess.ui.MainActivity
import com.tacturn.chess.ui.analysis.AnalysisActivity
import java.text.DateFormat
import java.util.Date

/**
 * The Profile tab: identity + personal settings + the full game history
 * (played and analyzed, tap to reopen in the analysis screen).
 */
class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        renderIdentity()
        renderSettings()
        renderHistory()
        renderStats()

        binding.nameEdit.setOnClickListener { showNameDialog() }
        binding.userEloEdit.setOnClickListener { showEloDialog() }
    }

    override fun onResume() {
        super.onResume()
        renderHistory()
        renderStats()
    }

    private fun renderIdentity() {
        binding.userName.text = Prefs.userName(requireContext())
        val elo = Prefs.userElo(requireContext())
        binding.userElo.text = getString(R.string.your_elo, elo)
        binding.userTier.text = skillTier(elo)
    }

    /** Friendly skill tier shown on the identity card's mint pill. */
    private fun skillTier(elo: Int): String = when {
        elo < 1400 -> getString(R.string.tier_beginner)
        elo < 1800 -> getString(R.string.tier_club)
        elo < 2200 -> getString(R.string.tier_advanced)
        else -> getString(R.string.tier_master)
    }

    private fun renderSettings() {
        val ctx = requireContext()
        binding.soundSwitch.isChecked = Prefs.soundEnabled(ctx)
        binding.soundSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setSoundEnabled(ctx, checked)
        }
        binding.batterySwitch.isChecked = Prefs.batterySaver(ctx)
        binding.batterySwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setBatterySaver(ctx, checked)
        }
        binding.hapticsSwitch.isChecked = Prefs.hapticsEnabled(ctx)
        binding.hapticsSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setHapticsEnabled(ctx, checked)
        }
        binding.autoQueenSwitch.isChecked = Prefs.autoQueen(ctx)
        binding.autoQueenSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setAutoQueen(ctx, checked)
        }
        val mode = Prefs.themeMode(ctx)
        binding.themeGroup.check(
            when (mode) {
                Prefs.THEME_MODE_LIGHT -> R.id.themeLight
                Prefs.THEME_MODE_DARK -> R.id.themeDark
                else -> R.id.themeSystem
            }
        )
        binding.themeGroup.setOnCheckedChangeListener { _, id ->
            val newMode = when (id) {
                R.id.themeLight -> Prefs.THEME_MODE_LIGHT
                R.id.themeDark -> Prefs.THEME_MODE_DARK
                else -> Prefs.THEME_MODE_SYSTEM
            }
            Prefs.setThemeMode(ctx, newMode)
            MainActivity.applyTheme(newMode)
        }

        // Board theme swatches.
        val swatches = listOf(
            binding.swatchRed to Prefs.THEME_RED,
            binding.swatchWood to Prefs.THEME_WOOD,
            binding.swatchSlate to Prefs.THEME_SLATE,
            binding.swatchEmerald to Prefs.THEME_EMERALD
        )
        val current = Prefs.boardTheme(ctx)
        swatches.forEach { (view, theme) ->
            view.isSelected = theme == current
            view.setOnClickListener {
                Prefs.setBoardTheme(ctx, theme)
                swatches.forEach { (v, t) -> v.isSelected = t == theme }
            }
        }
    }

    private fun renderStats() {
        val entries = HistoryRepository(requireContext()).all()
        val analyzed = entries.filter { it.kind == "analyzed" }
        val played = entries.filter { it.kind == "played" }
        val wins = played.count {
            (it.result == "1-0" && it.playerColor == 0) ||
                (it.result == "0-1" && it.playerColor == 1)
        }
        binding.statGames.text = played.size.toString()
        binding.statWins.text = wins.toString()
        binding.statAnalyzed.text = analyzed.size.toString()
        val perf = analyzed.mapNotNull { it.performanceElo }
        binding.statBestPerf.text = if (perf.isEmpty()) "—" else perf.max().toString()
    }

    private fun renderHistory() {
        val container = binding.historyList
        container.removeAllViews()
        val entries = HistoryRepository(requireContext()).all()
        if (entries.isEmpty()) {
            binding.emptyHistory.visibility = View.VISIBLE
            return
        }
        binding.emptyHistory.visibility = View.GONE
        val inflater = layoutInflater
        for (entry in entries.take(50)) {
            val item = inflater.inflate(R.layout.item_history, container, false)
            item.findViewById<TextView>(R.id.itemTitle).text =
                "${entry.white} vs ${entry.black}"
            item.findViewById<TextView>(R.id.itemSubtitle).text = describe(entry)
            item.setOnLongClickListener {
                confirmDelete(entry)
                true
            }
            item.setOnClickListener { open(entry) }
            container.addView(item)
        }
    }

    private fun describe(entry: HistoryEntry): String {
        val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(entry.date))
        return when (entry.kind) {
            "played" -> {
                val res = entry.result ?: "*"
                val mode = when (entry.mode) {
                    HistoryEntry.MODE_PVP -> "pass & play"
                    else -> "vs engine ${entry.engineElo ?: "?"}"
                }
                val tc = entry.timeControl ?: "unlimited"
                "$mode · $tc · $res · ${entry.moveCount} moves · $date"
            }
            else -> {
                val parts = ArrayList<String>()
                entry.accuracy?.let { parts.add("accuracy ${it.toInt()}%") }
                entry.performanceElo?.let { parts.add("played at $it") }
                parts.add("${entry.moveCount} moves")
                parts.add(date)
                parts.joinToString(" · ")
            }
        }
    }

    private fun open(entry: HistoryEntry) {
        startActivity(
            AnalysisActivity.intent(
                requireContext(),
                Uri.parse("tacturn://history/${entry.id}"),
                AnalysisActivity.SOURCE_HISTORY
            )
        )
    }

    private fun confirmDelete(entry: HistoryEntry) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.delete_entry_title)
            .setMessage(R.string.delete_entry_message)
            .setPositiveButton(R.string.delete) { _, _ ->
                HistoryRepository(requireContext()).delete(entry.id)
                renderHistory()
                renderStats()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showNameDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_text_input, null)
        val input = view.findViewById<com.google.android.material.textfield.TextInputEditText>(
            R.id.inputField
        )
        input.setHint(R.string.name_hint)
        input.setText(Prefs.userName(requireContext()))
        view.findViewById<TextView>(R.id.inputCounter).visibility = View.GONE
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.name_title)
            .setView(view)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                Prefs.setUserName(requireContext(), input.text?.toString().orEmpty())
                renderIdentity()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showEloDialog() {
        val view = layoutInflater.inflate(R.layout.dialog_elo_input, null)
        val input = view.findViewById<com.google.android.material.textfield.TextInputEditText>(
            R.id.eloField
        )
        input.setText(Prefs.userElo(requireContext()).toString())
        MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.your_elo_title)
            .setMessage(R.string.your_elo_message)
            .setView(view)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val parsed = input.text?.toString()?.trim()?.toIntOrNull() ?: return@setPositiveButton
                Prefs.setUserElo(requireContext(), parsed)
                renderIdentity()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }
}
