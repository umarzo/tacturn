package com.tacturn.chess.ui

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tacturn.chess.databinding.ActivitySplashBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Brief branding splash, then straight to the main hub. The green window
 * background (theme) guarantees there is never a white flash at launch.
 */
@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.logoMark.alpha = 0f
        binding.wordmark.alpha = 0f
        binding.tagline.alpha = 0f
        binding.logoMark.animate().alpha(1f).setDuration(350).start()
        binding.wordmark.animate().alpha(1f).setStartDelay(120).setDuration(350).start()
        binding.tagline.animate().alpha(1f).setStartDelay(260).setDuration(350).start()

        // fast start — the splash is brief (cold start < 2 s) and the
        // native engine lazy-loads only when Play/Analysis is entered.
        lifecycleScope.launch {
            delay(700)
            if (isFinishing) return@launch
            startActivity(Intent(this@SplashActivity, MainActivity::class.java))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                // Android 14+ replacement for the deprecated overridePendingTransition.
                overrideActivityTransition(
                    Activity.OVERRIDE_TRANSITION_OPEN,
                    android.R.anim.fade_in,
                    android.R.anim.fade_out
                )
            } else {
                @Suppress("DEPRECATION")
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            }
            finish()
        }
    }
}
