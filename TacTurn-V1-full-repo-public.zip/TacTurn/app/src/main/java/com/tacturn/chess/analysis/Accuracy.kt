package com.tacturn.chess.analysis

import com.tacturn.chess.engine.Searcher
import kotlin.math.exp

/*
 * TacTurn v2 — accuracy + performance-rating math (ANALYSIS OVERHAUL).
 *
 * Design goals (fixing the v1 failure modes reported as "ratings are
 * extremely inaccurate in every kind of game"):
 *
 *  1. EVERYTHING downstream of the raw evals is judged in WIN-PERCENT
 *     space, never in raw centipawns. A 200 cp give-back at +9 is a ~3.5%
 *     win% drop (harmless), the same 200 cp at equality is a ~17.6% drop
 *     (a real error). The v1 raw-cp thresholds called both "Mistake" —
 *     the single biggest source of absurd flags in human games.
 *
 *  2. Game accuracy is the MEAN of the per-move accuracies over the
 *     non-book moves — the same statistic Lichess publishes, so the
 *     number users see is directly comparable to the platforms they
 *     know. The v1 "live-phase gating" (drop every move once |eval| >
 *     500) + "worst-quartile blend" invented a different statistic that
 *     read low and behaved inconsistently between won and lost games.
 *
 *  3. Book (known-theory) moves are excluded from the aggregates, as on
 *     Lichess/chess.com. Judging opening theory with a depth-18 search
 *     only measures the engine's opening preferences, not the player.
 *
 *  4. Performance Elo is a monotone anchor-curve mapping of mean move
 *     accuracy onto the Elo scale (calibrated to the accuracy↔rating
 *     bands observed on the big platforms), with shrinkage toward a
 *     prior for very short games. It replaces the v1 ad-hoc 3-feature
 *     regression whose "cp surrendered while already winning" feature
 *     punished the WINNER of a game for harmless coasting moves — the
 *     "a good game reads as low Elo" failure.
 *
 * Per-move math follows Lichess's published methodology
 * (https://lichess.org/page/accuracy):
 *   win%      = 50 + 50 * (2 / (1 + exp(-0.00368208 * cp)) - 1)
 *   accuracy  = 103.1668 * exp(-0.04354 * win% drop) - 3.1669  (+1)
 */
object Accuracy {

    /** Win probability (percent 0..100) for a centipawn score. */
    fun winPercent(cp: Int): Double {
        val c = cp.coerceIn(-1500, 1500)
        return 50.0 + 50.0 * (2.0 / (1.0 + exp(-0.00368208 * c)) - 1.0)
    }

    /**
     * Per-move accuracy in percent (0..100) from the win% drop.
     * Matches Lichess exactly: if the move IMPROVED win% (or held it), the
     * move is unambiguously accurate (100%) — the exponential curve only
     * applies to an actual drop. A small "+1" uncertainty bonus (Lichess's
     * own constant, acknowledging the eval itself is an estimate) is added
     * before clamping.
     */
    fun moveAccuracy(beforeCp: Int, afterCp: Int): Double {
        val before = winPercent(beforeCp)
        val after = winPercent(afterCp)
        if (after >= before) return 100.0
        val drop = before - after
        val a = 103.1668100711649 * exp(-0.04354415386753951 * drop) - 3.166924740191411 + 1.0
        return a.coerceIn(0.0, 100.0)
    }

    /**
     * Win% LOST by a move (mover POV), >= 0. The classification and
     * aggregate signal for the whole review — saturates naturally in
     * decided positions, which raw centipawns never do.
     */
    fun winDrop(beforeCp: Int, afterCp: Int): Double {
        val b = winPercent(beforeCp)
        val a = winPercent(afterCp)
        return if (a >= b) 0.0 else b - a
    }

    /** Convert an engine score (cp or mate) to a clamp-safe cp value. */
    fun toCp(score: Int): Int = when {
        score >= Searcher.MATE_BOUND -> 1500
        score <= -Searcher.MATE_BOUND -> -1500
        else -> score.coerceIn(-1500, 1500)
    }

    /** Centipawn loss of a move, from the mover's POV (>= 0, <= 1000).
     *  Display-only now — classification uses [winDrop]. */
    fun cpLoss(beforeCp: Int, afterCp: Int): Int =
        (toCp(beforeCp) - toCp(afterCp)).coerceIn(0, 1000)

    // ---- game aggregates ------------------------------------------------

    /**
     * One judged move: the eval before (mover POV) and after (mover POV),
     * plus whether it was known opening theory.
     */
    data class MoveEval(val beforeCp: Int, val afterCp: Int, val isBook: Boolean)

    /**
     * Game accuracy in percent: the mean of the per-move accuracies over
     * the non-book moves (Lichess's published statistic). Book moves are
     * excluded; decided-phase moves are INCLUDED — the win% sigmoid
     * already saturates there, so coasting moves neither inflate nor
     * wash out anything. Games with no judged moves return 100 by
     * convention (the performance-Elo model shrinks those to the prior).
     */
    fun gameAccuracy(evals: List<MoveEval>): Double {
        val judged = evals.filter { !it.isBook }
        if (judged.isEmpty()) return 100.0
        var sum = 0.0
        for (e in judged) sum += moveAccuracy(e.beforeCp, e.afterCp)
        return sum / judged.size
    }

    // ---- performance Elo -------------------------------------------------
    //
    // A monotone piecewise-linear curve maps mean move accuracy onto the
    // Elo scale, anchored on the accuracy bands empirically associated
    // with each rating level on the major platforms (rapid/classical):
    //   ~2500+ -> 97-99%   ~2000 -> 92-94%   ~1500 -> 84-88%
    //   ~1000  -> 66-72%   ~800  -> 58-66%
    // Short judged games shrink toward a neutral prior — five clean moves
    // are not a 2700 performance, and a blunder is not a rating verdict.

    private val ELO_PRIOR = 1200.0
    private const val ELO_SHRINK = 8.0

    private val ANCHORS = arrayOf(
        100.0 to 2900.0,
        98.0 to 2620.0,
        96.0 to 2400.0,
        94.0 to 2230.0,
        92.0 to 2090.0,
        90.0 to 1970.0,
        88.0 to 1870.0,
        86.0 to 1780.0,
        84.0 to 1700.0,
        82.0 to 1630.0,
        80.0 to 1570.0,
        78.0 to 1510.0,
        76.0 to 1460.0,
        74.0 to 1410.0,
        72.0 to 1365.0,
        70.0 to 1320.0,
        66.0 to 1240.0,
        62.0 to 1170.0,
        58.0 to 1110.0,
        54.0 to 1050.0,
        50.0 to 990.0,
        46.0 to 930.0,
        42.0 to 880.0,
        38.0 to 830.0,
        34.0 to 790.0,
        30.0 to 750.0,
        26.0 to 715.0,
        22.0 to 685.0,
        18.0 to 660.0,
        14.0 to 640.0,
        10.0 to 620.0,
        5.0 to 600.0,
        0.0 to 580.0
    )

    /** Monotone interpolation of the accuracy->Elo anchor curve. */
    private fun eloForAccuracy(acc: Double): Double {
        val a = acc.coerceIn(0.0, 100.0)
        if (a >= ANCHORS.first().first) return ANCHORS.first().second
        for (i in 0 until ANCHORS.size - 1) {
            val (a0, e0) = ANCHORS[i]
            val (a1, e1) = ANCHORS[i + 1]
            if (a <= a0 && a >= a1) {
                val t = if (a0 == a1) 0.0 else (a0 - a) / (a0 - a1)
                return e0 + t * (e1 - e0)
            }
        }
        return ANCHORS.last().second
    }

    /**
     * Performance Elo for one player's game from the same judged moves
     * [gameAccuracy] consumes. Calibrated against real rating bands, not
     * against the accuracy% scalar of the old model; shrinks toward the
     * 1200 prior when few moves were judged.
     */
    fun performanceElo(evals: List<MoveEval>): Int {
        val judged = evals.filter { !it.isBook }
        val n = judged.size
        if (n == 0) return ELO_PRIOR.toInt()
        val acc = gameAccuracy(evals)
        val raw = eloForAccuracy(acc)
        val shrunk = ELO_PRIOR + (n / (n + ELO_SHRINK)) * (raw - ELO_PRIOR)
        return shrunk.toInt().coerceIn(300, 2900)
    }
}

/** Verbal + badge classification of a single move (adapted per Elo tier). */
enum class MoveClass(val shortLabel: String) {
    BOOK("Book"),
    BEST("Best"),
    EXCELLENT("Excellent"),
    GOOD("Good"),
    INACCURACY("Inaccuracy"),
    MISTAKE("Mistake"),
    BLUNDER("Blunder");

    companion object {
        /**
         * Classification from the move's WIN% DROP — the industry-standard
         * approach (Lichess/chess.com). Brackets (drop in win% points at
         * equality, with the Lichess win% curve):
         *      <= 0.5  Best (also when the engine's top move was played)
         *      <  2    Excellent      (~ 12 cp slip at equality)
         *      <  4    Good           (~ quarter-pawn slip)
         *      <  8    Inaccuracy     (~ half-pawn slip)
         *      <  15   Mistake        (~ a full pawn at equality)
         *      >= 15   Blunder        (~ two pawns / a piece at equality)
         * Because these live in win% space they saturate naturally in
         * won/lost positions: giving back 200 cp of a +9 lead is a ~3.5%
         * drop — "Good", not the v1 raw-cp "Mistake".
         *
         * Club tiers keep a mild leniency factor (their blunder bar is a
         * little wider, as on chess.com's level-aware review) — display
         * only; the accuracy/Elo aggregates always use the raw drop.
         */
        fun fromWinDrop(dropPercent: Double, playedBest: Boolean, elo: Int): MoveClass {
            val leniency = when {
                elo <= 1000 -> 0.75
                elo <= 1800 -> 0.90
                else -> 1.0
            }
            val d = dropPercent * leniency
            return when {
                playedBest -> BEST
                d <= 0.5 -> BEST
                d < 2.0 -> EXCELLENT
                d < 4.0 -> GOOD
                d < 8.0 -> INACCURACY
                d < 15.0 -> MISTAKE
                else -> BLUNDER
            }
        }
    }
}

/** Practicality heuristic (Beginner/Club only): how forgiving a move is. */
enum class Practicality(val label: String) {
    SOLID("Solid"),
    RISKY("Risky"),
    SHARP("Sharp");

    companion object {
        /** @param dropPct win% drop of the move; @param materialSwing how
         *  much material the mover gives up along the engine's line (cp). */
        fun of(dropPct: Double, materialSwing: Int): Practicality = when {
            materialSwing >= 300 -> SHARP
            dropPct < 5.0 -> SOLID
            else -> RISKY
        }
    }
}
