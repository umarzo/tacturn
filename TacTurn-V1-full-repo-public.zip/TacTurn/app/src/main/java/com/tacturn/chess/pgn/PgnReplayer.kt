package com.tacturn.chess.pgn

import com.tacturn.chess.engine.BISHOP
import com.tacturn.chess.engine.KING
import com.tacturn.chess.engine.KNIGHT
import com.tacturn.chess.engine.QUEEN
import com.tacturn.chess.engine.ROOK
import com.tacturn.chess.engine.PAWN
import com.tacturn.chess.engine.fileOf
import com.tacturn.chess.engine.isCastleK
import com.tacturn.chess.engine.isCastleQ
import com.tacturn.chess.engine.moveFrom
import com.tacturn.chess.engine.movePiece
import com.tacturn.chess.engine.movePromo
import com.tacturn.chess.engine.moveTo
import com.tacturn.chess.engine.rankOf
import com.tacturn.chess.engine.squareFromName

/*
 * TacTurn v1 — structural SAN matcher + game replayer.
 *
 * SAN tokens are matched against the engine's legal-move list by structure
 * (piece, disambiguation, target square, promotion) instead of generating
 * and comparing SAN strings — an order of magnitude cheaper and immune to
 * annotation noise. Tolerated input quirks:
 *   - trailing "!?", "+", "#", "e.p."
 *   - both castling spellings (O-O / 0-0)
 *   - missing or redundant disambiguation (resolved when unambiguous)
 *   - promotions with or without "=" ("e8Q", "e8=Q")
 */

object SanMatcher {

    private val SAN_RE = Regex(
        """^([KQRBN])?([a-h])?([1-8])?(x)?([a-h][1-8])(?:=?([QRBN]))?$"""
    )

    /**
     * Resolves one SAN token to a legal engine move.
     * @return the move int, or null when nothing legal matches.
     */
    fun match(sanRaw: String, legal: List<Int>): Int? {
        var s = sanRaw.trim()
        // Strip annotation suffixes (repeatedly: "!?+", "e.p.").
        while (s.isNotEmpty() && s.last() in "!?+#") s = s.dropLast(1)
        if (s.endsWith("e.p.")) s = s.removeSuffix("e.p.").trim()
        if (s.isEmpty()) return null

        // Castling.
        if (s == "O-O" || s == "0-0" || s == "OO") return legal.firstOrNull { isCastleK(it) }
        if (s == "O-O-O" || s == "0-0-0" || s == "OOO") return legal.firstOrNull { isCastleQ(it) }

        val m = SAN_RE.matchEntire(s) ?: return null
        val pieceChar = m.groupValues[1].ifBlank { null }
        val disambigFile = m.groupValues[2].ifBlank { null }?.get(0)
        val disambigRank = m.groupValues[3].ifBlank { null }?.get(0)
        val target = squareFromName(m.groupValues[5]) ?: return null
        val promoChar = m.groupValues[6].ifBlank { null }?.get(0)

        val piece = when (pieceChar) {
            "K" -> KING
            "Q" -> QUEEN
            "R" -> ROOK
            "B" -> BISHOP
            "N" -> KNIGHT
            else -> PAWN
        }
        val promo = when (promoChar) {
            'Q' -> QUEEN
            'R' -> ROOK
            'B' -> BISHOP
            'N' -> KNIGHT
            else -> 0
        }

        var candidates = legal.filter { movePiece(it) == piece && moveTo(it) == target }
        candidates = if (promo != 0) {
            candidates.filter { movePromo(it) == promo }
        } else {
            // A bare "e8" (no promo) must mean a non-promotion move; for
            // pawns reaching the last rank the SAN is always "e8=Q"-style.
            candidates.filter { movePromo(it) == 0 }
        }
        if (disambigFile != null) candidates = candidates.filter { fileOf(moveFrom(it)) == disambigFile - 'a' }
        if (disambigRank != null) candidates = candidates.filter { rankOf(moveFrom(it)) == disambigRank - '1' }

        return when {
            candidates.isEmpty() -> null
            candidates.size == 1 -> candidates[0]
            else -> {
                // Sloppy PGN without needed disambiguation: accept when all
                // remaining candidates share the same origin square.
                val froms = candidates.map { moveFrom(it) }.distinct()
                if (froms.size == 1) candidates[0] else null
            }
        }
    }
}

/** One successfully replayed ply. */
data class Ply(
    val move: Int,          // engine move int
    val san: String,        // canonical SAN from the engine
    val fenBefore: String   // FEN before this ply
)

/**
 * Replays parsed SAN tokens on an engine [Game] session. The session ends
 * positioned at the final ply; callers can undo()/reset() afterwards.
 */
class PgnReplayer(private val game: com.tacturn.chess.engine.Game) {

    data class ReplayOutcome(
        val plies: List<Ply>,
        val startFen: String,
        val result: String?,              // from headers, if present
        /** Index of the first token that could NOT be replayed (-1 = all). */
        val failedAt: Int,
        val failedToken: String?
    )

    /** @throws PgnParseException when the start FEN is invalid. */
    fun replay(parsed: ParsedPgn): ReplayOutcome {
        val startFen = parsed.startFen
        if (startFen != null) {
            if (!game.setFen(startFen)) throw PgnParseException("invalid FEN header")
        } else {
            game.reset()
        }

        val plies = ArrayList<Ply>(parsed.sanTokens.size)
        var failedAt = -1
        var failedToken: String? = null
        for ((index, token) in parsed.sanTokens.withIndex()) {
            val fenBefore = game.fen()
            val legal = game.legalMoves()
            val move = SanMatcher.match(token, legal)
            if (move == null || move !in legal) {
                failedAt = index
                failedToken = token
                break
            }
            val canonicalSan = game.makeMove(move)
            plies.add(Ply(move, canonicalSan, fenBefore))
        }
        return ReplayOutcome(plies, game.fen(), parsed.result, failedAt, failedToken)
    }

    companion object {
        /** Human-friendly description of a replay failure (never throws). */
        fun describeFailure(outcome: ReplayOutcome): String {
            val at = outcome.failedAt
            val token = outcome.failedToken ?: "?"
            return "Move ${at + 1} (\"${token}\") could not be replayed — " +
                "the game was imported up to that point."
        }
    }
}
