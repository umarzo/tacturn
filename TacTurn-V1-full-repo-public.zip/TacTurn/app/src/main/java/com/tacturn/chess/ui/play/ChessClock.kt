package com.tacturn.chess.ui.play

import android.os.SystemClock
import com.tacturn.chess.engine.BLACK
import com.tacturn.chess.engine.WHITE

/*
 * TacTurn v2 — the chess clock.
 *
 * One immutable TimeControl + mutable per-side remaining time, driven by
 * monotonic elapsed-realtime so wall-clock changes can never distort it.
 *
 * The protocol (mirrors a real DGT clock):
 *   start()          -> White's clock begins running.
 *   onMoveMade(color)-> settles `color`'s elapsed time, adds the Fischer
 *                       increment to `color`, then starts the opponent's
 *                       clock.
 *   pause()/resume() -> freeze / unfreeze the running side (app in
 *                       background, game-over review, etc.).
 *
 * Nothing here is thread-safe by itself — the owning ViewModel serializes
 * every mutation on the engine dispatcher and the ticker only READS
 * [remaining], which is computed from monotonic timestamps (a torn read
 * degrades to a ~ms-stale display value, never a wrong game decision).
 */
class ChessClock(private val control: TimeControl) {

    /** Remaining time per color in ms (settled base; live deduction on read). */
    private val remainingMs = longArrayOf(control.initialMs, control.initialMs)

    /** The side whose clock is currently running: WHITE / BLACK, or -1 when stopped. */
    private var runningSide = -1

    /** The side that was running when [pause] was called (for a correct resume). */
    private var pausedSide = -1

    /** Monotonic timestamp (elapsedRealtimeNanos) of the last settle/switch. */
    private var lastTickNanos = 0L

    /** Set once a side's time is exhausted; game logic acts on this. */
    private var flaggedSide = -1

    val hasClock: Boolean get() = !control.isUnlimited
    val incrementMs: Long get() = control.incrementMs

    /** True while either side's clock is actively ticking. */
    val isRunning: Boolean get() = runningSide != -1

    // ------------------------------------------------------------------
    // Lifecycle
    // ------------------------------------------------------------------

    /** Starts White's clock (standard rule: White's time runs from move one). */
    fun start() {
        if (!hasClock) return
        remainingMs[WHITE] = control.initialMs
        remainingMs[BLACK] = control.initialMs
        flaggedSide = -1
        pausedSide = -1
        runningSide = WHITE
        lastTickNanos = SystemClock.elapsedRealtimeNanos()
    }

    fun reset() {
        remainingMs[WHITE] = control.initialMs
        remainingMs[BLACK] = control.initialMs
        runningSide = -1
        pausedSide = -1
        flaggedSide = -1
        lastTickNanos = 0L
    }

    /** Freezes the running side. Safe to call when already stopped. */
    fun pause() {
        if (runningSide == -1) return
        settle(runningSide)
        pausedSide = runningSide
        runningSide = -1
    }

    /** Resumes the side that was paused. No-op when nothing was paused. */
    fun resume() {
        if (runningSide != -1 || pausedSide == -1) return
        runningSide = pausedSide
        pausedSide = -1
        lastTickNanos = SystemClock.elapsedRealtimeNanos()
    }

    // ------------------------------------------------------------------
    // Move protocol
    // ------------------------------------------------------------------

    /**
     * Call immediately after `color` completed a move on the board:
     * deducts the elapsed thinking time from `color`, grants the increment,
     * then starts the opponent's clock.
     */
    fun onMoveMade(color: Int) {
        if (!hasClock) return
        if (runningSide == color) {
            settle(color)
        }
        if (flaggedSide == -1 && control.incrementMs > 0) {
            remainingMs[color] = (remainingMs[color] + control.incrementMs).coerceAtMost(MAX_TIME_MS)
        }
        // Hand the turn over — even if `color` just flagged, the flag is
        // reported by [flaggedSide] and the game layer ends the game.
        if (flaggedSide == -1) {
            runningSide = color xor 1
            lastTickNanos = SystemClock.elapsedRealtimeNanos()
        }
    }

    // ------------------------------------------------------------------
    // Reads
    // ------------------------------------------------------------------

    /** Live remaining time for a side (includes the running deduction). */
    fun remaining(color: Int): Long {
        val base = remainingMs[color]
        if (runningSide != color) return base
        val elapsedMs = (SystemClock.elapsedRealtimeNanos() - lastTickNanos) / 1_000_000L
        return (base - elapsedMs).coerceAtLeast(0L)
    }

    /** The side whose time ran out, or -1. Latched once set. */
    fun flagged(): Int = flaggedSide

    /** The side whose clock is currently ticking (-1 when paused/stopped). */
    fun activeSide(): Int = runningSide

    /** True while the clock is deliberately frozen (app in background). */
    fun isPaused(): Boolean = runningSide == -1 && pausedSide != -1

    /** True when `color` is below the low-time threshold (drives the red clock). */
    fun isLowTime(color: Int): Boolean =
        hasClock && control.isLowTime(remaining(color))

    /**
     * Live flag check from the owning (engine) thread: if the running
     * side's time has crossed zero, bake it in and latch the flag.
     * Returns the flagged color or -1.
     */
    fun checkFlag(): Int {
        if (runningSide != -1 && remaining(runningSide) <= 0L) {
            settle(runningSide)
        }
        return flaggedSide
    }

    /**
     * Forces the running side (undo/takeback support): settles whoever was
     * running, then hands the clock to `color` WITHOUT an increment.
     */
    fun setRunning(color: Int) {
        if (!hasClock) return
        if (runningSide != -1) settle(runningSide)
        pausedSide = -1
        if (flaggedSide == -1) {
            runningSide = color
            lastTickNanos = SystemClock.elapsedRealtimeNanos()
        }
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------

    /** Bakes the running side's elapsed time into its stored remainder. */
    private fun settle(color: Int) {
        val elapsedMs = (SystemClock.elapsedRealtimeNanos() - lastTickNanos) / 1_000_000L
        remainingMs[color] = (remainingMs[color] - elapsedMs).coerceAtLeast(0L)
        if (remainingMs[color] <= 0L && flaggedSide == -1) flaggedSide = color
        lastTickNanos = SystemClock.elapsedRealtimeNanos()
        if (remainingMs[color] <= 0L) runningSide = -1
    }

    private companion object {
        /** Safety ceiling so repeated increments can never overflow display. */
        const val MAX_TIME_MS = 6L * 3_600_000L
    }
}
