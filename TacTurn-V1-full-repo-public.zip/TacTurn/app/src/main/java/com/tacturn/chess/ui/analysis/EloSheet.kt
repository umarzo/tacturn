package com.tacturn.chess.ui.analysis

import android.view.LayoutInflater
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.tacturn.chess.R
import com.tacturn.chess.analysis.EloProfile
import com.tacturn.chess.databinding.SheetEloBinding

/**
 * The personalization hook: "What is your current Elo?"
 *
 * An elegant Material bottom sheet with quick-select chips for the common
 * levels (100, 800, 1200, 1500, 1800, 2200, 2700+), a fine-grained slider
 * and a tier description that updates live.
 */
class EloSheet(
    private val host: AnalysisActivity,
    private val currentElo: Int,
    @Suppress("UNUSED_PARAMETER") allow2700: Boolean,
    private val onConfirm: (Int) -> Unit
) {

    private var dialog: BottomSheetDialog? = null
    private var binding: SheetEloBinding? = null

    fun show() {
        val sheet = BottomSheetDialog(host, R.style.ThemeOverlay_TacTurn_BottomSheet)
        dialog = sheet
        val b = SheetEloBinding.inflate(LayoutInflater.from(host))
        binding = b
        sheet.setContentView(b.root)

        var elo = currentElo.coerceIn(100, 3000)
        b.eloSlider.valueFrom = 100f
        b.eloSlider.valueTo = 3000f
        b.eloSlider.stepSize = 50f
        // Values must sit on step multiples; stored prefs may not be.
        b.eloSlider.value = ((elo / 50) * 50).coerceIn(100, 3000).toFloat()
        elo = (elo / 50) * 50
        render(b, elo)

        b.eloSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                elo = value.toInt()
                render(b, elo)
            }
        }

        // Quick-select chips (inflated into the ChipGroup).
        for (level in EloProfile.QUICK_LEVELS) {
            val chip = host.layoutInflater
                .inflate(R.layout.item_elo_chip, b.quickLevels, false)
                as com.google.android.material.chip.Chip
            chip.text = if (level >= 2700) "2700+" else level.toString()
            chip.setOnClickListener {
                elo = level
                b.eloSlider.value = level.toFloat()
                render(b, elo)
            }
            b.quickLevels.addView(chip)
        }

        b.btnConfirmElo.setOnClickListener {
            sheet.dismiss()
            onConfirm(elo)
        }

        sheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        sheet.show()
    }

    private fun render(b: SheetEloBinding, elo: Int) {
        b.eloValue.text = if (elo >= 2700) "$elo+" else elo.toString()
        val profile = EloProfile.fromElo(elo)
        b.tierName.text = profile.tier.label
        b.tierDescription.text = describeTier(profile)
    }

    private fun describeTier(p: EloProfile): String = when (p.tier) {
        com.tacturn.chess.analysis.SkillTier.BEGINNER ->
            "Rounded scores, plain-language coaching, safe suggestions."
        com.tacturn.chess.analysis.SkillTier.CLUB ->
            "Rounded scores, practicality notes, obvious-move guidance."
        com.tacturn.chess.analysis.SkillTier.ADVANCED ->
            "Raw centipawns, top 3 engine lines, sharp moves tagged."
        com.tacturn.chess.analysis.SkillTier.MASTER ->
            "Unfiltered analysis at maximum depth."
    }

    fun dismiss() {
        dialog?.dismiss()
        dialog = null
        binding = null
    }
}
