package com.tacturn.chess.ui

/*
 * TacTurn v2 — opening-name detection.
 *
 * A curated ECO-style book of the ~110 most common openings, matched by
 * longest SAN-move prefix. Every key is a space-joined sequence of native
 * SAN tokens (castles as "O-O", checks with "+"), exactly as the engine
 * emits them — so no normalization is needed on the game side.
 *
 * Transpositions degrade gracefully: the walk simply keeps the deepest
 * matched name, exactly like the lightweight ECO badges in lichess/chess.com.
 */
object Openings {

    // The first move that is still "unknown" (e.g. 1.a3) yields "" and the
    // UI hides the badge.
    private val BOOK: Map<String, String> = mapOf(
        // ---- first moves -------------------------------------------------
        "e4" to "King's Pawn Opening",
        "d4" to "Queen's Pawn Opening",
        "c4" to "English Opening",
        "Nf3" to "Zukertort Opening",
        "f4" to "Bird's Opening",
        "b3" to "Nimzo-Larsen Attack",
        "g3" to "Benko Opening",
        "g4" to "Grob's Attack",
        "Nc3" to "Van Geet Opening",
        "e3" to "Van 't Kruijs Opening",
        "c3" to "Saragossa Opening",
        "b4" to "Polish Opening",

        // ---- 1.e4 e5 : open games ---------------------------------------
        "e4 e5" to "Open Game",
        "e4 e5 f4" to "King's Gambit",
        "e4 e5 f4 exf4" to "King's Gambit Accepted",
        "e4 e5 f4 d5" to "King's Gambit Declined: Falkbeer Countergambit",
        "e4 e5 Bc4" to "Bishop's Opening",
        "e4 e5 Nc3" to "Vienna Game",
        "e4 e5 Nc3 Nf6 f4" to "Vienna Gambit",
        "e4 e5 d4 exd4 Qxd4" to "Centre Game",
        "e4 e5 d4 exd4 c3" to "Danish Gambit",
        "e4 e5 Nf3" to "King's Knight Opening",
        "e4 e5 Nf3 f5" to "Latvian Gambit",
        "e4 e5 Nf3 d5" to "Elephant Gambit",
        "e4 e5 Nf3 d6" to "Philidor Defence",
        "e4 e5 Nf3 Nf6" to "Petrov's Defence",
        "e4 e5 Nf3 Nf6 Nxe5 d6 Nf3 Nxe4" to "Petrov's Defence: Stafford Gambit",

        // ---- 1.e4 e5 2.Nf3 Nc6 : Ruy Lopez family ------------------------
        "e4 e5 Nf3 Nc6 Bb5" to "Ruy Lopez",
        "e4 e5 Nf3 Nc6 Bb5 a6" to "Ruy Lopez: Morphy Defence",
        "e4 e5 Nf3 Nc6 Bb5 Nf6" to "Ruy Lopez: Berlin Defence",
        "e4 e5 Nf3 Nc6 Bb5 Bc5" to "Ruy Lopez: Classical Variation",
        "e4 e5 Nf3 Nc6 Bb5 a6 Bxc6" to "Ruy Lopez: Exchange Variation",
        "e4 e5 Nf3 Nc6 Bb5 a6 Ba4" to "Ruy Lopez: Morphy Defence",
        "e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Nxe4" to "Ruy Lopez: Open Variation",
        "e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Be7" to "Ruy Lopez: Closed Variation",
        "e4 e5 Nf3 Nc6 Bb5 a6 Ba4 Nf6 O-O Be7 Re1 b5 Bb3 d6 c3 O-O" to
                "Ruy Lopez: Closed, Main Line",

        // ---- 1.e4 e5 2.Nf3 Nc6 : Italian family --------------------------
        "e4 e5 Nf3 Nc6 Bc4" to "Italian Game",
        "e4 e5 Nf3 Nc6 Bc4 Bc5" to "Italian Game: Giuoco Piano",
        "e4 e5 Nf3 Nc6 Bc4 Bc5 b4" to "Evans Gambit",
        "e4 e5 Nf3 Nc6 Bc4 Bc5 d3" to "Italian Game: Giuoco Pianissimo",
        "e4 e5 Nf3 Nc6 Bc4 Be7" to "Italian Game: Hungarian Defence",
        "e4 e5 Nf3 Nc6 Bc4 Nf6" to "Two Knights Defence",
        "e4 e5 Nf3 Nc6 Bc4 Nf6 Ng5" to "Two Knights Defence: Knight Attack",
        "e4 e5 Nf3 Nc6 Bc4 Nf6 d3" to "Italian Game: Anti-Two Knights",

        // ---- 1.e4 e5 2.Nf3 Nc6 : others ----------------------------------
        "e4 e5 Nf3 Nc6 d4" to "Scotch Game",
        "e4 e5 Nf3 Nc6 d4 exd4 Bc4" to "Scotch Gambit",
        "e4 e5 Nf3 Nc6 d4 exd4 Nxd4" to "Scotch Game: Main Line",
        "e4 e5 Nf3 Nc6 c3" to "Ponziani Opening",
        "e4 e5 Nf3 Nc6 Nc3 Nf6" to "Four Knights Game",
        "e4 e5 Nf3 Nc6 Nc3 Nf6 Bb5" to "Four Knights Game: Spanish Variation",

        // ---- Sicilian -----------------------------------------------------
        "e4 c5" to "Sicilian Defence",
        "e4 c5 c3" to "Sicilian Defence: Alapin Variation",
        "e4 c5 Nc3" to "Sicilian Defence: Closed",
        "e4 c5 Nc3 Nc6 f4" to "Sicilian Defence: Grand Prix Attack",
        "e4 c5 d4 cxd4 c3" to "Sicilian Defence: Smith-Morra Gambit",
        "e4 c5 Nf3 Nc6 Bb5" to "Sicilian Defence: Rossolimo Attack",
        "e4 c5 Nf3 d6 Bb5+" to "Sicilian Defence: Moscow Variation",
        "e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 a6" to "Sicilian Defence: Najdorf Variation",
        "e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 g6" to "Sicilian Defence: Dragon Variation",
        "e4 c5 Nf3 d6 d4 cxd4 Nxd4 Nf6 Nc3 e6" to "Sicilian Defence: Scheveningen Variation",
        "e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 Nf6 Nc3 e5" to "Sicilian Defence: Sveshnikov Variation",
        "e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 g6" to "Sicilian Defence: Accelerated Dragon",
        "e4 c5 Nf3 Nc6 d4 cxd4 Nxd4 Nf6 Nc3 Nc6" to "Sicilian Defence: Classical Variation",

        // ---- French -------------------------------------------------------
        "e4 e6" to "French Defence",
        "e4 e6 d4 d5" to "French Defence",
        "e4 e6 d4 d5 Nc3 Bb4" to "French Defence: Winawer Variation",
        "e4 e6 d4 d5 Nc3 Nf6" to "French Defence: Classical Variation",
        "e4 e6 d4 d5 Nc3 dxe4" to "French Defence: Rubinstein Variation",
        "e4 e6 d4 d5 Nd2" to "French Defence: Tarrasch Variation",
        "e4 e6 d4 d5 e5" to "French Defence: Advance Variation",
        "e4 e6 d4 d5 e5 c5" to "French Defence: Advance Variation",
        "e4 e6 d4 d5 exd5" to "French Defence: Exchange Variation",

        // ---- Caro-Kann ----------------------------------------------------
        "e4 c6" to "Caro-Kann Defence",
        "e4 c6 d4 d5" to "Caro-Kann Defence",
        "e4 c6 d4 d5 e5" to "Caro-Kann Defence: Advance Variation",
        "e4 c6 d4 d5 exd5 cxd5" to "Caro-Kann Defence: Exchange Variation",
        "e4 c6 d4 d5 exd5 cxd5 c4" to "Caro-Kann Defence: Panov Attack",
        "e4 c6 d4 d5 Nc3 dxe4" to "Caro-Kann Defence: Classical Variation",

        // ---- 1.e4 others --------------------------------------------------
        "e4 d5" to "Scandinavian Defence",
        "e4 d5 exd5 Qxd5" to "Scandinavian Defence: Main Line",
        "e4 d5 exd5 Qxd5 Nc3 Qa5" to "Scandinavian Defence: Main Line",
        "e4 d5 exd5 Nf6" to "Scandinavian Defence: Modern Variation",
        "e4 Nf6" to "Alekhine Defence",
        "e4 Nf6 e5 Nd5 d4 d6" to "Alekhine Defence",
        "e4 d6" to "Pirc Defence",
        "e4 d6 d4 Nf6 Nc3 g6" to "Pirc Defence",
        "e4 g6" to "Modern Defence",
        "e4 g6 d4" to "Modern Defence",

        // ---- 1.d4 d5 : Queen's Gambit complex -----------------------------
        "d4 d5" to "Closed Game",
        "d4 d5 c4" to "Queen's Gambit",
        "d4 d5 c4 dxc4" to "Queen's Gambit Accepted",
        "d4 d5 c4 e6" to "Queen's Gambit Declined",
        "d4 d5 c4 e6 Nc3 Nf6" to "Queen's Gambit Declined",
        "d4 d5 c4 e6 Nc3 c5" to "Queen's Gambit Declined: Tarrasch Defence",
        "d4 d5 c4 e6 g3" to "Catalan Opening",
        "d4 d5 c4 c6" to "Slav Defence",
        "d4 d5 c4 c6 Nf3 Nf6 Nc3 e6" to "Semi-Slav Defence",
        "d4 d5 c4 c6 cxd5 cxd5" to "Slav Defence: Exchange Variation",
        "d4 d5 c4 Nc6" to "Chigorin Defence",
        "d4 d5 c4 e5" to "Albin Countergambit",
        "d4 d5 c4 Bf5" to "Baltic Defence",
        "d4 d5 e4 dxe4 Nc3" to "Blackmar-Diemer Gambit",
        "d4 d5 Bf4" to "London System",
        "d4 d5 Nf3 Nf6 Bf4" to "London System",

        // ---- 1.d4 Nf6 : Indian complex -------------------------------------
        "d4 Nf6" to "Indian Defence",
        "d4 Nf6 c4 e6" to "East Indian Defence",
        "d4 Nf6 c4 e6 Nc3 Bb4" to "Nimzo-Indian Defence",
        "d4 Nf6 c4 e6 Nf3 b6" to "Queen's Indian Defence",
        "d4 Nf6 c4 e6 Nf3 Bb4+" to "Bogo-Indian Defence",
        "d4 Nf6 c4 e6 g3" to "Catalan Opening",
        "d4 Nf6 c4 g6" to "King's Indian Defence",
        "d4 Nf6 c4 g6 Nc3 Bg7 e4 d6" to "King's Indian Defence",
        "d4 Nf6 c4 g6 Nc3 Bg7 e4 d6 f3" to "King's Indian Defence: Sämisch Variation",
        "d4 Nf6 c4 g6 Nc3 Bg7 e4 d6 Nf3 e5" to "King's Indian Defence: Classical Variation",
        "d4 Nf6 c4 g6 Nc3 d5" to "Grünfeld Defence",
        "d4 Nf6 c4 c5" to "Benoni Defence",
        "d4 Nf6 c4 c5 d5 e6" to "Modern Benoni",
        "d4 Nf6 c4 c5 d5 b5" to "Benko Gambit",
        "d4 Nf6 c4 e5" to "Budapest Gambit",
        "d4 Nf6 c4 e5 dxe5 Ng4" to "Budapest Gambit",
        "d4 Nf6 Bg5" to "Trompowsky Attack",
        "d4 Nf6 Nc3 d5 Bg5" to "Veresov Attack",

        // ---- 1.d4 others ----------------------------------------------------
        "d4 c5" to "Old Benoni Defence",
        "d4 f5" to "Dutch Defence",
        "d4 e6" to "Horwitz Defence",

        // ---- flank openings -------------------------------------------------
        "c4 e5" to "English Opening: Reversed Sicilian",
        "c4 c5" to "English Opening: Symmetrical Variation",
        "Nf3 d5 c4" to "Réti Opening"
    )

    /**
     * Longest-prefix opening name for a SAN move list. Returns "" when the
     * line is unknown (the caller hides the badge).
     */
    fun name(sanMoves: List<String>): String {
        if (sanMoves.isEmpty()) return ""
        val sb = StringBuilder()
        var best = ""
        for (i in sanMoves.indices) {
            if (i > 0) sb.append(' ')
            sb.append(sanMoves[i])
            // Prefixes longer than the deepest book line can never match —
            // the longest key is 16 moves.
            if (i >= 16) break
            BOOK[sb.toString()]?.let { best = it }
        }
        return best
    }
}
