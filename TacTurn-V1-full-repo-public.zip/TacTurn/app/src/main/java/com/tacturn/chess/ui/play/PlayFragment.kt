package com.tacturn.chess.ui.play

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.slider.Slider
import com.tacturn.chess.R
import com.tacturn.chess.data.Prefs
import com.tacturn.chess.databinding.FragmentPlayBinding
import com.tacturn.chess.engine.BLACK
import com.tacturn.chess.engine.WHITE

/**
 * TacTurn v2 — the Play tab is now a full "New Game" setup screen:
 *
 *  1. Game mode: Play vs Engine  ·  Pass & Play
 *  2. Time control: Unlimited / Bullet / Blitz / Rapid / Classical presets
 *     (chip grid) + a Custom… dialog (minutes + increment sliders)
 *  3. Mode-specific setup: Elo slider + side (engine) or player names +
 *     auto-flip (pass & play)
 *  4. Options: auto-promote to queen
 *
 * Nothing engine-related happens here — the native session only spins up
 * when the user actually enters a game (fast app start).
 */
class PlayFragment : Fragment() {

    private var _binding: FragmentPlayBinding? = null
    private val binding get() = _binding!!

    /** Sentinel for the "Random side" card — engine colors are 0/1, so -1 is free. */
    private val COLOR_RANDOM = -1

    /** WHITE, BLACK, or [COLOR_RANDOM] while the random card is selected. */
    private var chosenColor = WHITE

    private var mode = GameMode.ENGINE

    /** Index into [TimeControl.PRESETS], or -1 for the custom control. */
    private var tcIndex = 0

    /** Last preset the user had selected — restored if the Custom dialog
     *  is dismissed without applying (previously it always jumped to
     *  Unlimited, silently losing the user's choice). */
    private var lastPresetIndex = 0

    /** The custom control (valid when [tcIndex] == -1). */
    private var customTc = TimeControl.custom(5, 3)

    /** The chip views, parallel to PRESETS + one trailing Custom chip. */
    private lateinit var presetChips: List<Chip>
    private lateinit var customChip: Chip

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPlayBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        restoreLastSetup()
        wireModeCards()
        wireTimeControlChips()
        wireEngineSection()
        wirePvpSection()
        wireOptions()
        wireStart()
        renderMode()
    }

    // ------------------------------------------------------------------
    // Restore / persist the last setup
    // ------------------------------------------------------------------

    private fun restoreLastSetup() {
        val last = GameConfig.fromPrefs(requireContext())
        mode = last.mode
        chosenColor = last.playerColor
        if (last.timeControl.isUnlimited) {
            tcIndex = 0
        } else {
            val idx = TimeControl.PRESETS.indexOfFirst { it == last.timeControl }
            if (idx >= 0) tcIndex = idx else {
                tcIndex = -1
                customTc = last.timeControl
            }
        }
        if (tcIndex >= 0) lastPresetIndex = tcIndex
        binding.whiteNameField.setText(last.whiteName)
        binding.blackNameField.setText(last.blackName)
        binding.autoFlipSwitch.isChecked = last.autoFlip
        binding.autoQueenSwitch.isChecked = Prefs.autoQueen(requireContext())

        val elo = roundToStep(last.engineElo, 25)
        binding.eloSlider.value = elo.toFloat()
        renderElo(elo)
        binding.eloSlider.addSliderChangeListener(
            onSliderChange = { _, value, fromUser ->
                if (fromUser) renderElo(value.toInt())
            }
        )
        renderColorChoice()
    }

    // ------------------------------------------------------------------
    // Game mode
    // ------------------------------------------------------------------

    private fun wireModeCards() {
        binding.engineModeCard.setOnClickListener { mode = GameMode.ENGINE; renderMode() }
        binding.pvpModeCard.setOnClickListener { mode = GameMode.HUMAN; renderMode() }
    }

    private fun renderMode() {
        val selectedStroke = MaterialColors.getColor(
            binding.root, com.google.android.material.R.attr.colorPrimary
        )
        val selectedFill = MaterialColors.getColor(
            binding.root, com.google.android.material.R.attr.colorPrimaryContainer
        )
        val plainStroke = MaterialColors.getColor(
            binding.root, com.google.android.material.R.attr.colorOutlineVariant
        )
        val plainFill = MaterialColors.getColor(
            binding.root, com.google.android.material.R.attr.colorSurface
        )
        fun apply(card: MaterialCardView, chosen: Boolean) {
            card.strokeColor = if (chosen) selectedStroke else plainStroke
            card.strokeWidth = dp(if (chosen) 2 else 1)
            card.setCardBackgroundColor(if (chosen) selectedFill else plainFill)
        }
        apply(binding.engineModeCard, mode == GameMode.ENGINE)
        apply(binding.pvpModeCard, mode == GameMode.HUMAN)

        binding.engineSection.visibility =
            if (mode == GameMode.ENGINE) View.VISIBLE else View.GONE
        binding.pvpSection.visibility =
            if (mode == GameMode.HUMAN) View.VISIBLE else View.GONE
    }

    // ------------------------------------------------------------------
    // Time control
    // ------------------------------------------------------------------

    private fun wireTimeControlChips() {
        val inflater = layoutInflater
        val group = binding.tcChipGroup
        val presets = TimeControl.PRESETS

        presetChips = presets.map { tc ->
            val chip = inflater.inflate(R.layout.item_tc_chip, group, false) as Chip
            chip.text = tc.label
            chip.id = View.generateViewId()
            group.addView(chip)
            chip
        }
        customChip = inflater.inflate(R.layout.item_tc_chip, group, false) as Chip
        customChip.text = getString(R.string.tc_custom)
        customChip.id = View.generateViewId()
        group.addView(customChip)
        refreshCustomChipLabel()

        // Preset selections land here; the Custom chip is driven entirely by
        // its own click listener (so re-tapping it re-opens the editor).
        group.setOnCheckedStateChangeListener { _, checkedIds ->
            val checkedId = checkedIds.firstOrNull() ?: return@setOnCheckedStateChangeListener
            val presetPos = presetChips.indexOfFirst { it.id == checkedId }
            if (presetPos >= 0) {
                tcIndex = presetPos
                lastPresetIndex = presetPos
            }
        }
        customChip.setOnClickListener {
            if (tcIndex != -1) tcIndex = -1   // this tap also checks it in the group
            showCustomTimeDialog()
        }

        // Initial selection.
        if (tcIndex == -1) group.check(customChip.id)
        else presetChips.getOrNull(tcIndex)?.let { group.check(it.id) }

        // The selector is a single-line scroller — make sure the restored
        // selection (e.g. 60+30 at the far end) is actually on screen.
        binding.tcChipScroller.post {
            val selected = if (tcIndex == -1) customChip else presetChips.getOrNull(tcIndex)
            selected?.let { chip ->
                val targetX = chip.left + chip.width / 2 - binding.tcChipScroller.width / 2
                binding.tcChipScroller.smoothScrollTo(targetX.coerceAtLeast(0), 0)
            }
        }
    }

    private fun refreshCustomChipLabel() {
        customChip.text = if (tcIndex == -1) customTc.label
        else getString(R.string.tc_custom)
    }

    private fun showCustomTimeDialog() {
        val pad = dp(20)
        val layout = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(16), pad, dp(8))
        }

        var minutes = customTc.initialMs.toInt() / 60000
        var increment = (customTc.incrementMs / 1000).toInt()

        // One live Apply button inside the dialog body — its label follows
        // the sliders. (The dialog-bar positive button previously duplicated
        // it with a STALE label, so two "Use x+y" buttons were visible.)

        val applyBtn = com.google.android.material.button.MaterialButton(requireContext()).apply {
            text = applyLabel(minutes, increment)
            cornerRadius = dp(24)
        }

        val minutesLabel = TextView(requireContext()).apply {
            text = getString(R.string.tc_custom_minutes)
            textSize = 14f
        }
        val minutesValue = TextView(requireContext()).apply {
            textSize = 22f
            text = "$minutes′"
        }
        val minutesSlider = Slider(requireContext()).apply {
            valueFrom = 1f
            valueTo = 120f
            stepSize = 1f
            value = minutes.toFloat()
            addOnChangeListener { _, v, _ ->
                minutes = v.toInt()
                minutesValue.text = "$minutes′"
                applyBtn.text = applyLabel(minutes, increment)
            }
        }
        val incLabel = TextView(requireContext()).apply {
            text = getString(R.string.tc_custom_increment)
            textSize = 14f
        }
        val incValue = TextView(requireContext()).apply {
            textSize = 22f
            text = "${increment}s"
        }
        val incSlider = Slider(requireContext()).apply {
            valueFrom = 0f
            valueTo = 60f
            stepSize = 1f
            value = increment.toFloat()
            addOnChangeListener { _, v, _ ->
                increment = v.toInt()
                incValue.text = "${increment}s"
                applyBtn.text = applyLabel(minutes, increment)
            }
        }

        listOf(
            minutesLabel, minutesValue, minutesSlider,
            incLabel, incValue, incSlider, applyBtn
        ).forEach { layout.addView(it) }

        fun applySelection() {
            customTc = TimeControl.custom(minutes, increment)
            refreshCustomChipLabel()
            Prefs.setCustomTc(requireContext(), minutes, increment)
        }

        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle(R.string.tc_custom_title)
            .setView(layout)
            .setNegativeButton(android.R.string.cancel) { _, _ -> revertCustomSelection() }
            .create()
        applyBtn.setOnClickListener {
            applySelection()
            dialog.dismiss()
        }
        dialog.setOnCancelListener { revertCustomSelection() }
        dialog.show()
    }

    private fun applyLabel(minutes: Int, inc: Int): String =
        getString(R.string.tc_custom_apply, minutes, inc)

    /** Dialog dismissed without applying — restore the previous preset. */
    private fun revertCustomSelection() {
        if (tcIndex == -1) {
            tcIndex = lastPresetIndex.coerceIn(0, TimeControl.PRESETS.lastIndex)
            binding.tcChipGroup.check(presetChips[tcIndex].id)
            refreshCustomChipLabel()
        }
    }

    private fun selectedTimeControl(): TimeControl =
        if (tcIndex == -1) customTc else TimeControl.PRESETS[tcIndex]

    // ------------------------------------------------------------------
    // Engine section (Elo + color)
    // ------------------------------------------------------------------

    private fun wireEngineSection() {
        binding.whiteCard.setOnClickListener { chosenColor = WHITE; renderColorChoice() }
        binding.blackCard.setOnClickListener { chosenColor = BLACK; renderColorChoice() }
        binding.randomCard.setOnClickListener {
            chosenColor = COLOR_RANDOM
            renderColorChoice()
        }
    }

    private fun renderElo(elo: Int) {
        binding.eloValue.text = elo.toString()
        binding.eloTier.text = EloLevels.tierLabel(elo)
        binding.eloHint.text = EloLevels.hint(elo)
    }

    /** Slider values must sit on step multiples — stored prefs may not. */
    private fun roundToStep(v: Int, step: Int): Int {
        val rounded = (v / step) * step
        return rounded.coerceIn(EloLevels.MIN_ELO, EloLevels.MAX_ELO)
    }

    private fun renderColorChoice() {
        val selectedStroke = MaterialColors.getColor(
            binding.root, com.google.android.material.R.attr.colorPrimary
        )
        val selectedFill = MaterialColors.getColor(
            binding.root, com.google.android.material.R.attr.colorPrimaryContainer
        )
        val plainStroke = MaterialColors.getColor(
            binding.root, com.google.android.material.R.attr.colorOutlineVariant
        )
        val plainFill = MaterialColors.getColor(
            binding.root, com.google.android.material.R.attr.colorSurface
        )
        fun apply(card: MaterialCardView, chosen: Boolean) {
            card.strokeColor = if (chosen) selectedStroke else plainStroke
            card.strokeWidth = dp(if (chosen) 2 else 1)
            card.setCardBackgroundColor(if (chosen) selectedFill else plainFill)
        }
        apply(binding.whiteCard, chosenColor == WHITE)
        apply(binding.blackCard, chosenColor == BLACK)
        apply(binding.randomCard, chosenColor == COLOR_RANDOM)
    }

    // ------------------------------------------------------------------
    // Pass & Play section
    // ------------------------------------------------------------------

    private fun wirePvpSection() {
        // Names are read when the game starts.
    }

    // ------------------------------------------------------------------
    // Options + start
    // ------------------------------------------------------------------

    private fun wireOptions() {
        binding.autoQueenSwitch.setOnCheckedChangeListener { _, checked ->
            Prefs.setAutoQueen(requireContext(), checked)
        }
    }

    private fun wireStart() {
        binding.btnStartGame.setOnClickListener {
            val context = requireContext()
            val elo = binding.eloSlider.value.toInt()
            // Resolve the random pick only when the game actually starts,
            // so the Random card can stay visibly selected while choosing.
            val finalColor = if (chosenColor == COLOR_RANDOM) {
                if (Math.random() < 0.5) WHITE else BLACK
            } else chosenColor

            val whiteName = cleanName(binding.whiteNameField.text?.toString(), "White")
            val blackName = cleanName(binding.blackNameField.text?.toString(), "Black")

            val config = GameConfig(
                mode = mode,
                playerColor = finalColor,
                engineElo = elo,
                timeControl = selectedTimeControl(),
                whiteName = whiteName,
                blackName = blackName,
                autoFlip = binding.autoFlipSwitch.isChecked
            )
            GameConfig.saveToPrefs(context, config, tcIndex)
            startActivity(GameActivity.intent(context, config))
        }
    }

    private fun cleanName(raw: String?, fallback: String): String {
        val clean = raw?.trim()?.take(18).orEmpty()
        return clean.ifEmpty { fallback }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }
}

/** Small helper so the slider wiring reads clearly. */
private fun Slider.addSliderChangeListener(
    onSliderChange: (Slider, Float, Boolean) -> Unit,
    onSliderTouch: (Boolean) -> Unit = {}
) {
    addOnChangeListener(onSliderChange)
    addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
        override fun onStartTrackingTouch(slider: Slider) = onSliderTouch(true)
        override fun onStopTrackingTouch(slider: Slider) = onSliderTouch(false)
    })
}
