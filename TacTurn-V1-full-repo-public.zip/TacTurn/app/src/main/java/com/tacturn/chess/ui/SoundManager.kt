package com.tacturn.chess.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.tacturn.chess.R
import com.tacturn.chess.data.Prefs

/** Sound types played by the game screen. */
enum class SoundType { MOVE, CAPTURE, CHECK, WIN, LOSE, DRAW }

/**
 * Tiny SoundPool wrapper for the generated WAV effects.
 *
 * Routing note: game SFX must use [AudioAttributes.USAGE_GAME] (media
 * stream). The previous USAGE_ASSISTANCE_SONIFICATION routed to the SYSTEM
 * stream, which is muted whenever the ringer is silent / Do-Not-Disturb is
 * on — the user heard nothing even with "Move sounds" enabled. Media-stream
 * move sounds (chess.com / lichess behavior) always come through.
 */
class SoundManager(context: Context) {

    var enabled: Boolean = Prefs.soundEnabled(context)

    private val pool: SoundPool = SoundPool.Builder()
        .setMaxStreams(2)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    /** Sample ids that finished decoding — play() before this is a silent no-op. */
    private val ready = HashSet<Int>()

    /** Sample requested before its load completed — replayed on load. */
    private var pendingSample: Int? = null

    private val ids: Map<SoundType, Int> = mapOf(
        SoundType.MOVE to pool.load(context, R.raw.s_move, 1),
        SoundType.CAPTURE to pool.load(context, R.raw.s_capture, 1),
        SoundType.CHECK to pool.load(context, R.raw.s_check, 1),
        SoundType.WIN to pool.load(context, R.raw.s_win, 1),
        SoundType.LOSE to pool.load(context, R.raw.s_lose, 1),
        SoundType.DRAW to pool.load(context, R.raw.s_draw, 1)
    )

    init {
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) {
                ready += sampleId
                // A move landed while the sample was still decoding — play it now.
                if (pendingSample == sampleId) {
                    pendingSample = null
                    if (enabled) pool.play(sampleId, VOLUME, VOLUME, 1, 0, 1f)
                }
            }
        }
    }

    fun play(type: SoundType) {
        if (!enabled) return
        ids[type]?.let { id ->
            if (id in ready) pool.play(id, VOLUME, VOLUME, 1, 0, 1f)
            else pendingSample = id
        }
    }

    fun release() {
        pool.release()
    }

    private companion object {
        const val VOLUME = 1f
    }
}
