package com.tacturn.chess.analysis

import com.tacturn.chess.engine.BLACK
import com.tacturn.chess.engine.Searcher
import com.tacturn.chess.engine.WHITE
import com.tacturn.chess.engine.isCastleK
import com.tacturn.chess.engine.isCastleQ
import com.tacturn.chess.pgn.Ply
import kotlin.math.abs

/*
 * TacTurn v1 — the display mapper.
 *
 * Converts a raw [GameReview] (canonical, Elo-independent) into rich UI
 * models under an [EloProfile]. Everything here is pure Kotlin on cached
 * data: switching Elo re-runs the presenter in well under a millisecond
 * for a 100-ply game — the "instant re-filter" requirement.
 */

/** Formatted score string per profile (rounded pawns for Beginner/Club). */
object ScoreFormat {
    fun format(score: Int, profile: EloProfile, moverPov: Boolean = true): String {
        val s = if (moverPov) score else -score
        return when {
            s >= Searcher.MATE_BOUND -> "M${(Searcher.MATE - s + 1) / 2}"
            s <= -Searcher.MATE_BOUND -> "-M${(Searcher.MATE + s + 1) / 2}"
            profile.roundWholePawns -> {
                // Whole pawns, truncated toward zero: 0.49 -> "+0",
                // 150 -> "+1" (the fractional part is dropped, so "equal"
                // only shows at exactly 0).
                val pawns = s / 100
                if (pawns > 0) "+$pawns" else if (pawns < 0) "$pawns" else "0"
            }
            else -> {
                val pawns = s / 100.0
                if (abs(pawns) < 0.005) "0.00"
                else if (pawns > 0) "+${"%.2f".format(java.util.Locale.US, pawns)}"
                else "${"%.2f".format(java.util.Locale.US, pawns)}"
            }
        }
    }

    /** White-POV score for the eval graph/badges. */
    fun whitePov(score: Int, sideToMove: Int): Int =
        if (sideToMove == WHITE) score else -score
}

/** One move in the move list, presentation-ready. */
data class MoveChip(
    val plyIndex: Int,
    val number: Int,            // fullmove number
    val san: String,
    val isWhite: Boolean,
    val moveClass: MoveClass,
    val playedBest: Boolean,
    val practicality: Practicality?
)

/** Detailed card for the selected ply. */
data class PlyDetail(
    val plyIndex: Int,
    val number: Int,
    val san: String,
    val isWhite: Boolean,
    /** Score BEFORE the move (mover POV), formatted per profile. */
    val scoreBefore: String,
    /** Score AFTER the move (still mover POV), formatted per profile. */
    val scoreAfter: String,
    /** Raw cp loss, formatted ("−0.8" club / "−84" advanced). */
    val lossText: String,
    val moveClass: MoveClass,
    val bestMoveSan: String?,
    val verbal: String?,
    val practicality: Practicality?,
    /** True when the engine's suggestion here is a sharp sacrifice. */
    val suggestionIsSharp: Boolean
)

/** One engine line shown in the lines card. */
data class LineModel(
    val rank: Int,
    val scoreText: String,
    val depth: Int,
    val pvSan: List<String>,
    val isSharp: Boolean
)

/** Full presentation of a reviewed game under one Elo profile. */
data class ReviewPresentation(
    val profile: EloProfile,
    val moveChips: List<MoveChip>,
    val whiteAccuracyPct: Int,
    val blackAccuracyPct: Int,
    val whitePerformanceElo: Int,
    val blackPerformanceElo: Int,
    /** "You played at a 1420 level in this game!" (the analyzed side). */
    val heroPerformanceElo: Int,
    val heroSide: Int,                     // WHITE or BLACK
    val bestMoveSan: String?,
    val bestMoveNumber: Int,
    val verbal: String?
)

object AnalysisPresenter {

    /** Builds the whole-game presentation (move list + summary). */
    fun present(review: GameReview, profile: EloProfile, heroSide: Int): ReviewPresentation {
        val chips = ArrayList<MoveChip>(review.plyCount)
        for (i in review.plies.indices) {
            val ply = review.plies[i]
            val facts = review.plyFacts[i]
            val isWhite = (i % 2 == 0) xor (startedFromBlack(review))
            chips.add(
                MoveChip(
                    plyIndex = i,
                    number = plyNumber(i),
                    san = ply.san,
                    isWhite = isWhite,
                    moveClass = if (facts.isBook) MoveClass.BOOK
                    else MoveClass.fromWinDrop(facts.winDrop, facts.playedBest, profile.elo),
                    playedBest = facts.playedBest,
                    practicality = if (profile.practicalityIndicator) {
                        Practicality.of(facts.winDrop, facts.materialSwing)
                    } else null
                )
            )
        }

        val bestPly = review.plies.getOrNull(review.bestPlyIndex)
        val heroPerf = if (heroSide == WHITE) review.whitePerformanceElo else review.blackPerformanceElo
        val verbal = summaryVerbal(review, profile, heroSide)

        return ReviewPresentation(
            profile = profile,
            moveChips = chips,
            whiteAccuracyPct = (review.whiteAccuracy + 0.5).toInt(),
            blackAccuracyPct = (review.blackAccuracy + 0.5).toInt(),
            whitePerformanceElo = review.whitePerformanceElo,
            blackPerformanceElo = review.blackPerformanceElo,
            heroPerformanceElo = heroPerf,
            heroSide = heroSide,
            bestMoveSan = bestPly?.san,
            bestMoveNumber = plyNumber(review.bestPlyIndex),
            verbal = verbal
        )
    }

    /** Builds the detail card for one ply. */
    fun detail(review: GameReview, profile: EloProfile, plyIndex: Int): PlyDetail? {
        if (plyIndex < 0 || plyIndex >= review.plyCount) return null
        val ply = review.plies[plyIndex]
        val facts = review.plyFacts[plyIndex]
        val before = review.positions[plyIndex]
        val after = review.positions[plyIndex + 1]
        val mover = moverAt(review, plyIndex)

        val beforeCp = Accuracy.toCp(before.score)
        val afterCp = -Accuracy.toCp(after.score)   // after is opponent POV
        val cls = if (facts.isBook) MoveClass.BOOK
        else MoveClass.fromWinDrop(facts.winDrop, facts.playedBest, profile.elo)

        val verbal = if (profile.verbalFeedback) verbalFor(cls, facts.playedBest, profile) else null
        val practicality = if (profile.practicalityIndicator) {
            Practicality.of(facts.winDrop, facts.materialSwing)
        } else null

        return PlyDetail(
            plyIndex = plyIndex,
            number = plyNumber(plyIndex),
            san = ply.san,
            isWhite = (plyIndex % 2 == 0) xor (startedFromBlack(review)),
            scoreBefore = ScoreFormat.format(beforeCp, profile),
            scoreAfter = ScoreFormat.format(afterCp, profile),
            lossText = formatLoss(facts.loss, profile),
            moveClass = cls,
            bestMoveSan = null,   // resolved by the ViewModel (needs the session)
            verbal = verbal,
            practicality = practicality,
            suggestionIsSharp = facts.materialSwing >= 300
        )
    }

    /**
     * Chooses which analysis LINES to show for a position under a profile.
     * Beginner/Club: the first NON-sharp line (obvious, practical play);
     * Advanced: up to 3 lines, sharp ones tagged; Master: all, unfiltered.
     */
    fun filterLines(lines: List<LineModel>, profile: EloProfile): List<LineModel> {
        if (profile.rawMode) return lines
        val capped = lines.take(profile.maxLines)
        if (!profile.hideSharpLines) return capped
        // Beginner: hide sacrificial suggestions; prefer the next solid line.
        val solid = capped.filter { !it.isSharp }
        return solid.take(1).ifEmpty { capped.take(1) }
    }

    // ---- helpers ---------------------------------------------------------

    private fun plyNumber(plyIndex: Int): Int = plyIndex / 2 + 1

    /** True when the game started with Black to move (FEN import). */
    private fun startedFromBlack(review: GameReview): Boolean {
        // The side to move at ply 0 is encoded in the start FEN; derive it
        // from the first position's best-move ownership instead of re-parsing.
        // Simpler: the replayer stored fenBefore for ply 0 — parse side.
        val fen = review.plies.firstOrNull()?.fenBefore ?: return false
        val parts = fen.split(" ")
        return parts.getOrNull(1) == "b"
    }

    private fun moverAt(review: GameReview, plyIndex: Int): Int =
        if (startedFromBlack(review)) (plyIndex + 1) % 2 else plyIndex % 2

    private fun formatLoss(loss: Int, profile: EloProfile): String {
        if (loss <= 10) return ""
        return if (profile.roundWholePawns) {
            val pawns = (loss + 50) / 100   // round to the nearest pawn
            "\u2212$pawns"
        } else {
            "\u2212$loss"
        }
    }

    private fun verbalFor(cls: MoveClass, playedBest: Boolean, profile: EloProfile): String = when {
        cls == MoveClass.BOOK -> "Known opening theory — the established line here."
        playedBest -> "Engine's top choice — great find for a ${profile.elo} player!"
        cls == MoveClass.BEST -> "Solid move for your level."
        cls == MoveClass.EXCELLENT -> "Solid move for your level."
        cls == MoveClass.GOOD -> "Reasonable — the engine slightly prefers another move."
        cls == MoveClass.INACCURACY -> "Playable, but this loosens your position a little."
        cls == MoveClass.MISTAKE -> "Careful — this gives up real material or position."
        else -> "This is the losing moment — check the engine line to see why."
    }

    private fun summaryVerbal(review: GameReview, profile: EloProfile, heroSide: Int): String? {
        if (!profile.verbalFeedback) return null
        val acc = if (heroSide == WHITE) review.whiteAccuracy else review.blackAccuracy
        val perf = if (heroSide == WHITE) review.whitePerformanceElo else review.blackPerformanceElo
        val diff = perf - profile.elo
        return when {
            diff >= 200 -> "Outstanding — you played well above your rating!"
            diff >= 50 -> "Strong game — comfortably above your level."
            diff >= -50 -> "Right at your level — steady play."
            diff >= -250 -> "A rough game — review the flagged moves below."
            else -> "Tough session — the flagged moves are worth replaying."
        } + " (accuracy ${acc.toInt()}%)"
    }
}
