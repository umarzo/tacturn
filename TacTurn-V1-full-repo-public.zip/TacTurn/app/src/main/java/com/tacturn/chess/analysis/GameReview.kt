package com.tacturn.chess.analysis

import com.tacturn.chess.engine.PIECE_VALUES
import com.tacturn.chess.engine.isCapture
import com.tacturn.chess.engine.moveCaptured
import com.tacturn.chess.pgn.Ply

/*
 * TacTurn v2 — the raw game review (engine output, Elo-independent).
 *
 * One [GameReview] is computed ONCE per imported game and cached (memory +
 * JSON on disk). It stores, for every position of the game:
 *   - the engine score from the side-to-move's POV (centipawns/mate)
 *   - the engine's best move at that position
 *   - the search depth reached
 * Switching the user's Elo NEVER recomputes any of this — the presenter
 * only re-filters the display.
 *
 * v2 overhaul: [PlyFacts] now carries the WIN% drop (the classification
 * signal — see [Accuracy]) and the book flag, so every consumer judges
 * moves identically. The batch pipeline also runs a deep VERIFICATION
 * pass over suspect moments before the review is finalized (see
 * AnalysisViewModel): the first-pass evals are re-searched deeper so
 * eval noise cannot fabricate blunders that decide the reported rating.
 */

/** Raw per-position engine data. Position i is BEFORE ply i. */
data class PositionEval(
    val score: Int,        // mover POV (cp or mate score, engine encoding)
    val bestMove: Int,     // engine's best move (0 = none: mate/stalemate)
    val depth: Int
)

/** Per-ply derived raw facts (still Elo-independent). */
data class PlyFacts(
    val loss: Int,                 // cp loss from the mover's POV (>= 0) — display
    val winDrop: Double,           // win% lost by the move — THE classification signal
    val playedBest: Boolean,       // move == engine best at that position
    val isBook: Boolean,           // known-theory continuation — excluded from aggregates
    val materialSwing: Int         // material (cp) the mover gives up along
                                   // the engine's best line from here
)

data class GameReview(
    val startFen: String,
    val plies: List<Ply>,
    val headers: Map<String, String>,
    val result: String?,
    /** positions.size == plies.size + 1 (evals before every ply + final). */
    val positions: List<PositionEval>,
    val plyFacts: List<PlyFacts>,
    val whiteAccuracy: Double,
    val blackAccuracy: Double,
    val whitePerformanceElo: Int,
    val blackPerformanceElo: Int,
    /** Ply index of the player's best move (lowest loss among best-moves). */
    val bestPlyIndex: Int,
    val source: Source
) {
    val plyCount: Int get() = plies.size

    enum class Source { PGN_TEXT, PGN_FILE, FEN, PLAYED_GAME, HISTORY }
}

/** Analysis of "sharpness" along a PV — used to tag/hide lines per Elo. */
object Sharpness {

    /**
     * Walks a PV (engine move ints) and reports how much material the ROOT
     * MOVER gives up along it (maximum deficit, in cp, >= 0).
     *
     * A line that sacrifices 3+ pawns of material within the first 12 plies
     * is exactly the "hyper-complex positional sacrifice" the beginner
     * filter must catch: the compensation lives 10+ moves deep, far beyond
     * what a club player can verify over the board.
     */
    fun materialGivenUp(pv: List<Int>): Int {
        if (pv.isEmpty()) return 0
        var balance = 0          // root mover's material balance (cp)
        var worst = 0            // most negative balance seen (>= 0 result)
        for ((i, move) in pv.withIndex()) {
            if (i >= 12) break   // only the verifiable prefix matters
            if (isCapture(move)) {
                val victimValue = PIECE_VALUES[moveCaptured(move)]
                // Even ply = root mover's move (PV always starts with the
                // side to move at the root).
                balance += if (i % 2 == 0) victimValue else -victimValue
                if (balance < worst) worst = balance
            }
        }
        return -worst
    }

    /** True when a line should be tagged "Sharp / Requires precise
     *  calculation" for the Advanced tier. */
    fun isSharpLine(pv: List<Int>): Boolean = materialGivenUp(pv) >= 300
}
