package com.tacturn.chess.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/*
 * TacTurn v1 — game history persistence.
 *
 * One JSON file per entry under filesDir/history/. Three kinds:
 *   - "played":   a Play-vs-Engine game (moves + result + engine Elo)
 *   - "played" (pvp): a Pass & Play game (two local players, optional clock)
 *   - "analyzed": an imported game WITH its raw review cache (scores /
 *                 best moves per position) so reopening it never re-runs
 *                 the engine — the instant-restore path.
 *
 * org.json (platform) keeps the APK dependency-free.
 */

data class HistoryEntry(
    val id: String,
    val kind: String,             // "played" | "analyzed"
    val date: Long,
    val white: String,
    val black: String,
    val result: String?,          // "1-0" | "0-1" | "1/2-1/2" | "*"
    val startFen: String?,        // null = standard start
    val sanMoves: List<String>,
    val engineElo: Int?,          // played games: the opponent's level
    val playerColor: Int?,        // played games (engine mode)
    val userElo: Int?,            // analyzed games: Elo the review was run at
    val accuracy: Double?,        // analyzed: hero accuracy
    val performanceElo: Int?,     // analyzed: hero performance Elo
    /** analyzed: raw per-position scores (mover POV). */
    val reviewScores: List<Int>?,
    /** analyzed: raw per-position best moves (0 = none). */
    val reviewBestMoves: List<Int>?,
    /** analyzed: per-position search depth. */
    val reviewDepths: List<Int>?,
    /** analyzed: source of the import. */
    val importSource: String?,
    /** v2: "engine" | "pvp" (null = legacy engine games). */
    val mode: String? = null,
    /** v2: time-control label like "3+2" (null = unlimited/legacy). */
    val timeControl: String? = null
) {
    val moveCount: Int get() = sanMoves.size

    companion object {
        const val MODE_ENGINE = "engine"
        const val MODE_PVP = "pvp"
    }
}

class HistoryRepository(context: Context) {

    private val dir: File = File(context.applicationContext.filesDir, "history").apply {
        mkdirs()
    }

    fun save(entry: HistoryEntry) {
        try {
            val f = File(dir, entry.id + ".json")
            f.writeText(entry.toJson().toString())
        } catch (t: Throwable) {
            // Persistence is best-effort: never let it break the UX.
        }
    }

    fun delete(id: String) {
        try { File(dir, "$id.json").delete() } catch (_: Throwable) {}
    }

    fun all(): List<HistoryEntry> =
        try {
            dir.listFiles { f -> f.extension == "json" }
                ?.mapNotNull { file ->
                    try {
                        fromJson(JSONObject(file.readText()))
                    } catch (t: Throwable) {
                        null   // corrupt file: skip silently
                    }
                }
                ?.sortedByDescending { it.date }
                ?: emptyList()
        } catch (t: Throwable) {
            emptyList()
        }

    fun get(id: String): HistoryEntry? = try {
        val f = File(dir, "$id.json")
        if (f.exists()) fromJson(JSONObject(f.readText())) else null
    } catch (t: Throwable) {
        null
    }

    // ---- JSON -----------------------------------------------------------

    private fun HistoryEntry.toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("kind", kind)
        put("date", date)
        put("white", white)
        put("black", black)
        put("result", result ?: JSONObject.NULL)
        put("startFen", startFen ?: JSONObject.NULL)
        put("moves", JSONArray(sanMoves))
        if (engineElo != null) put("engineElo", engineElo)
        if (playerColor != null) put("playerColor", playerColor)
        if (userElo != null) put("userElo", userElo)
        if (accuracy != null) put("accuracy", accuracy)
        if (performanceElo != null) put("performanceElo", performanceElo)
        reviewScores?.let { put("scores", JSONArray(it)) }
        reviewBestMoves?.let { put("bestMoves", JSONArray(it)) }
        reviewDepths?.let { put("depths", JSONArray(it)) }
        put("importSource", importSource ?: JSONObject.NULL)
        if (mode != null) put("mode", mode)
        if (timeControl != null) put("timeControl", timeControl)
    }

    private fun fromJson(o: JSONObject): HistoryEntry {
        fun JSONArray.toIntList(): List<Int> = (0 until length()).map { optInt(it) }
        fun JSONArray.toStringList(): List<String> = (0 until length()).map { optString(it) }
        return HistoryEntry(
            id = o.optString("id"),
            kind = o.optString("kind", "analyzed"),
            date = o.optLong("date"),
            white = o.optString("white", "White"),
            black = o.optString("black", "Black"),
            result = if (o.isNull("result")) null else o.optString("result"),
            startFen = if (o.isNull("startFen")) null else o.optString("startFen"),
            sanMoves = o.optJSONArray("moves")?.toStringList() ?: emptyList(),
            engineElo = if (o.has("engineElo") && !o.isNull("engineElo")) o.optInt("engineElo") else null,
            playerColor = if (o.has("playerColor") && !o.isNull("playerColor")) o.optInt("playerColor") else null,
            userElo = if (o.has("userElo") && !o.isNull("userElo")) o.optInt("userElo") else null,
            accuracy = if (o.has("accuracy") && !o.isNull("accuracy")) o.optDouble("accuracy") else null,
            performanceElo = if (o.has("performanceElo") && !o.isNull("performanceElo")) o.optInt("performanceElo") else null,
            reviewScores = o.optJSONArray("scores")?.toIntList(),
            reviewBestMoves = o.optJSONArray("bestMoves")?.toIntList(),
            reviewDepths = o.optJSONArray("depths")?.toIntList(),
            importSource = if (o.isNull("importSource")) null else o.optString("importSource"),
            mode = if (o.has("mode") && !o.isNull("mode")) o.optString("mode") else null,
            timeControl = if (o.has("timeControl") && !o.isNull("timeControl")) o.optString("timeControl") else null
        )
    }
}
