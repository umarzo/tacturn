package com.tacturn.chess.ui.analysis

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.chip.Chip
import com.tacturn.chess.R
import com.tacturn.chess.analysis.MoveClass
import com.tacturn.chess.analysis.Practicality
import com.tacturn.chess.data.Prefs
import com.tacturn.chess.databinding.ActivityAnalysisBinding
import com.tacturn.chess.databinding.ItemAnalysisLineBinding
import com.tacturn.chess.engine.GameResult
import com.tacturn.chess.engine.WHITE
import com.tacturn.chess.ui.BoardTarget
import kotlinx.coroutines.launch

/**
 * The Analysis session screen — the flagship UX:
 *
 *   board (60% height) + best-move arrow
 *   move list with per-move class badges (tap to browse)
 *   summary card: "You played at a 1420 level!" + best move highlight
 *   detail card for the selected move (verbal coaching at club level)
 *   engine lines card (Multi-PV, sharp tags, live depth)
 *   always-visible accuracy note (approximate analysis disclaimer)
 *
 * All engine work lives in [AnalysisViewModel]; this class only renders
 * immutable [AnalysisUiState] snapshots. Lifecycle-safe: ON_STOP halts
 * the engine, ON_START resumes.
 */
class AnalysisActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAnalysisBinding
    private val viewModel: AnalysisViewModel by viewModels()

    private var eloSheet: EloSheet? = null
    private var renderedChipCount = -1
    private var renderedSelectedPly = -1
    private var lastPayload: String? = null
    private var importFailedHandled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAnalysisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.boardView.onMoveAttempt = null   // analysis board is read-only

        binding.btnBack.setOnClickListener { finish() }
        binding.eloChip.setOnClickListener { showEloSheet(reselect = true) }
        binding.heroToggle.setOnClickListener {
            val next = if (viewModel.ui.value.heroSide == WHITE) 1 else 0
            viewModel.changeHeroSide(next)
        }
        binding.btnFirst.setOnClickListener { viewModel.goToStart() }
        binding.btnPrev.setOnClickListener { viewModel.stepPly(-1) }
        binding.btnNext.setOnClickListener { viewModel.stepPly(1) }
        binding.btnLast.setOnClickListener { viewModel.goToEnd() }
        binding.btnFlip.setOnClickListener { viewModel.flipBoard() }

        // Deliver the import only when there is actually something to load —
        // a rotation recreate must keep the session (and its analysis
        // results) alive, but after an OS process death the Activity comes
        // back with a savedInstanceState Bundle AND a fresh ViewModel, so
        // the phase check (not just the Bundle check) is what makes the
        // screen recover instead of showing an empty review forever.
        val payload = intent.getStringExtra(EXTRA_PAYLOAD)
        val source = intent.getStringExtra(EXTRA_SOURCE) ?: SOURCE_PGN_TEXT
        if (payload != null && payload != lastPayload &&
            (savedInstanceState == null || viewModel.ui.value.phase is AnalysisPhase.Idle)
        ) {
            lastPayload = payload
            when (source) {
                SOURCE_PGN_FILE -> viewModel.loadFromPgnFile(Uri.parse(payload))
                SOURCE_FEN -> viewModel.loadFromFen(payload)
                SOURCE_HISTORY -> viewModel.loadFromHistory(
                    Uri.parse(payload).lastPathSegment ?: ""
                )
                SOURCE_SAMPLE -> viewModel.loadFromPgnText(SAMPLE_GAME)
                else -> viewModel.loadFromPgnText(payload)
            }
        }

        // Lifecycle wiring: halt the engine when the UI is hidden,
        // resume the (resumable) batch when it comes back.
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.ui.collect { render(it) }
            }
        }
        lifecycle.addObserver(object : androidx.lifecycle.DefaultLifecycleObserver {
            override fun onStop(owner: androidx.lifecycle.LifecycleOwner) {
                viewModel.haltEngine()
            }

            override fun onStart(owner: androidx.lifecycle.LifecycleOwner) {
                viewModel.resumeEngine()
            }
        })

        // Interstitial import errors -> friendly toast + exit.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { finish() }
        })
    }

    // ------------------------------------------------------------------
    // Rendering
    // ------------------------------------------------------------------

    private fun render(state: AnalysisUiState) {
        renderHeader(state)
        renderPhase(state)
        renderBoard(state)
        renderSummary(state)
        renderMoveChips(state)
        renderDetail(state)
        renderLines(state)

        // One-shot transient messages (partial imports etc). ImportFailed
        // errors are handled inside renderPhase (toast + exit) — skip here.
        state.errorMessage
            ?.takeIf { it.isNotBlank() && state.phase != AnalysisPhase.ImportFailed }
            ?.let {
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
                viewModel.clearError()
            }
    }

    private fun renderHeader(state: AnalysisUiState) {
        binding.gameTitle.text = state.gameTitle.ifBlank { getString(R.string.analysis_title) }
        binding.gameMeta.text = buildMeta(state)
        binding.eloChip.text = if (state.profile != null) {
            "${state.userElo}"
        } else getString(R.string.elo_chip_empty)
        binding.heroToggle.text = if (state.heroSide == WHITE) {
            getString(R.string.analyzed_side, state.whiteName)
        } else {
            getString(R.string.analyzed_side, state.blackName)
        }
    }

    private fun buildMeta(state: AnalysisUiState): String {
        val parts = ArrayList<String>()
        state.result?.let { parts.add(it) }
        if (state.plyCount > 0) parts.add(resources.getQuantityString(R.plurals.moves, state.plyCount, state.plyCount))
        if (state.profile != null) parts.add(state.profile.tier.label)
        return parts.joinToString("  ·  ")
    }

    private fun renderPhase(state: AnalysisUiState) {
        when (state.phase) {
            AnalysisPhase.Idle, AnalysisPhase.Importing ->
                binding.progressCard.visibility = View.GONE
            AnalysisPhase.NeedsElo -> {
                binding.progressCard.visibility = View.GONE
                if (eloSheet == null) showEloSheet(reselect = false, elo = state.userElo)
            }
            AnalysisPhase.ImportFailed -> {
                binding.progressCard.visibility = View.GONE
                if (!importFailedHandled) {
                    importFailedHandled = true
                    val reason = state.errorMessage ?: getString(R.string.import_invalid)
                    Toast.makeText(this, reason, Toast.LENGTH_LONG).show()
                    viewModel.clearError()
                    finish()
                }
            }
            AnalysisPhase.BatchRunning -> {
                binding.progressCard.visibility = View.VISIBLE
                val total = state.progressTotal.coerceAtLeast(1)
                binding.progressBar.max = total
                binding.progressBar.progress = state.progressDone
                binding.progressText.text =
                    getString(R.string.analysis_progress, state.progressDone, total)
            }
            AnalysisPhase.Ready -> binding.progressCard.visibility = View.GONE
        }
    }

    private fun renderBoard(state: AnalysisUiState) {
        binding.boardView.setPosition(
            squares = state.board.toIntArray(),
            targets = emptyList(),
            lastFrom = state.lastFrom,
            lastTo = state.lastTo,
            checkSquare = -1,
            orientation = state.orientation,
            playerColor = state.orientation,
            inputEnabled = false,
            themeIndex = Prefs.boardTheme(this)
        )
        binding.boardView.setBestMoveArrow(
            if (state.bestFrom >= 0) state.bestFrom to state.bestTo else null
        )
    }

    @SuppressLint("SetTextI18n")
    private fun renderSummary(state: AnalysisUiState) {
        val p = state.presentation
        if (p == null) {
            binding.summaryCard.visibility = View.GONE
            return
        }
        binding.summaryCard.visibility = View.VISIBLE
        if (state.plyCount == 0) {
            // FEN import: no moves, just show the evaluation.
            binding.perfHeadline.text = getString(R.string.position_evaluated)
            binding.perfDetail.text = getString(R.string.analyze_position_hint)
            binding.bestMoveChip.visibility = View.GONE
            return
        }
        val hero = if (p.heroSide == WHITE) state.whiteName else state.blackName
        binding.perfHeadline.text = getString(R.string.played_at_level, hero, p.heroPerformanceElo)
        val acc = if (p.heroSide == WHITE) p.whiteAccuracyPct else p.blackAccuracyPct
        binding.perfDetail.text = getString(R.string.accuracy_line, acc)
        if (p.bestMoveSan != null) {
            binding.bestMoveChip.visibility = View.VISIBLE
            binding.bestMoveChip.text =
                getString(R.string.best_move_chip, "${p.bestMoveNumber}. ${p.bestMoveSan}")
        } else {
            binding.bestMoveChip.visibility = View.GONE
        }
        p.verbal?.let { binding.perfVerbal.text = it; binding.perfVerbal.visibility = View.VISIBLE }
            ?: run { binding.perfVerbal.visibility = View.GONE }
    }

    private fun renderMoveChips(state: AnalysisUiState) {
        val container = binding.moveChips
        // Rebuild on count OR selection change: the selected-pill highlight
        // is painted per chip at inflation time, so navigating with
        // First/Prev/Next/Last (or tapping a chip) must re-render even when
        // the move list itself is unchanged.
        if (state.moveChips.size == renderedChipCount &&
            state.selectedPly == renderedSelectedPly &&
            container.childCount > 0
        ) return
        renderedChipCount = state.moveChips.size
        renderedSelectedPly = state.selectedPly
        container.removeAllViews()
        val inflater = LayoutInflater.from(this)
        var moveNumberShown = -1
        for (chipModel in state.moveChips) {
            if (chipModel.isWhite && chipModel.number != moveNumberShown) {
                moveNumberShown = chipModel.number
                addNumber(inflater, container, "${chipModel.number}.")
            }
            addMoveChip(inflater, container, state, chipModel)
        }
        container.post {
            (binding.moveHistoryScroll).fullScroll(View.FOCUS_RIGHT)
        }
    }

    private fun addNumber(inflater: LayoutInflater, container: LinearLayout, text: String) {
        val tv = inflater.inflate(R.layout.item_move_chip, container, false) as TextView
        tv.text = text
        tv.setTextColor(resColor(R.color.text_hint))
        container.addView(tv)
    }

    private fun addMoveChip(
        inflater: LayoutInflater,
        container: LinearLayout,
        state: AnalysisUiState,
        model: com.tacturn.chess.analysis.MoveChip
    ) {
        val tv = inflater.inflate(R.layout.item_move_chip, container, false) as TextView
        tv.text = model.san
        val (fg, dot) = colorsForClass(model.moveClass)
        tv.setTextColor(fg)
        tv.background = chipBackground(model, state, dot)
        tv.setOnClickListener { viewModel.selectPly(model.plyIndex + 1) }
        container.addView(tv)
    }
    private fun chipBackground(
        model: com.tacturn.chess.analysis.MoveChip,
        state: AnalysisUiState,
        dotColor: Int
    ): android.graphics.drawable.GradientDrawable {
        val selected = state.selectedPly == model.plyIndex + 1
        return android.graphics.drawable.GradientDrawable().apply {
            // Full pill (half the fixed 26dp chip height) so programmatic chips
            // match the XML chip_move pill on every density — this was px before.
            cornerRadius = resources.getDimensionPixelSize(R.dimen.chip_corner).toFloat()
            when {
                selected -> setColor(attrColor(com.google.android.material.R.attr.colorSecondaryContainer))
                model.moveClass == MoveClass.BLUNDER -> setColor(withAlpha(dotColor, 0x30))
                model.moveClass == MoveClass.MISTAKE -> setColor(withAlpha(dotColor, 0x24))
                model.moveClass == MoveClass.INACCURACY -> setColor(withAlpha(dotColor, 0x1C))
                model.playedBest -> setColor(withAlpha(resColor(R.color.class_excellent), 0x1C))
                else -> setColor(attrColor(com.google.android.material.R.attr.colorSurfaceVariant))
            }
            if (selected) setStroke(dp(2), attrColor(com.google.android.material.R.attr.colorSecondary))
        }
    }

    /** Move-class text + chip-tint colors — resource-driven so night mode
     *  gets the lighter class palette instead of light-mode-only literals. */
    private fun colorsForClass(cls: MoveClass): Pair<Int, Int> = when (cls) {
        MoveClass.BOOK -> resColor(R.color.class_book) to resColor(R.color.class_book)
        MoveClass.BEST -> resColor(R.color.class_best) to resColor(R.color.class_best)
        MoveClass.EXCELLENT -> resColor(R.color.class_excellent) to resColor(R.color.class_excellent)
        MoveClass.GOOD -> resColor(R.color.class_good) to resColor(R.color.class_good)
        MoveClass.INACCURACY -> resColor(R.color.class_inaccuracy) to resColor(R.color.class_inaccuracy)
        MoveClass.MISTAKE -> resColor(R.color.class_mistake) to resColor(R.color.class_mistake)
        MoveClass.BLUNDER -> resColor(R.color.class_blunder) to resColor(R.color.class_blunder)
    }

    private fun renderDetail(state: AnalysisUiState) {
        val d = state.detail
        if (d == null) {
            binding.detailCard.visibility = if (state.phase == AnalysisPhase.Ready &&
                state.selectedPly == 0) View.VISIBLE else View.GONE
            if (state.phase == AnalysisPhase.Ready && state.selectedPly == 0) {
                binding.detailTitle.text = getString(R.string.start_position)
                binding.detailBody.text = getString(R.string.tap_a_move_hint)
            }
            return
        }
        binding.detailCard.visibility = View.VISIBLE
        val side = if (d.isWhite) state.whiteName else state.blackName
        binding.detailTitle.text = getString(R.string.move_detail_title, d.number, d.san, side)

        val lines = ArrayList<String>()
        val clsLabel = when (d.moveClass) {
            MoveClass.BOOK -> getString(R.string.class_book)
            MoveClass.BEST -> getString(R.string.class_best)
            MoveClass.EXCELLENT -> getString(R.string.class_excellent)
            MoveClass.GOOD -> getString(R.string.class_good)
            MoveClass.INACCURACY -> getString(R.string.class_inaccuracy)
            MoveClass.MISTAKE -> getString(R.string.class_mistake)
            MoveClass.BLUNDER -> getString(R.string.class_blunder)
        }
        lines.add(clsLabel)
        if (d.lossText.isNotEmpty()) lines.add("eval ${d.scoreBefore} → ${d.scoreAfter} (${d.lossText})")
        else lines.add("eval ${d.scoreBefore} → ${d.scoreAfter}")
        d.bestMoveSan?.let { lines.add(getString(R.string.engine_preferred, it)) }
        d.practicality?.let {
            lines.add(getString(R.string.practicality_label, practicalityText(it)))
        }
        if (d.suggestionIsSharp) lines.add(getString(R.string.sharp_tag))
        binding.detailBody.text = lines.joinToString("\n")
        d.verbal?.let {
            binding.detailVerbal.text = it
            binding.detailVerbal.visibility = View.VISIBLE
        } ?: run { binding.detailVerbal.visibility = View.GONE }
    }

    private fun practicalityText(p: Practicality): String = when (p) {
        Practicality.SOLID -> getString(R.string.practicality_solid)
        Practicality.RISKY -> getString(R.string.practicality_risky)
        Practicality.SHARP -> getString(R.string.practicality_sharp)
    }

    private fun renderLines(state: AnalysisUiState) {
        val container = binding.linesList
        container.removeAllViews()
        if (state.lines.isEmpty() && !state.linesAnalyzing) {
            binding.linesCard.visibility =
                if (state.phase == AnalysisPhase.Ready) View.VISIBLE else View.GONE
            if (state.phase == AnalysisPhase.Ready) {
                binding.linesDepthLabel.text = ""
                addLinesPlaceholder()
            }
            return
        }
        binding.linesCard.visibility = View.VISIBLE
        binding.linesDepthLabel.text = when {
            state.linesAnalyzing -> state.linesInfo.ifBlank { getString(R.string.analyzing) }
            else -> ""
        }
        val inflater = LayoutInflater.from(this)
        for (line in state.lines) {
            val b = ItemAnalysisLineBinding.inflate(inflater, container, false)
            b.lineRank.text = line.rank.toString()
            b.lineScore.text = line.scoreText
            b.linePv.text = line.pvSan.joinToString("  ")
            b.lineDepth.text = getString(R.string.depth_label, line.depth)
            if (line.isSharp) {
                b.sharpTag.visibility = View.VISIBLE
            } else {
                b.sharpTag.visibility = View.GONE
            }
            container.addView(b.root)
        }
    }

    private fun addLinesPlaceholder() {
        val tv = TextView(this).apply {
            text = getString(R.string.tap_a_move_hint)
            setTextColor(attrColor(com.google.android.material.R.attr.colorOnSurfaceVariant))
            textSize = 13f
            setPadding(0, dp(4), 0, dp(4))
        }
        binding.linesList.addView(tv)
    }

    // ------------------------------------------------------------------
    // Elo sheet
    // ------------------------------------------------------------------

    private fun showEloSheet(reselect: Boolean, elo: Int? = null) {
        val current = elo ?: viewModel.ui.value.userElo
        eloSheet?.dismiss()
        eloSheet = EloSheet(this, current, allow2700 = true) { picked ->
            when (viewModel.ui.value.phase) {
                // NeedsElo: the first personalization — starts the review.
                AnalysisPhase.NeedsElo -> viewModel.confirmElo(picked)
                // Otherwise: instant re-filter, never a re-analysis.
                else -> viewModel.changeElo(picked)
            }
        }.also { it.show() }
    }

    // ------------------------------------------------------------------
    // helpers

    fun attrColor(attrRes: Int): Int =
        com.google.android.material.color.MaterialColors.getColor(binding.root, attrRes)

    private fun resColor(res: Int): Int =
        androidx.core.content.ContextCompat.getColor(this, res)

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        eloSheet?.dismiss()
        eloSheet = null
        super.onDestroy()
    }

    companion object {
        const val SOURCE_PGN_TEXT = "pgn_text"
        const val SOURCE_PGN_FILE = "pgn_file"
        const val SOURCE_FEN = "fen"
        const val SOURCE_HISTORY = "history"
        const val SOURCE_SAMPLE = "sample"

        /**
         * Bundled miniature so first-time users can try the flow without
         * any import (a short, real attacking game).
         */
        const val SAMPLE_GAME = """
[Event "Opera Game"]
[Site "Paris FRA"]
[Date "1858.11.02"]
[White "Morphy"]
[Black "Duke of Brunswick & Count Isouard"]
[Result "1-0"]

1.e4 e5 2.Nf3 d6 3.d4 Bg4 4.dxe5 Bxf3 5.Qxf3 dxe5 6.Bc4 Nf6 7.Qb3 Qe7
8.Nc3 c6 9.Bg5 b5 10.Nxb5 cxb5 11.Bxb5+ Nbd7 12.O-O-O Rd8 13.Rxd7 Rxd7
14.Rd1 Qe6 15.Bxd7+ Nxd7 16.Qb8+ Nxb8 17.Rd8# 1-0
"""

        fun intent(context: Context, payload: String, source: String): Intent =
            Intent(context, AnalysisActivity::class.java)
                .putExtra(EXTRA_PAYLOAD, payload)
                .putExtra(EXTRA_SOURCE, source)

        fun intent(context: Context, uri: Uri, source: String): Intent =
            intent(context, uri.toString(), source)

        private const val EXTRA_PAYLOAD = "payload"
        private const val EXTRA_SOURCE = "source"
    }
}
