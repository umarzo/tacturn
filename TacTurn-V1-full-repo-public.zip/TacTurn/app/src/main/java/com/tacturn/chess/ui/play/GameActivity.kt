package com.tacturn.chess.ui.play

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.tacturn.chess.R
import com.tacturn.chess.data.Prefs
import com.tacturn.chess.databinding.ActivityGameBinding
import com.tacturn.chess.engine.BLACK
import com.tacturn.chess.engine.BISHOP
import com.tacturn.chess.engine.GameResult
import com.tacturn.chess.engine.KNIGHT
import com.tacturn.chess.engine.QUEEN
import com.tacturn.chess.engine.ROOK
import com.tacturn.chess.engine.WHITE
import com.tacturn.chess.ui.BoardTarget
import com.tacturn.chess.ui.ClockUiState
import com.tacturn.chess.ui.GameUiState
import com.tacturn.chess.ui.PieceIconView
import com.tacturn.chess.ui.SoundManager
import com.tacturn.chess.ui.SoundType
import com.tacturn.chess.ui.StatusStyle
import kotlinx.coroutines.launch

/**
 * TacTurn v2 — the game screen for BOTH modes:
 *
 *  - Play vs Engine (any Elo level, optional clock)
 *  - Pass & Play (two local players, optional clock, auto-flip board)
 *
 * Anatomy is unchanged from v1 (board fills all leftover space) with new
 * elements: a chess clock pill at the end of each player row, a Draw
 * button in the action bar, mode-aware player labels, draw-offer and
 * resign dialogs, time-forfeit result cards, an opening-name badge in the
 * top bar, and a shareable PGN on the game-over card.
 */
class GameActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameBinding
    private val viewModel: GameViewModel by viewModels()
    private val soundManager by lazy { SoundManager(this) }

    private lateinit var config: GameConfig

    private var renderedMoveCount = -1
    private var lastSoundId = -1
    private var lastNoticeId = -1
    private var lastChipSig: Pair<Int, String?>? = null
    private var promotionDialog: android.app.Dialog? = null
    private var drawDialog: android.app.Dialog? = null
    private var vibrator: Vibrator? = null

    /** The mode the top avatar was last rendered for — the avatar is only
     *  restyled when the mode actually changes (robot vs human player). */
    private var renderedAvatarMode: GameMode? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)

        config = GameConfig.fromIntent(intent)
        vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator

        binding.btnBack.setOnClickListener { finish() }
        binding.boardView.onMoveAttempt = { from, to -> viewModel.requestMove(from, to) }

        binding.btnNew.setOnClickListener { viewModel.newGame() }
        binding.btnFlip.setOnClickListener { viewModel.flip() }
        binding.btnUndo.setOnClickListener { viewModel.undo() }
        binding.btnResign.setOnClickListener { showResignConfirm() }
        binding.btnRematch.setOnClickListener { viewModel.rematch() }
        binding.btnDraw.setOnClickListener { onDrawPressed() }
        binding.btnAnalyzeGame.setOnClickListener {
            viewModel.exportPgn { pgn ->
                if (pgn.isNotBlank()) {
                    startActivity(
                        com.tacturn.chess.ui.analysis.AnalysisActivity.intent(
                            this, pgn, com.tacturn.chess.ui.analysis.AnalysisActivity.SOURCE_PGN_TEXT
                        )
                    )
                }
            }
        }
        binding.btnSharePgn.setOnClickListener { sharePgn() }

        // Only (re)start a fresh game on a true launch — a rotation
        // recreate must keep the in-progress session alive in the ViewModel.
        if (savedInstanceState == null || !viewModel.ui.value.started) {
            viewModel.startGame(config)
        }

        // Start from the event id already showing (if any): a fresh session
        // has none, so the VERY FIRST move plays; after a rotation the last
        // event is stale and must not replay its sound.
        lastSoundId = viewModel.ui.value.soundEvent?.id ?: -1

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.ui.collect { render(it) }
            }
        }
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.clockUi.collect { renderClocks(it) }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        soundManager.enabled = Prefs.soundEnabled(this)
    }

    override fun onStart() {
        super.onStart()
        viewModel.resumeClock()
    }

    override fun onStop() {
        super.onStop()
        // Freeze the clock while the app is away — friendly for pass & play.
        viewModel.pauseClock()
    }

    // ------------------------------------------------------------------
    // Main render
    // ------------------------------------------------------------------

    private fun render(state: GameUiState) {
        val vsEngine = state.mode == GameMode.ENGINE

        // Top bar: difficulty / mode badge + opening name.
        binding.difficultyBadge.text = state.difficultyLabel
        binding.engineEloBadge.text = state.openingName.ifEmpty {
            if (state.timeControlLabel.isEmpty()) "" else state.timeControlLabel
        }

        renderTopAvatar(vsEngine)

        binding.topNameText.text = state.topLabel
        binding.bottomNameText.text = state.bottomLabel

        // Engine-only chrome. GONE (not INVISIBLE) in Pass & Play so the
        // human player's name re-centers instead of floating above a
        // phantom engine-info line.
        binding.thinkingIndicator.visibility =
            if (state.thinking) View.VISIBLE else View.INVISIBLE
        binding.engineInfoText.visibility = if (vsEngine) View.VISIBLE else View.GONE

        binding.boardView.setPosition(
            squares = state.board.toIntArray(),
            targets = state.legalMoves.map {
                BoardTarget(it.from, it.to, it.isCapture, it.isPromotion)
            },
            lastFrom = state.lastFrom,
            lastTo = state.lastTo,
            checkSquare = state.checkSquare,
            orientation = state.orientation,
            playerColor = state.moverColor,
            inputEnabled = state.yourTurn && state.result == GameResult.ONGOING,
            themeIndex = Prefs.boardTheme(this)
        )
        binding.boardView.setBestMoveArrow(null)

        if (state.moveCounter != renderedMoveCount) {
            val animate = renderedMoveCount >= 0 && state.moveCounter > renderedMoveCount
            renderedMoveCount = state.moveCounter
            if (animate && state.lastFrom >= 0) binding.boardView.animateLastMove()
        }

        // Status line.
        binding.statusText.text = state.statusText
        val (bg, fg) = when (state.statusStyle) {
            StatusStyle.PLAYER -> R.drawable.pill_red to R.color.white
            StatusStyle.THINKING -> R.drawable.pill_grey to R.color.text_primary
            StatusStyle.CHECK -> R.drawable.pill_gold to R.color.on_gold
            StatusStyle.WIN -> R.drawable.pill_green to R.color.white
            StatusStyle.LOSE -> R.drawable.pill_dark to R.color.white
            StatusStyle.DRAW -> R.drawable.pill_grey to R.color.text_primary
        }
        binding.statusText.setBackgroundResource(bg)
        binding.statusText.setTextColor(getColor(fg))

        binding.engineInfoText.text = state.engineInfo

        // Move history chips: rebuild only when the content actually changed.
        val chipSig = state.moveRows.size to state.moveRows.lastOrNull()?.blackSan
        if (chipSig != lastChipSig) {
            lastChipSig = chipSig
            rebuildMoveChips(state)
        }

        // Captured material (orientation-aware strips).
        binding.capturedTop.setCaptured(state.capturedByEngine)
        binding.capturedBottom.setCaptured(state.capturedByPlayer)
        binding.materialDiff.text = when {
            state.materialDiff < 0 -> "+${(-state.materialDiff) / 100.0}"
            else -> ""
        }
        binding.materialDiff2.text = when {
            state.materialDiff > 0 -> "+${state.materialDiff / 100.0}"
            else -> ""
        }

        val canUndo = !state.thinking && state.result == GameResult.ONGOING && state.moveCounter > 0
        binding.btnUndo.isEnabled = canUndo
        binding.btnNew.isEnabled = !state.thinking
        binding.btnResign.isEnabled = !state.thinking && state.result == GameResult.ONGOING
        binding.btnDraw.isEnabled = state.canOfferDraw

        // Game over overlay + history persistence.
        val over = state.result != GameResult.ONGOING
        binding.gameOverOverlay.visibility = if (over) View.VISIBLE else View.GONE
        if (over) {
            renderGameOver(state)
            if (!viewModel.consumeResultPersistFlag()) {
                persistPlayedGame(state)
            }
        }

        // Sounds + haptics — every fresh event id plays (the id baseline is
        // set in onCreate, so the first move is never silently swallowed).
        state.soundEvent?.let { ev ->
            if (ev.id != lastSoundId) {
                lastSoundId = ev.id
                soundManager.play(ev.type)
                maybeVibrate(ev.type)
            }
        }

        // Transient notices (e.g. engine declines a draw offer).
        state.noticeEvent?.let { n ->
            if (n.id != lastNoticeId) {
                lastNoticeId = n.id
                Snackbar.make(binding.root, n.text, Snackbar.LENGTH_SHORT)
                    .setAnchorView(binding.statusText)
                    .show()
            }
        }

        // Promotion dialog.
        if (state.pendingPromotion != null && promotionDialog == null) {
            showPromotionDialog(state)
        } else if (state.pendingPromotion == null) {
            promotionDialog?.dismiss()
            promotionDialog = null
        }

        // Pass & Play draw offer — the OPPONENT answers in a dialog.
        if (state.drawOfferFrom != -1 && drawDialog == null) {
            showDrawOfferDialog(state)
        } else if (state.drawOfferFrom == -1) {
            drawDialog?.dismiss()
            drawDialog = null
        }
    }

    /** Mode-aware top-row avatar: the engine robot vs Engine games, and a
     *  person-in-circle for the human player in Pass & Play (the robot was
     *  hardcoded in every layout variant, so a local player looked like a
     *  bot). Mirrors the bottom row's styling for visual consistency. */
    private fun renderTopAvatar(vsEngine: Boolean) {
        val mode = if (vsEngine) GameMode.ENGINE else GameMode.HUMAN
        if (renderedAvatarMode == mode) return
        renderedAvatarMode = mode
        val avatar = binding.avatarTop
        if (vsEngine) {
            avatar.setBackgroundResource(0)
            avatar.setPadding(0, 0, 0, 0)
            avatar.imageTintList = null
            avatar.setImageResource(R.drawable.avatar_engine)
        } else {
            avatar.setBackgroundResource(R.drawable.bg_avatar_circle)
            val pad = dp(7)
            avatar.setPadding(pad, pad, pad, pad)
            avatar.imageTintList = android.content.res.ColorStateList.valueOf(
                com.google.android.material.color.MaterialColors.getColor(
                    avatar, com.google.android.material.R.attr.colorOnPrimaryContainer
                )
            )
            avatar.setImageResource(R.drawable.ic_person)
        }
    }

    private fun renderGameOver(state: GameUiState) {
        val vsEngine = state.mode == GameMode.ENGINE
        // Names are orientation-dependent in the strips; reconstruct the
        // color-truth names for the result card.
        val whiteName = nameOf(state, WHITE)
        val blackName = nameOf(state, BLACK)
        val winner = if (state.result == GameResult.WHITE_WINS) whiteName else blackName

        val (title, subtitle, trophy) = when {
            state.result.isDraw -> when (state.endReason) {
                GameViewModel.END_AGREEMENT -> Triple(
                    getString(R.string.draw_agreed_title),
                    getString(R.string.result_draw_agreed), false
                )
                GameViewModel.END_TIMEOUT_DRAW -> Triple(
                    getString(R.string.draw_title),
                    getString(R.string.result_timeout_draw), false
                )
                else -> Triple(
                    getString(R.string.draw_title),
                    drawReason(state.result), false
                )
            }
            vsEngine && state.timeForfeitLoser == state.playerColor -> Triple(
                getString(R.string.result_time_title),
                getString(R.string.result_time_loss_engine), false
            )
            vsEngine && state.timeForfeitLoser != -1 -> Triple(
                getString(R.string.result_time_title),
                getString(R.string.result_time_win), true
            )
            state.endReason == GameViewModel.END_TIME -> Triple(
                getString(R.string.result_time_title),
                getString(R.string.result_time_loss, winner), false
            )
            state.endReason == GameViewModel.END_RESIGN -> Triple(
                getString(R.string.result_resign_title),
                if (vsEngine) {
                    if (state.result == GameResult.WHITE_WINS && state.playerColor == WHITE ||
                        state.result == GameResult.BLACK_WINS && state.playerColor == BLACK
                    ) getString(R.string.result_you_win) else getString(R.string.result_engine_wins)
                } else getString(R.string.result_wins_by, winner),
                vsEngine && ((state.result == GameResult.WHITE_WINS && state.playerColor == WHITE) ||
                        (state.result == GameResult.BLACK_WINS && state.playerColor == BLACK))
            )
            vsEngine -> {
                val youWin = (state.result == GameResult.WHITE_WINS && state.playerColor == WHITE) ||
                        (state.result == GameResult.BLACK_WINS && state.playerColor == BLACK)
                if (youWin) Triple(
                    getString(R.string.result_checkmate_you_win),
                    getString(R.string.result_you_win), true
                ) else Triple(
                    getString(R.string.result_checkmate_engine_wins),
                    getString(R.string.result_engine_wins), false
                )
            }
            else -> Triple(
                getString(R.string.result_checkmate_side_wins, winner),
                "${resultScore(state.result)} · ${state.moveCounter} moves",
                false
            )
        }
        binding.resultTitle.text = title
        binding.resultSubtitle.text = subtitle
        binding.trophyIcon.setImageResource(
            if (trophy) R.drawable.ic_trophy else R.drawable.ic_trophy_neutral
        )
        binding.resultMeta.text = buildString {
            if (state.timeControlLabel.isNotEmpty()) append(state.timeControlLabel)
            if (state.openingName.isNotEmpty()) {
                if (isNotEmpty()) append(" · ")
                append(state.openingName)
            }
        }
    }

    /** Orientation-independent display name for a color. */
    private fun nameOf(state: GameUiState, color: Int): String =
        if (color == WHITE) {
            // bottom/top labels follow orientation; reconstruct white's name
            if (state.orientation == WHITE) state.bottomLabel else state.topLabel
        } else {
            if (state.orientation == WHITE) state.topLabel else state.bottomLabel
        }

    private fun resultScore(result: GameResult): String = when (result) {
        GameResult.WHITE_WINS -> "1-0"
        GameResult.BLACK_WINS -> "0-1"
        else -> "1/2-1/2"
    }

    private fun persistPlayedGame(state: GameUiState) {
        if (state.moveCounter < 1) return
        viewModel.persistPlayedGame(state)
    }

    // ------------------------------------------------------------------
    // Clocks
    // ------------------------------------------------------------------

    private fun renderClocks(c: ClockUiState) {
        val show = c.visible
        binding.clockTop.visibility = if (show) View.VISIBLE else View.GONE
        binding.clockBottom.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) return

        // Map board sides onto top/bottom views by the current orientation.
        val orientation = viewModel.ui.value.orientation
        val topColor = orientation xor 1
        val bottomColor = orientation

        val topMs = if (topColor == WHITE) c.whiteMs else c.blackMs
        val bottomMs = if (bottomColor == WHITE) c.whiteMs else c.blackMs

        renderOneClock(binding.clockTop, topMs, c.activeColor == topColor,
            topColor == WHITE && c.whiteLow || topColor == BLACK && c.blackLow,
            c.flaggedColor == topColor, c.paused)
        renderOneClock(binding.clockBottom, bottomMs, c.activeColor == bottomColor,
            bottomColor == WHITE && c.whiteLow || bottomColor == BLACK && c.blackLow,
            c.flaggedColor == bottomColor, c.paused)
    }

    private fun renderOneClock(
        view: TextView,
        ms: Long,
        active: Boolean,
        low: Boolean,
        flagged: Boolean,
        paused: Boolean
    ) {
        view.text = config.timeControl.format(ms)
        val (bg, fg, alpha) = when {
            flagged -> Triple(R.drawable.clock_pill_flagged, R.color.white, 1f)
            active && low -> Triple(R.drawable.clock_pill_low, R.color.white, 1f)
            active -> Triple(R.drawable.clock_pill_active, R.color.white, 1f)
            low -> Triple(R.drawable.clock_pill_idle, R.color.md_error, if (paused) 0.55f else 1f)
            else -> Triple(R.drawable.clock_pill_idle, R.color.text_primary, if (paused) 0.55f else 1f)
        }
        view.setBackgroundResource(bg)
        view.setTextColor(getColor(fg))
        view.alpha = alpha
    }

    // ------------------------------------------------------------------
    // Dialogs
    // ------------------------------------------------------------------

    private fun showResignConfirm() {
        val state = viewModel.ui.value
        if (state.result != GameResult.ONGOING) return
        val vsEngine = state.mode == GameMode.ENGINE
        val moverName = if (state.mode == GameMode.HUMAN) nameOf(state, state.moverColor)
        else getString(R.string.you_label)
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.resign_title)
            .setMessage(
                if (vsEngine) getString(R.string.resign_message)
                else getString(R.string.resign_message_pvp, moverName)
            )
            .setPositiveButton(R.string.resign_yes) { _, _ -> viewModel.resign() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun onDrawPressed() {
        val state = viewModel.ui.value
        if (state.mode == GameMode.HUMAN) {
            viewModel.offerDraw()   // opponent gets the dialog via state
        } else {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.draw_confirm_title)
                .setMessage(R.string.draw_confirm_message)
                .setPositiveButton(R.string.draw_offer_accept_me) { _, _ -> viewModel.offerDraw() }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    private fun showDrawOfferDialog(state: GameUiState) {
        val offerer = nameOf(state, state.drawOfferFrom)
        val opponent = nameOf(state, state.drawOfferFrom xor 1)
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(R.string.draw_offer_title)
            .setMessage(getString(R.string.draw_offer_message, offerer, opponent))
            .setPositiveButton(R.string.draw_offer_accept) { _, _ -> viewModel.acceptDraw() }
            .setNegativeButton(R.string.draw_offer_decline) { _, _ -> viewModel.declineDraw() }
            .setCancelable(false)
            .show()
        drawDialog = dialog
    }

    private fun sharePgn() {
        viewModel.exportPgn { pgn ->
            if (pgn.isBlank()) return@exportPgn
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/x-chess-pgn"
                putExtra(Intent.EXTRA_TEXT, pgn)
                putExtra(Intent.EXTRA_TITLE, getString(R.string.pgn_shared_chooser))
            }
            startActivity(Intent.createChooser(send, getString(R.string.pgn_shared_chooser)))
        }
    }

    private fun drawReason(result: GameResult): String = when (result) {
        GameResult.DRAW_STALEMATE -> getString(R.string.result_stalemate)
        GameResult.DRAW_FIFTY_MOVE -> getString(R.string.result_fifty)
        GameResult.DRAW_REPETITION -> getString(R.string.result_repetition)
        GameResult.DRAW_INSUFFICIENT_MATERIAL -> getString(R.string.result_insufficient)
        GameResult.DRAW_AGREEMENT -> getString(R.string.result_draw_agreed)
        else -> ""
    }

    // ------------------------------------------------------------------
    // Move history chips
    // ------------------------------------------------------------------

    private fun rebuildMoveChips(state: GameUiState) {
        val container = binding.moveChips
        container.removeAllViews()
        val inflater = LayoutInflater.from(this)
        for (row in state.moveRows) {
            addChip(inflater, container, "${row.number}.", isNumber = true)
            row.whiteSan?.let { addChip(inflater, container, it, isNumber = false) }
            row.blackSan?.let { addChip(inflater, container, it, isNumber = false) }
        }
        binding.moveHistoryScroll.post { binding.moveHistoryScroll.fullScroll(View.FOCUS_RIGHT) }
    }

    private fun addChip(inflater: LayoutInflater, container: LinearLayout, text: String, isNumber: Boolean) {
        val chip = inflater.inflate(R.layout.item_move_chip, container, false) as TextView
        chip.text = text
        chip.setTextColor(
            if (isNumber) getColor(R.color.text_hint) else getColor(R.color.text_primary)
        )
        container.addView(chip)
        (chip.layoutParams as LinearLayout.LayoutParams).gravity = Gravity.CENTER_VERTICAL
    }

    // ------------------------------------------------------------------
    // Promotion dialog
    // ------------------------------------------------------------------

    private fun showPromotionDialog(state: GameUiState) {
        // The promoting side: engine mode -> always the player; PvP -> the
        // pawn owner on the from-square.
        val from = state.pendingPromotion?.first ?: return
        val color = if (state.mode == GameMode.ENGINE) state.playerColor
        else (state.board[from].takeIf { it >= 0 }?.shr(3) ?: state.moverColor)
        val options = listOf(QUEEN, ROOK, BISHOP, KNIGHT)
        val dialog = android.app.Dialog(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(22))
            setBackgroundResource(R.drawable.card_white)
        }
        val title = TextView(this).apply {
            text = getString(R.string.promotion_title)
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(attrColor(com.google.android.material.R.attr.colorOnSurface))
            typeface = androidx.core.content.res.ResourcesCompat.getFont(
                this@GameActivity, com.tacturn.chess.R.font.plus_jakarta_sans_800
            )
            setPadding(0, 0, 0, dp(14))
        }
        layout.addView(title)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (opt in options) {
            val icon = PieceIconView(this).apply {
                setPiece(opt, color)
                layoutParams = LinearLayout.LayoutParams(dp(64), dp(64)).apply {
                    marginStart = dp(6)
                    marginEnd = dp(6)
                }
                setBackgroundResource(R.drawable.card_option)
                isClickable = true
                setOnClickListener { viewModel.completePromotion(opt) }
            }
            row.addView(icon)
        }
        layout.addView(row)
        dialog.setContentView(layout)
        dialog.setCancelable(true)
        dialog.setOnDismissListener { viewModel.cancelPromotion() }
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.show()
        promotionDialog = dialog
    }

    // ------------------------------------------------------------------
    // Haptics
    // ------------------------------------------------------------------

    private fun maybeVibrate(type: SoundType) {
        if (!Prefs.hapticsEnabled(this)) return
        val v = vibrator ?: return
        val ms = when (type) {
            SoundType.MOVE -> 12L
            SoundType.CAPTURE -> 24L
            SoundType.CHECK -> 30L
            else -> 45L
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                v.vibrate(ms)
            }
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------
    // Misc
    // ------------------------------------------------------------------

    /** Resolves a theme color attribute the same way XML's ?attr/x does, for colors set programmatically. */
    private fun attrColor(attrRes: Int): Int =
        com.google.android.material.color.MaterialColors.getColor(binding.root, attrRes)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        promotionDialog?.dismiss()
        promotionDialog = null
        drawDialog?.dismiss()
        drawDialog = null
        soundManager.release()
        super.onDestroy()
    }

    companion object {
        // Intent keys are defined in GameConfig.Companion (single source of
        // truth shared with fromIntent).

        fun intent(context: Context, config: GameConfig): Intent =
            Intent(context, GameActivity::class.java)
                .putExtra(GameConfig.EXTRA_MODE, config.mode.ordinal)
                .putExtra(GameConfig.EXTRA_COLOR, config.playerColor)
                .putExtra(GameConfig.EXTRA_ELO, config.engineElo)
                .putExtra(GameConfig.EXTRA_TC_INITIAL, config.timeControl.initialMs)
                .putExtra(GameConfig.EXTRA_TC_INC, config.timeControl.incrementMs)
                .putExtra(GameConfig.EXTRA_WHITE_NAME, config.whiteName)
                .putExtra(GameConfig.EXTRA_BLACK_NAME, config.blackName)
                .putExtra(GameConfig.EXTRA_AUTO_FLIP, config.autoFlip)
    }
}
