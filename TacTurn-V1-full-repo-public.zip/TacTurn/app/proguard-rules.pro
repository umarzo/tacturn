# TacTurn — ProGuard/R8 rules.

# The chess engine is plain Kotlin with no reflection; default rules suffice.
# Keep line numbers for readable crash reports during development.
-keepattributes SourceFile,LineNumberTable

# Coroutines (safety for release builds on older devices).
-dontwarn kotlinx.coroutines.**

# v2.0.1: native engine bridge — R8 must not rename/remove anything the JNI
# surface touches: the facade classes, the IterationListener callback
# (invoked by name from C via GetMethodID) and the companion natives.
-keep class com.tacturn.chess.engine.** { *; }
-keepclasseswithmembernames class com.tacturn.chess.engine.** {
    native <methods>;
}
-keep class com.tacturn.chess.engine.Game$Companion { *; }
-keep interface com.tacturn.chess.engine.Game$IterationListener { *; }
