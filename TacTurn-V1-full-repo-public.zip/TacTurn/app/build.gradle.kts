plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tacturn.chess"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.tacturn.chess"
        minSdk = 21
        targetSdk = 34
        versionCode = 46
        versionName = "1.4.9"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        // Personal/self-hosted distribution: the release key is committed
        // at keystore/tacturn-v1.keystore so every build machine produces
        // signature-compatible, install-over-updatable APKs; fresh checkouts
        // without it fall back to the standard debug keystore. For Play Store
        // distribution replace with your own private upload keystore (and
        // never commit that one).
        val releaseKeystore = rootProject.file("keystore/tacturn-v1.keystore")
        create("release") {
            if (releaseKeystore.exists()) {
                storeFile = releaseKeystore
                storePassword = "tacturn"
                keyAlias = "tacturn"
                keyPassword = "tacturn"
            } else {
                storeFile = file(
                    System.getProperty("user.home", ".")
                        + "/.android/debug.keystore"
                )
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    // The chess engine lives in its own pure-Kotlin JVM module.
    implementation(project(":engine"))

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.4")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
}
