#!/bin/bash
# TacTurn — package the source tree for release.
#   scripts/package_zip.sh [output.zip]
set -e
cd "$(dirname "$0")/.."
OUT="${1:-tacturn-1.4.0.zip}"
rm -f "$OUT"
# Source tree only: no VCS, no build artifacts, no IDE droppings, no gate
# game records.
zip -r "$OUT" . \
    -x ".git/*" \
    -x "*.zip" \
    -x ".gradle/*" \
    -x "local.properties" \
    -x ".idea/*" \
    -x "build/*" \
    -x "app/build/*" \
    -x "engine/build/*" \
    -x "engine/.cxx/*" \
    -x "scripts/bin/*" \
    -x "games/*" \
    -x ".DS_Store" \
    -x "*.gcda" -x "*.gcno" -x "*.o"
echo "OK: $OUT ($(du -h "$OUT" | cut -f1))"
md5sum "$OUT"
