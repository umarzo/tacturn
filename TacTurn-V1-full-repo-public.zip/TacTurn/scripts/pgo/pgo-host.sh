#!/bin/bash
# TacTurn PGO build helper — HOST REFERENCE pipeline (x86-64).
#
# Demonstrates and validates the exact two-stage PGO flow the Android
# build uses (engine/src/main/cpp/CMakeLists.txt, TACTURN_PGO option).
# The Android flow is identical except the instrumented library runs on
# the phone (see README-PGO.md).
#
# usage: ./pgo-host.sh <engine-src-dir> <out-prefix>
set -e
SRCDIR="$1"
PREFIX="$2"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
WORK="$SCRIPT_DIR/pgo-host-work"
rm -rf "$WORK"
mkdir -p "$WORK"

CORE="$SRCDIR/tacturn"
BIN="$WORK/$PREFIX-pgo"
COMMON=(-std=c++17 -O3 -march=native -DNDEBUG -I"$SRCDIR" -I"$CORE")

# GCC note: the .gcda profile files are keyed by the OUTPUT BINARY name,
# so both stages must build to the same filename — the instrumented
# binary is trained first and then overwritten by the profile-USE build.
echo "== stage 1: instrumented build (-fprofile-generate) =="
g++ "${COMMON[@]}" -fprofile-generate="$WORK/prof" \
    "$SCRIPT_DIR/../host-tools/uci.cpp" "$CORE"/*.cpp \
    -o "$BIN" -lpthread

echo "== stage 2: profile training (90 s deterministic engine workload) =="
"$BIN" - <<'EOF'
pgotrain 90
quit
EOF

echo "== stage 3: profile-USE rebuild (same binary name as stage 1) =="
g++ "${COMMON[@]}" -fprofile-use -fprofile-dir="$WORK/prof" \
    -Wno-missing-profile \
    "$SCRIPT_DIR/../host-tools/uci.cpp" "$CORE"/*.cpp \
    -o "$BIN" -lpthread

echo ""
echo "PGO host pipeline complete: $BIN"
echo "verify:  $BIN bench 14  (fingerprint must equal the plain -O3 build; lower wall time)"
