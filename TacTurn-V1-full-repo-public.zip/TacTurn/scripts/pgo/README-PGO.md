# TacTurn PGO (profile-guided optimization) guide

PGO gives the engine a measured **+10-11% nodes/sec on the host reference
build** (x86-64, GCC; bench-14 workload, HISTORY.md v1.1) and is expected
to be in the same range on ARM64 phones (the engine's hot loops — NNUE
inference, movegen, search — are exactly the branch-profile shapes PGO
rewards). This file documents the full two-stage flow.

**How it works:** stage 1 builds the engine instrumented
(`-fprofile-generate`); a training run on the TARGET device records which
branches/loops are hot; stage 2 rebuilds with `-fprofile-use`, letting the
compiler lay out code, inline and unroll for the real workload mix.

## 1. Android (the shipped app)

Profiles are **architecture- and device-specific** — train on the phone
class you care about (arm64-v8a is the one that matters).

### Stage A — instrumented build

```bash
./gradlew :app:assembleDebug \
  -Pandroid.injected.build.abi=arm64-v8a \
  -PtacturnPgo=GENERATE
```

(`-PtacturnPgo` maps to the engine CMake option `TACTURN_PGO` — see
`engine/src/main/cpp/CMakeLists.txt`.)

Install, then generate a profile by playing a few engine games at high
levels, or more conveniently by calling the dedicated training entry
point — it runs a deterministic 10-position search workload that
exercises the complete hot path (search, quiescence, NNUE, HCE, movegen,
SEE, TT):

```kotlin
// e.g. from a debug screen / adb shell am instrument:
val nodes = Game.nativePgoTrain(90)   // ~90 s of pure searching
```

The instrumented library writes `default.profraw` to the app's external
files dir (`/storage/emulated/0/Android/data/com.tacturn.chess/files/`)
or its data dir (NDK r26+; `LLVM_PROFILE_FILE` can override the path).

### Stage B — pull, merge, rebuild

```bash
adb pull /storage/emulated/0/Android/data/com.tacturn.chess/files/default.profraw .
$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-profdata merge \
    -output=tacturn-arm64.profdata default.profraw

./gradlew :app:assembleRelease \
  -Pandroid.injected.build.abi=arm64-v8a \
  -PtacturnPgo=USE:$(pwd)/tacturn-arm64.profdata
```

Notes:

- Do this **once per ABI**; the arm64 profile is what ships to phones.
- Repeat the training after major engine changes (the v1.1 kernel rewrite
  changed the NNUE hot loop — retrain).
- The profile-USE build is verified by the bench fingerprint: the node
  counts must be **identical** to the plain -O3 build (PGO must never
  change the tree — if it does, the profile was stale).

## 2. Host reference (development / verification)

```bash
scripts/pgo/pgo-host.sh engine/src/main/cpp tacturn
# produces: bench-comparable instrumented and PGO binaries
```

The script builds instrumented, runs the same 90 s `pgotrain` workload,
merges, and rebuilds with `-fprofile-use`. Compare against a plain -O3
build with `bench 14` (same node totals, lower wall time).

## 3. Verification checklist

1. **Bench fingerprint identical** PGO vs non-PGO (PGO is a speed-only
   change; any node-count difference means a stale/mismatched profile).
2. Perft suite unchanged.
3. nps: expect ≈ +10% host; on-device numbers should be verified with a
   quick `go depth 15` timing before/after on the same phone.
