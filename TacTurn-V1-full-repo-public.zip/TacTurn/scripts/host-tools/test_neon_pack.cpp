// Host validation of the v1.1/v1.3.2/v1.4.1 NEON block-GEMV packing +
// kernel logic.
//
// The NEON intrinsics cannot run on x86, so this test re-implements the
// EXACT packed layout and the EXACT accumulation structure of the shipped
// NEON kernels in scalar code, then compares every L2/L3/OUT output
// against the portable per-output reference (the v5.x kernel formula)
// over random activation vectors for all 16 output buckets. Bit-exact
// equality here proves the packing/indexing/accumulation design is
// correct; the NEON intrinsics are a 1:1 translation of the same
// structure.
//
// v1.3.2: the pair-major zero-skipping kernel (dotBlocks4PairMajor),
// including a ~89%-zero activation vector so the skip path is actually
// exercised.
//
// v1.4.1: the packed tables are TRANSPOSED to [bucket][pair][block][8]
// (fixing the 8 KB-stride bug: the v1.3.2 array was [bucket][block][pair][8],
// so the two input passes of each pair were 8 KB apart while the comment
// claimed contiguity). This test now emulates the transposed layout and
// the dotBlocks4PairMajor addressing exactly as shipped in nnue.cpp. The
// old dense dotBlock4 kernel was removed from the engine in v1.4.1
// (dead since v1.3.2), so its emulation is gone too.

#include <cstdio>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <vector>

#include "nnue.h"

using namespace tacturn;
using namespace tacturn::nnue;

static int32_t clipI_(int y, int shift) {
    int v = y >> shift;
    return v < 0 ? 0 : (v > QA ? QA : v);
}

// ---- scalar emulation of the packed tables (same layout as nnue.cpp) ----
struct EmuPacked {
    // v1.4.1 transposed layout — L2: [bucket][pair][L2/4 blocks][8],
    // L3: [bucket][pair][L3/4 blocks][8] (pair-major: each pair's 8
    // block-rows are 128 contiguous bytes).
    std::vector<int16_t> l2, l3;
    EmuPacked()
        : l2((size_t)OUT_BUCKETS * (2 * L1 / 2) * (L2 / 4) * 8),
          l3((size_t)OUT_BUCKETS * (L2 / 2) * (L3 / 4) * 8) {
        for (int b = 0; b < OUT_BUCKETS; b++) {
            for (int q = 0; q < 2 * L1 / 2; q++) {
                for (int blk = 0; blk < L2 / 4; blk++) {
                    int16_t *dst = &l2[(((size_t)b * (2 * L1 / 2) + q) * (L2 / 4) + blk) * 8];
                    for (int k = 0; k < 4; k++) {
                        dst[k] = L2_W[b][blk * 4 + k][2 * q];
                        dst[4 + k] = L2_W[b][blk * 4 + k][2 * q + 1];
                    }
                }
            }
            for (int q = 0; q < L2 / 2; q++) {
                for (int blk = 0; blk < L3 / 4; blk++) {
                    int16_t *dst = &l3[(((size_t)b * (L2 / 2) + q) * (L3 / 4) + blk) * 8];
                    for (int k = 0; k < 4; k++) {
                        dst[k] = L3_W[b][blk * 4 + k][2 * q];
                        dst[4 + k] = L3_W[b][blk * 4 + k][2 * q + 1];
                    }
                }
            }
        }
    }
};

/** Scalar emulation of the v1.4.1 dotBlocks4PairMajor on the transposed
 *  [pair][block][8] layout: ALL 8 four-output blocks in one pass over the
 *  pairs, vmlal_lane semantics (each block's row for pair q =
 *  {a0*w[0..3], a1*w[4..7]}), and the exact skip condition (int32 pair
 *  bit pattern == 0). Bit-exact equivalence with the per-output
 *  reference proves the transposed indexing + restructured loop + skip
 *  are exact; the NEON intrinsic kernel is a 1:1 translation of this
 *  shape. */
static void dotBlocksPairMajorEmu(const int16_t *A, const int16_t *packed, int npairs,
                                  int nBlocks, const int32_t *bias, int shift,
                                  int16_t *y) {
    int32_t d[8][4] = {{0}};
    for (int q = 0; q < npairs; q++) {
        int32_t p;
        std::memcpy(&p, A + 2 * q, sizeof(p));
        if (p == 0) continue;  // both activations zero
        int a0 = A[2 * q], a1 = A[2 * q + 1];
        for (int blk = 0; blk < nBlocks; blk++) {
            // v1.4.1: [pair][block][8] — the row for (q, blk) is at
            // ((q * nBlocks) + blk) * 8 (128 contiguous bytes per pair).
            const int16_t *w = packed + ((size_t)q * nBlocks + blk) * 8;
            d[blk][0] += a0 * w[0] + a1 * w[4];
            d[blk][1] += a0 * w[1] + a1 * w[5];
            d[blk][2] += a0 * w[2] + a1 * w[6];
            d[blk][3] += a0 * w[3] + a1 * w[7];
        }
    }
    for (int blk = 0; blk < nBlocks; blk++)
        for (int k = 0; k < 4; k++)
            y[blk * 4 + k] = (int16_t)clipI_(bias[blk * 4 + k] + d[blk][k], shift);
}

int main() {
    EmuPacked pk;
    uint64_t rng = 0x12345678ULL;
    auto rnd = [&rng]() {
        rng = rng * 6364136223846793005ULL + 1442695040888963407ULL;
        return (int16_t)((rng >> 48) % (QA + 1));  // activations in [0, QA]
    };
    auto coin = [&rng]() {  // 0..99, advances the stream
        rng = rng * 6364136223846793005ULL + 1442695040888963407ULL;
        return (int)((rng >> 40) % 100);
    };

    const int TRIALS = 2000;
    long mismatches = 0, outputs = 0, skipped = 0, totalPairs = 0;
    std::vector<int16_t> A(2 * L1), A2(2 * L1), yRef(L2), yPm(L2),
        act3Ref(L3), act3Pm(L3);

    for (int t = 0; t < TRIALS; t++) {
        int b = t % OUT_BUCKETS;
        for (auto &v : A) v = rnd();

        // v1.3.2 sparsified copy: zero ~89% of the activations (and thus
        // ~80%+ of the pairs) so the skip path carries real load.
        for (size_t i = 0; i < A.size(); i++) A2[i] = coin() < 89 ? 0 : A[i];

        // ---- L2: pair-major zero-skip kernel vs per-output reference ----
        // (checked on BOTH the dense and the ~89%-sparse activations)
        dotBlocksPairMajorEmu(A.data(), &pk.l2[(size_t)b * (2 * L1 / 2) * (L2 / 4) * 8],
                              L1, L2 / 4, L2_B[b], S2, yPm.data());
        for (int j = 0; j < L2; j++) {
            int32_t dot = 0;
            for (int i = 0; i < 2 * L1; i++) dot += (int32_t)A[i] * L2_W[b][j][i];
            yRef[j] = (int16_t)clipI_(L2_B[b][j] + dot, S2);
        }
        for (int j = 0; j < L2; j++) {
            outputs++;
            if (yPm[j] != yRef[j]) { mismatches++; break; }
        }

        dotBlocksPairMajorEmu(A2.data(), &pk.l2[(size_t)b * (2 * L1 / 2) * (L2 / 4) * 8],
                              L1, L2 / 4, L2_B[b], S2, yPm.data());
        for (int j = 0; j < L2; j++) {
            int32_t dot = 0;
            for (int i = 0; i < 2 * L1; i++) dot += (int32_t)A2[i] * L2_W[b][j][i];
            yRef[j] = (int16_t)clipI_(L2_B[b][j] + dot, S2);
        }
        for (int j = 0; j < L2; j++) {
            outputs++;
            if (yPm[j] != yRef[j]) { mismatches++; break; }
        }
        for (int q = 0; q < L1; q++) {
            totalPairs++;
            if (A2[2 * q] == 0 && A2[2 * q + 1] == 0) skipped++;
        }

        // ---- L3 (input = the pair-major L2 activations) ----
        dotBlocksPairMajorEmu(yPm.data(), &pk.l3[(size_t)b * (L2 / 2) * (L3 / 4) * 8],
                              L2 / 2, L3 / 4, L3_B[b], S3, act3Pm.data());
        for (int k = 0; k < L3; k++) {
            int32_t dot = 0;
            for (int j = 0; j < L2; j++) dot += (int32_t)yPm[j] * L3_W[b][k][j];
            act3Ref[k] = (int16_t)clipI_(L3_B[b][k] + dot, S3);
        }
        for (int k = 0; k < L3; k++) {
            outputs++;
            if (act3Pm[k] != act3Ref[k]) { mismatches++; break; }
        }

        // ---- OUT ----
        int32_t oRef = B4[b], oPm = B4[b];
        for (int k = 0; k < L3; k++) {
            oRef += (int32_t)act3Ref[k] * W4[b][k];
            oPm += (int32_t)act3Pm[k] * W4[b][k];
        }
        outputs += 2;
        if (oPm != oRef) mismatches++;
    }

    std::printf("NEON-packing emulation (v1.4.1 transposed layout): %d trials x 16 buckets, %ld output checks, %ld mismatches\n",
                TRIALS, outputs, mismatches);
    std::printf("sparse-A pair statistics: %ld of %ld pairs skipped (%.1f%%)\n",
                skipped, totalPairs, totalPairs ? 100.0 * skipped / totalPairs : 0.0);
    std::printf("%s\n", mismatches == 0 ? "PASS — transposed packing + pair-major skip kernel bit-identical"
                                        : "FAIL");
    return mismatches == 0 ? 0 : 1;
}
