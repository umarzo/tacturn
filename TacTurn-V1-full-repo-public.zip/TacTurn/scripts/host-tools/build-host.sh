#!/bin/bash
# Build the TacTurn host UCI harness from a given source directory.
#   usage: build.sh <srcdir> <outname> [extra flags...]
# Example:
#   ./build.sh baseline-cpp tacturn-base
#   ./build.sh candidate-cpp tacturn-cand -DTAC_CAPORDER
set -e
SRCDIR="$1"
OUT="$2"
shift 2

CORE="$SRCDIR/tacturn"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TOOLSDIR="$SCRIPT_DIR"  # uci.cpp lives in host-tools itself

OUTDIR="$SCRIPT_DIR/../bin"
mkdir -p "$OUTDIR"

g++ -std=c++17 -O3 -flto -march=native \
    -DNDEBUG \
    -I"$SRCDIR" -I"$CORE" \
    "$@" \
    "$TOOLSDIR/uci.cpp" \
    "$CORE/types.cpp" \
    "$CORE/bitboard.cpp" \
    "$CORE/evaltables.cpp" \
    "$CORE/position.cpp" \
    "$CORE/movegen.cpp" \
    "$CORE/see.cpp" \
    "$CORE/evaluate.cpp" \
    "$CORE/nnue.cpp" \
    "$CORE/nnue_net.cpp" \
    "$CORE/search.cpp" \
    "$CORE/book.cpp" \
    "$CORE/book_data.cpp" \
    "$CORE/game.cpp" \
    "$CORE/api.cpp" \
    -o "$OUTDIR/$OUT" -lpthread

echo "built $OUTDIR/$OUT"
