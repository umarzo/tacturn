# TacTurn ♞

**A native Android chess app with a hand-written C++ engine.**

TacTurn is a complete, production-quality Android project: a bitboard chess
engine (100% original C++17, zero chess libraries, zero third-party code), a
polished Material 3 UI with a bold, modern visual language, and generated
sound effects.

**v1** is the first stable production release: the NNUE residual
hybrid engine (net `v96b-mix21m-3ep`, the strongest configuration ever
measured in this project — **+162 ± 17 Elo over the pure-HCE engine**,
SPRT-gated), **Play vs Engine** (100–3000 Elo) and **Pass & Play** (two
players on one device), **time controls for every
category** — Bullet, Blitz, Rapid, Classical, Unlimited and a Custom builder,
all with Fischer increments, low-time displays and proper flag-fall endings —
**draw offers** (mutual agreement in Pass & Play, evaluation-based
accept/decline vs the engine), **live opening names**, **shareable full-tag
PGN export**, a full **game review** with Elo-personalized coaching, auto-
promote, haptics and richer game history. The app is fully offline: it
requests no network permission and contains zero network code. The complete
engineering history and verification record lives in
**[HISTORY.md](HISTORY.md)**.

Every line of chess logic (board, movegen, rules, SAN, search, evaluation,
opening book) runs natively through JNI — the Kotlin side is UI plus a thin
facade with no chess logic of its own.

| | |
|---|---|
| Version | **1.4.4** (versionCode 42) — fourth-claim audit: provably-illegal in-check skip + pre-make king-ray legality gate + fused single-pass NNUE accumulator replay (bit-exact, +2.7% NPS interleaved); clocked-timeman depth-1 swing guard + cross-move lastScore drop trigger; Lazy-SMP consensus vote best-thread pick (multi-thread); proven game-level bit-exact vs 1.4.3 (self-play sequence identity at depth 12/14, 0/8 openings); match read +5.2 ± 11.2 vs 1.4.3 at 60 ms (see HISTORY §41) |
| Package | `com.tacturn.chess` |
| Engine | C++17 (`libtacturn.so`) via NDK/JNI — 100% original code |
| Kotlin | UI + thin facade only (bindings, no chess logic) |
| Build | Gradle 8.7 (Kotlin DSL) · AGP 8.5.2 · CMake 3.22 · JDK 17 |
| SDK | minSdk 21 · targetSdk 34 |
| ABIs | arm64-v8a, armeabi-v7a, x86_64 |
| Chess deps | **none** — engine is fully self-contained (MIT) |
| Engine memory | ≈ 34 MB peak (2^21-entry-equivalent 4-way-bucket transposition table at 16 B/slot) |

---

## Playing the engine

The Play tab is a full **New Game** setup: pick the mode (Play vs Engine or
Pass & Play), the time control (Unlimited, Bullet 1+0…2+1, Blitz 3+0…5+3,
Rapid 10+0…15+10, Classical 30+0…60+30, or Custom), and — vs the engine —
the Elo slider, **100–3000**, plus your color. The level maps onto four
coupled skill parameters (search depth, think time, root jitter and
thread/adaptive extras):

- Low levels think briefly, see little, and blunder via *root jitter* —
  random centipawn noise on root scores that produces human-looking slips
  instead of artificial "random legal moves".
- From 2100 up the engine uses adaptive time allocation (complexity-aware
  budgets, instability extensions) and extra Lazy-SMP threads.
- The **3000 ceiling** is real strength, not a label: depth-unlimited search
  with an 8 s soft budget (12 s hard cap) on **all eight** Lazy-SMP
  threads (the engine's designed maximum) and a doubled transposition
  table.

A per-level breakdown of the anchor table lives in
`app/src/main/java/com/tacturn/chess/ui/play/EloLevels.kt`; the engineering
history behind the engine's strength is consolidated in `HISTORY.md`.

---

## Building and running

### Android Studio (recommended)

1. Install **Android Studio Hedgehog (2023.1.1) or newer** with **JDK 17**,
   plus an **NDK** (any recent LTS; the project expects CMake 3.22+, which
   the SDK manager installs automatically).
2. Open the project folder (File → Open). Gradle sync should complete
   without errors — the wrapper (`gradle/wrapper/`) is included.
3. Press **Run** on a device or emulator with API 21+.

### Command line

Prerequisite: a **full JDK 17+ installation** — a headless JRE is not enough.
AGP 8.5.2's toolchain invokes `jlink`/`javac` from the JDK, and builds on
JRE-only hosts fail with a `jlink` / `Cannot run program` error before any
task runs. Verify with `jlink --version` before building.

```bash
./gradlew :app:assembleDebug          # outputs app/build/outputs/apk/debug/app-debug.apk
adb install app/build/outputs/apk/debug/app-debug.apk
```

Release (self-hosted distribution signs with the standard debug keystore —
replace `signingConfigs.release` in `app/build.gradle.kts` with your own
keystore for store distribution):

```bash
./gradlew :app:assembleRelease        # app/build/outputs/apk/release/app-release.apk
```

The C++ engine core has no Android dependencies and can be compiled with
plain CMake on a desktop host if ever needed (a plain `add_library` over the
sources in `engine/src/main/cpp/tacturn/`). A portable reference host build
of the exact shipped engine — `binaries/tacturn-1.4.4-linux-x64` in the
distribution zip — is kept as the strength/identity reference. Run it
(`./binaries/tacturn-1.4.4-linux-x64 [depth]`) and it reports the shipped
version string plus a deterministic startpos search fingerprint
(depth 9 = 219,136 total nodes across the 6-position suite, single thread); matching
node counts across builds prove identical search behavior. The
development-time host harness, test-suite and tuning tooling that produced
the engine is documented in `HISTORY.md`.

## Project layout

```
TacTurn/
├── engine/                     # Native C++ chess engine (Android library)
│   └── src/main/
│       ├── cpp/tacturn/
│       │   ├── types.h/.cpp        # move encoding, bit helpers (JNI-shared)
│       │   ├── bitboard.h/.cpp     # attack tables + runtime magic bitboards
│       │   ├── evaltables.h/.cpp   # PeSTO PSTs + tuned eval parameters
│       │   ├── eval_tuned.h        # Texel tuner output (shipped parameters)
│       │   ├── position.h/.cpp     # bitboard state, make/unmake, FEN, repetition
│       │   ├── movegen.h/.cpp      # pseudo-legal generation (+ legality filter)
│       │   ├── see.h/.cpp          # static exchange evaluation
│       │   ├── evaluate.h/.cpp     # tapered evaluation + pawn hash
│       │   ├── ttable.h            # lock-free transposition table (SMP-safe)
│       │   ├── timeman.h           # adaptive time allocation
│       │   ├── search.h/.cpp       # iterative-deepening PVS + Lazy SMP
│       │   ├── book.h/.cpp         # opening book (+ book_data.cpp, 3,996 lines)
│       │   ├── game.h/.cpp         # rules layer: SAN, results, records
│       │   ├── api.h/.cpp          # stable flat C API (the JNI boundary)
│       │   ├── jni/tacturn_jni.cpp # JNI marshalling
│       └── kotlin/com/tacturn/chess/engine/
│           ├── Types.kt            # constants + move decode helpers (pure Kotlin)
│           └── Game.kt             # facade over the native session
├── app/                        # Android UI (Material 3)
│   └── src/main/
│       ├── java/com/tacturn/chess/
│       │   ├── ui/                 # board view, game/analysis/profile screens
│       │   ├── analysis/           # accuracy, game review, Elo personalization
│       │   ├── data/               # prefs + history repository
│       │   └── pgn/                # PGN import/replay
│       └── res/                    # layouts, drawables, themes, sounds (raw/)
├── scripts/                    # release packaging tooling
├── HISTORY.md                  # consolidated development history
└── README.md
```

## Engine architecture

### Board representation
- **Bitboards** — one 64-bit word per piece type, two per colour, plus a
  mailbox (`pieceAt`: `-1` empty, else `(color<<3)|type` — the exact encoding
  the Android UI consumes, so moves cross the JNI boundary as plain ints).
- **Magic bitboards** — generated deterministically at init from a
  splitmix64 stream (no hand-maintained constants, identical results on
  every platform). Slider attacks are one multiply/shift/lookup; x86-64
  hosts additionally get a runtime-dispatched PEXT path (bit-exact).
- **Incrementally updated state** through make/unmake: Zobrist key, pawn
  key, midgame/endgame PST scores, game phase, and the checkers of the side
  to move (computed in make — in-check and gives-check become O(1) in
  search). A grow-only StateInfo stack keeps the game and search fully
  reversible; the key history doubles as the repetition-detection stack.

### Search
Iterative-deepening **principal-variation search** (fail-soft alpha-beta):

- **Transposition table** — 2M entries (~50 MB), age-aware replacement,
  mate-distance-adjusted scores, packed two-word entries with a
  key-XOR-verification design that makes concurrent Lazy-SMP writes safe:
  any interleaving degrades to a clean miss, a torn entry can never be used.
  The table also caches static evals (shared with quiescence).
- **Quiescence search** with full evasions while in check, **SEE filtering**
  of losing captures and unsound checks, MVV-LVA + capture-history
  ordering, delta pruning, and checking moves at the first quiescence ply.
- **Null-move pruning** (adaptive R), **reverse futility** with an
  *improving* flag, razoring, **futility pruning** and **late move pruning**
  of quiets, **unified SEE pruning** of clearly losing moves at shallow
  non-PV depths.
- **Late move reductions** (0.80 + ln·ln/2.25 formula; PV/cut-node/killer/
  counter-move/history adjustments, plus reductions for bad captures),
  **singular extensions** with a multi-cut shortcut, check extensions,
  **aspiration windows** (12 cp initial, floor-protected widening),
  **internal iterative reduction**, and the **partial-iteration salvage**
  with its sound-evidence guard (aborted iterations may publish a best move
  only when it genuinely beat the window floor).
- **Evaluation correction history** — pawn, own-non-pawn and enemy-non-pawn
  buckets keyed by Zobrist, learned online during search.
- **Move ordering**: TT move → promotions → captures (MVV-LVA + capture
  history) → killers → counter-moves → quiets by side-aware piece-to
  history plus continuation histories, gravity-bounded updates.
- **Lazy SMP** — up to 8 search threads over `std::thread` sharing the
  lock-free TT (the app's 3000 preset uses all 8).
- **Adaptive time management** — complexity-scaled soft budget, hard
  wall-clock cap, depth floor, instability extension; clock-aware pacing
  (t/(moves-to-go+2) + increment/2 with a proportional floor) in the time
  manager, shared by the app's clock-clamped engine play.
- **Draw awareness** with 12 cp contempt; twofold repetition and the
  50-move rule return the contempt score inside the tree.
- `tacturn_request_stop()` unwinds within milliseconds and always restores
  the position exactly (verified by the development-time native test suite;
  see `HISTORY.md` for the verification record).

### Evaluation
Tapered (midgame/endgame interpolated) evaluation — every term is a
parameterised `(amount × tuned weight)` product, fitted as a whole by the
offline Texel-tuning pipeline on ~1M self-play positions (pipeline and
fit history in `HISTORY.md`; the fitted parameters ship in
`eval_tuned.h`):

- material + tuned piece-square tables (maintained incrementally)
- pawn structure: doubled, isolated, backward, islands, phalanx /
  supported (connected), passed (by rank, plus connected-passer,
  king-proximity and blocked-passer terms) — cached in a per-thread
  **pawn hash table**
- **Bishop pair, bad bishop**, rooks on open/semi-open files, the 7th rank
  and behind passers, **knight/bishop outposts**, minors behind pawns
- **per-count mobility tables** for N/B/R/Q (non-linear weights by safe
  square count, fitted under monotonicity constraints)
- **king shelter** (per-file table by pawn distance and rank, pawn-storm
  terms, king defenders) and a **king-attack danger model** (weighted
  attacker units + king-zone hits → quadratic safety table)
- **safe mobility**, threats (pawn attacks on minors/majors, safe minor
  attacks on majors), **hanging pieces**, tempo, complexity scaling
- Endgame material scaling — opposite-colour-bishop fortresses and
  pawnless leaders are scaled toward zero, so the search keeps tension
  instead of trading into unwinnable endings.

### Correctness
- **Perft**: the standard six-position suite verified bit-exact during
  development — startpos perft(5) = 4 865 609, Kiwipete perft(4) =
  4 085 603, promotion and en-passant torture positions included (~17 M
  nodes/s on a desktop core).
- The development-time native test battery (rules, SAN, search behaviour,
  SMP safety, stop responsiveness, eval symmetry, book) passed **2358
  assertions, zero failures**, deterministic across runs (see `HISTORY.md`).
- Incremental Zobrist keys / PST values / pawn keys are re-computed from
  scratch and compared after moves across random games.
- Full rule coverage: castling legality (including through-check), en
  passant, all four promotions, 50-move rule, threefold repetition,
  insufficient material, SAN with disambiguation and +/# suffixes, FEN
  import/export with round-trip tests.

### Engine strength

The engine's strength has been developed and verified through a long series
of match-gated releases (fixed-time head-to-heads with cumulative confirms
and SPRT verdicts) — the full ledger, experiment verdicts, lessons and the
per-release verification record are consolidated in
**[HISTORY.md](HISTORY.md)**. Every promotion in that ladder was earned by a
statistically accepted head-to-head at compiled defaults; every dead end is
documented with data. Headline reference points on the development rig
(2 cores, 50 ms/move, paired openings):

- vs the same-binary pure-HCE engine (`UseNNUE=0`): **+162.0 ± 16.6 Elo**
  (n=540) — the hybrid's measured margin, with the HCE opponent's identity
  proven by bench fingerprint before the match.
- The shipped net (v96b-mix21m-3ep at blend 77/72) earned its slot with
  **+14.1 ± 6.0 SPRT(0,10) H1 accepted** (n=3389) over the previous
  champion net.

Treat relative head-to-head numbers in `HISTORY.md` as the current truth,
not any absolute Elo label. The in-app 3000 preset searches with a third
more time and all 8 threads.

## App design notes

- **Material 3 "Sage Sanctuary" theme** — a deep emerald primary
  (`#17663E`) over soft sage/mint surfaces, light/dark dynamic-color-ready
  tokens, the Plus Jakarta Sans type family end to end, and a soft,
  generous pill-shaped corner-radius scale rather than generic defaults.
- **The board is a single custom View** drawing squares, highlights
  (last move, selection, check), legal-move dots/rings, coordinates and
  pieces on one Canvas — no image assets, so the APK stays tiny and the
  pieces scale crisply at any density.
- **MVVM-ish**: `GameViewModel` owns the native game on one engine thread;
  the UI collects immutable `GameUiState` snapshots from a `StateFlow`. The
  engine never blocks the main thread and the UI never touches engine state.
- The engine always takes a beat before replying (per-level minimum think
  time), so the thinking indicator is visible and replies never race the
  move animation.
- **Sounds** are synthesized WAVs bundled in `res/raw/` — no bundled
  third-party audio.
- Four board themes, a 100–3000 Elo selector, undo, flip, rematch,
  promotion picker, captured-material strips, move history in SAN, and an
  eval/depth/nps badge while the engine thinks.
- **Game review**: batch analysis with the same complexity/instability-aware
  adaptive time allocation as play, **a deep verification pass that re-searches
  every flagged moment** (the anti-false-blunder stage), contempt-free
  analysis evals, Lichess-methodology accuracy % (win% space, book moves
  excluded) and a calibrated performance rating, per-move classifications
  (Best / Excellent / Good / Inaccuracy / Mistake / Blunder / Book) driven
  by win% drop so decided positions stop manufacturing phantom mistakes,
  Multi-PV engine lines, and an optional Elo-personalized presentation layer
  (whole-pawn rounding / verbal coaching at lower levels, raw centipawns at
  Master tier). The analysis screen carries a clear note that TacTurn's
  evaluations are approximate estimates, not definitive engine truth. The
  full rating-accuracy engineering record is in `HISTORY.md` §9.
- **Clocks & match features**: chess clocks with Fischer increment and
  flag-fall
  endings (including the FIDE insufficient-mating-material safeguard),
  clock-aware engine time management, Pass & Play with player names and
  auto-flip, draw offers in both modes, live opening names (127-line ECO-style
  book), full-tag PGN export + Android share sheet, auto-promote to queen,
  haptic feedback, and mode/time-control-aware game history.

## Design decisions worth calling out

1. **The engine is a native Android library.** All chess logic compiles to
   `libtacturn.so`; the Kotlin side is a thin, reflection-free facade with a
   small Game/SearchLimits surface, so UI code never touches chess logic
   directly. The same C++ sources build on desktop for testing/benchmarking.
2. **Runtime-generated magic bitboards.** No giant magic tables in the
   repo; init searches for multipliers from a deterministic splitmix64
   stream, so every build/platform gets identical, verified attack sets.
3. **One engine thread, snapshot UI.** Avoids locks entirely: the search
   mutates the native position only inside its thread and always restores
   it; the UI renders immutable snapshots.
4. **Move ints are the ABI.** The 32-bit move encoding is identical in C++
   and Kotlin, so moves cross JNI as plain ints with zero marshalling.
5. **Race-hardened TT instead of locks.** Two-word entries with a
   verification word (payload first, key-XOR published last) make Lazy-SMP
   sharing safe without atomics-per-field or mutexes.
6. **No third-party chess code.** Algorithms and tables are standard
   published techniques (alpha-beta, killer/history/counter-moves,
   continuation histories, swap-off SEE, PeSTO tables, magic bitboards);
   all implementation is original to this project. MIT license.
7. **NNUE residual hybrid, ON by default — and measured.** A
   small quantized network (3072→512×2→32→32→1 with king buckets and
   16 output buckets, int16 SIMD inference, incrementally maintained
   inside make/unmake) corrects the hand-crafted evaluation: the
   residual is injected both at the **quiescence stand-pat** and into
   the **main-search static eval**, at a tuned blend (77/72), learned
   from Stockfish 17.1's static eval on tens of millions of
   self-generated positions produced by a different-navigator datagen
   protocol (self-play / HCE / blend / SF-guided mixes, deduplicated
   against the full labeled pool to control the self-distillation
   echo). The shipped net is `v96b-mix21m-3ep` (21.47M positions, val
   RMSE 105.87). Measured vs the strict same-binary HCE-off reference
   (`UseNNUE=0`, identity proven by bench fingerprint):
   **+162.0 ± 16.6 Elo at 50 ms (n=540)** — and the net itself earned
   its slot with a **+14.1 ± 6.0 SPRT(0,10) H1 accepted** head-to-head
   (n=3389) over the previous champion net. With the net zeroed or
   `UseNNUE=0` the engine plays pure HCE. The full hybrid campaign
   record — every accepted generation, every rejected probe (capacity
   ladders, teacher ladders, soups, blend sweeps), the harness-integrity
   post-mortem and the residual-hybrid ceiling stated honestly — is
   consolidated in **[HISTORY.md](HISTORY.md)** §13–§29.

## Engine architecture notes

TacTurn's engine is a complete native rewrite: every line of chess logic
(board, movegen, rules, SAN, search, evaluation, opening book) is C++17
built into `libtacturn.so` through the NDK — there is no Kotlin/JVM chess
logic anywhere in the app.

- **Lock-free transposition table** (~50 MB, XOR-verified two-word entries)
  safely shared by Lazy-SMP workers, with allocation-failure fallback that
  downsizes gracefully on memory-constrained devices instead of crashing.
- **Stability hardening**: explicit 8 MB stacks for engine threads (Android
  default thread stacks vary by OEM and can be too small for the search's
  recursion depth), thread-safe one-shot table init (`std::call_once`),
  every JNI entry point validates its session handle, 16 KB page-size
  alignment for Android 15+ devices, logcat breadcrumbs (tag
  `TacTurnNative`) around engine lifecycle and every search call.
- **Opening book**: 3,996 weighted lines (curated mainlines merged with
  chessdb.cn-verified breadth), transposition-safe, Zobrist-stable across
  processes.
- **Rotational stability**: game and analysis sessions live in ViewModels;
  finished games persist exactly once via a one-shot latch; process-death
  recovery restarts a fresh session instead of stranding a dead screen.

## License

MIT — see `LICENSE`. Engine code, app code, piece art and sounds are
original. Stockfish was used during development in two roles: as an
external benchmark opponent (binary only — never distributed, never
linked), and as the training-label teacher for the NNUE nets:
Stockfish 17.1 "Final evaluation" scores of engine-generated positions
are the supervised labels the networks regress on. No Stockfish code,
weights, or net architectures are copied; the label dependency is stated
plainly here and in `HISTORY.md` §13–§15.
chessdb.cn was queried read-only to verify opening-book moves.
